'use client'

import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react'
import { Maximize, Minimize, Pause, Play, ScanLine, SkipBack, SkipForward } from 'lucide-react'
import { DRAG_MIME, importFiles, insertItemById } from '@/lib/editor/actions'
import { onAssetsChanged, syncMedia } from '@/lib/editor/assets'
import { formatTime, playback, usePlayback } from '@/lib/editor/playback'
import { drawFrame, getLayerSize, hitTest, isActive } from '@/lib/editor/render'
import { SAFE_ZONES, type SafeZoneSpec } from '@/lib/editor/safe-zones'
import { editor, useEditor, useSelectedLayer } from '@/lib/editor/store'
import { projectDuration, type Layer } from '@/lib/editor/types'
import { cn } from '@/lib/utils'
import { whenFontsReady } from './layer-thumb'

type Gesture =
  | { mode: 'move'; id: string; offX: number; offY: number }
  | { mode: 'scale'; id: string; startDist: number; base: Layer }
  | { mode: 'width'; id: string; base: Layer }
  | { mode: 'rotate'; id: string }

export const EDIT_TEXT_EVENT = 'studio:edit-text'

export function Stage() {
  const wrapRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const surfaceRef = useRef<HTMLDivElement>(null)
  const gesture = useRef<Gesture | null>(null)
  const [scale, setScale] = useState(0.3)
  const [guides, setGuides] = useState<{ v: boolean; h: boolean }>({ v: false, h: false })
  const [safe, setSafe] = useState(false)
  const rootRef = useRef<HTMLDivElement>(null)
  const [full, setFull] = useState(false)
  useEffect(() => {
    const on = () => setFull(document.fullscreenElement === rootRef.current)
    document.addEventListener('fullscreenchange', on)
    return () => document.removeEventListener('fullscreenchange', on)
  }, [])
  const toggleFull = () => {
    if (document.fullscreenElement) void document.exitFullscreen()
    else void rootRef.current?.requestFullscreen?.()
  }
  const [dropping, setDropping] = useState(false)
  const W = useEditor((s) => s.project.width)
  const H = useEditor((s) => s.project.height)
  const format = useEditor((s) => s.project.format)
  const [zoneId, setZoneId] = useState<string>('')
  const zoneSpecs = SAFE_ZONES[format]
  const zoneSpec = zoneSpecs.find((s) => s.id === zoneId) ?? zoneSpecs[0]
  const selected = useSelectedLayer()
  const { time, playing } = usePlayback()
  const duration = useEditor((s) => projectDuration(s.project))

  useEffect(() => {
    const el = wrapRef.current
    if (!el) return
    const ro = new ResizeObserver(([entry]) => {
      const { width, height } = entry.contentRect
      setScale(Math.max(0.05, Math.min((width - 48) / W, (height - 48) / H)))
    })
    ro.observe(el)
    return () => ro.disconnect()
  }, [W, H])

  useEffect(() => {
    let raf = 0
    let last = performance.now()
    let dirty = true
    const markDirty = () => {
      dirty = true
    }
    const offA = onAssetsChanged(markDirty)
    const offE = editor.subscribe(markDirty)
    const offP = playback.subscribe(markDirty)
    void whenFontsReady().then(markDirty)
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000)
      last = now
      const pb = playback.get()
      const { project } = editor.get()
      if (!pb.recording) {
        let t = pb.time
        if (pb.playing) {
          t += dt
          const total = projectDuration(project)
          if (t >= total) t = 0
          playback.setTime(t)
        }
        const hasVideo = project.assets.some((a) => a.type === 'video')
        syncMedia(project, t, pb.playing)
        const canvas = canvasRef.current
        if (canvas && (dirty || pb.playing || hasVideo)) {
          drawFrame(canvas.getContext('2d')!, project, t)
          dirty = false
        }
      }
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => {
      cancelAnimationFrame(raf)
      offA()
      offE()
      offP()
    }
  }, [])

  const toProject = (clientX: number, clientY: number) => {
    const r = surfaceRef.current!.getBoundingClientRect()
    return { x: (clientX - r.left) / scale, y: (clientY - r.top) / scale }
  }

  const onPointerDown = (e: ReactPointerEvent) => {
    if (e.button !== 0) return
    const { project } = editor.get()
    const t = playback.get().time
    const p = toProject(e.clientX, e.clientY)
    const handle = (e.target as HTMLElement).dataset.handle
    const sel = project.layers.find((l) => l.id === editor.get().selectedId)
    if (handle && sel) {
      editor.checkpoint()
      if (handle === 'rotate') gesture.current = { mode: 'rotate', id: sel.id }
      else if (handle === 'width') gesture.current = { mode: 'width', id: sel.id, base: sel }
      else gesture.current = { mode: 'scale', id: sel.id, base: sel, startDist: Math.hypot(p.x - sel.x, p.y - sel.y) || 1 }
    } else {
      const hit = hitTest(project, t, p.x, p.y)
      editor.select(hit?.id ?? null)
      if (!hit || hit.locked) return
      editor.checkpoint()
      gesture.current = { mode: 'move', id: hit.id, offX: p.x - hit.x, offY: p.y - hit.y }
    }
    ;(e.currentTarget as HTMLElement).setPointerCapture(e.pointerId)
  }

  const onPointerMove = (e: ReactPointerEvent) => {
    const g = gesture.current
    if (!g) return
    const p = toProject(e.clientX, e.clientY)
    const l = editor.get().project.layers.find((x) => x.id === g.id)
    if (!l) return
    if (g.mode === 'move') {
      let x = p.x - g.offX
      let y = p.y - g.offY
      const snap = 10 / scale
      const v = Math.abs(x - W / 2) < snap
      const h = Math.abs(y - H / 2) < snap
      if (v) x = W / 2
      if (h) y = H / 2
      setGuides({ v, h })
      editor.updateLayer(g.id, { x: Math.round(x), y: Math.round(y) }, false)
    } else if (g.mode === 'rotate') {
      let deg = (Math.atan2(p.y - l.y, p.x - l.x) * 180) / Math.PI + 90
      if (!e.shiftKey) {
        const nearest = Math.round(deg / 45) * 45
        if (Math.abs(deg - nearest) < 4) deg = nearest
      }
      editor.updateLayer(g.id, { rotation: Math.round(((deg + 540) % 360) - 180) }, false)
    } else if (g.mode === 'width') {
      const a = (-l.rotation * Math.PI) / 180
      const lx = (p.x - l.x) * Math.cos(a) - (p.y - l.y) * Math.sin(a)
      editor.updateLayer(g.id, { width: Math.max(40, Math.round(Math.abs(lx) * 2)) }, false)
    } else {
      const k = Math.max(0.05, Math.hypot(p.x - l.x, p.y - l.y) / g.startDist)
      const b = g.base
      const patch: Partial<Layer> = { width: Math.max(20, Math.round(b.width * k)), height: Math.max(4, Math.round(b.height * k)) }
      if (b.kind === 'text') Object.assign(patch, { fontSize: Math.max(8, Math.round(b.fontSize * k)), strokeWidth: b.strokeWidth * k, bgPadding: b.bgPadding * k, bgRadius: b.bgRadius * k })
      editor.updateLayer(g.id, patch, false)
    }
  }

  const endGesture = () => {
    gesture.current = null
    setGuides({ v: false, h: false })
  }

  const box = selected && selected.kind !== 'audio' && selected.kind !== 'effect' && isActive(selected, time) ? { l: selected, ...getLayerSize(selected) } : null
  const canWidth = box && (box.l.kind === 'text' || box.l.kind === 'comment')

  return (
    <div ref={rootRef} className="flex min-h-0 min-w-0 flex-1 flex-col bg-stage">
      <div
        ref={wrapRef}
        className="relative flex min-h-0 flex-1 items-center justify-center overflow-hidden"
        onPointerDown={(e) => {
          if (e.target === e.currentTarget) editor.select(null)
        }}
        onDragOver={(e) => {
          if (e.dataTransfer.types.includes(DRAG_MIME) || e.dataTransfer.types.includes('Files')) {
            e.preventDefault()
            setDropping(true)
          }
        }}
        onDragLeave={() => setDropping(false)}
        onDrop={(e) => {
          e.preventDefault()
          setDropping(false)
          const pos = surfaceRef.current ? toProject(e.clientX, e.clientY) : undefined
          const inside = pos && pos.x >= 0 && pos.y >= 0 && pos.x <= W && pos.y <= H ? pos : undefined
          const id = e.dataTransfer.getData(DRAG_MIME)
          if (id) insertItemById(id, inside)
          else if (e.dataTransfer.files.length) void importFiles(e.dataTransfer.files, { insert: true, pos: inside })
        }}
      >
        <div
          ref={surfaceRef}
          className={cn('relative shrink-0 touch-none select-none shadow-2xl ring-1 ring-border', dropping && 'ring-2 ring-primary')}
          style={{ width: W * scale, height: H * scale }}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={endGesture}
          onPointerCancel={endGesture}
          onDoubleClick={() => {
            if (selected?.kind === 'text' || selected?.kind === 'comment' || selected?.kind === 'sticker') window.dispatchEvent(new Event(EDIT_TEXT_EVENT))
          }}
          role="application"
          aria-label="Canvas. Click a layer to select it, drag to move."
        >
          <canvas ref={canvasRef} width={W} height={H} className="block size-full" />
          {safe && zoneSpec && <SafeZones spec={zoneSpec} scale={scale} W={W} H={H} />}
          {guides.v && <div className="pointer-events-none absolute inset-y-0 left-1/2 w-px bg-primary" />}
          {guides.h && <div className="pointer-events-none absolute inset-x-0 top-1/2 h-px bg-primary" />}
          {box && (
            <div
              className="pointer-events-none absolute border border-primary"
              style={{
                left: (box.l.x - box.w / 2) * scale,
                top: (box.l.y - box.h / 2) * scale,
                width: box.w * scale,
                height: box.h * scale,
                transform: `rotate(${box.l.rotation}deg)`,
              }}
            >
              {!box.l.locked && (
                <>
                  {(['-left-1.5 -top-1.5', '-right-1.5 -top-1.5', '-left-1.5 -bottom-1.5', '-right-1.5 -bottom-1.5'] as const).map((pos) => (
                    <span
                      key={pos}
                      data-handle="scale"
                      className={cn('pointer-events-auto absolute size-3 cursor-nwse-resize rounded-full border-2 border-primary bg-foreground', pos)}
                    />
                  ))}
                  {canWidth &&
                    (['-left-1 top-1/2', '-right-1 top-1/2'] as const).map((pos) => (
                      <span key={pos} data-handle="width" className={cn('pointer-events-auto absolute h-5 w-2 -translate-y-1/2 cursor-ew-resize rounded-full border-2 border-primary bg-foreground', pos)} />
                    ))}
                  <span className="absolute -top-8 left-1/2 h-6 w-px -translate-x-1/2 bg-primary" />
                  <span data-handle="rotate" className="pointer-events-auto absolute -top-10 left-1/2 size-4 -translate-x-1/2 cursor-grab rounded-full border-2 border-primary bg-foreground" title="Rotate (hold Shift for free rotation)" />
                </>
              )}
            </div>
          )}
        </div>
      </div>
      <div className="flex h-12 shrink-0 items-center justify-between gap-4 border-t border-border bg-card px-4">
        <button
          type="button"
          onClick={() => setSafe((s) => !s)}
          aria-pressed={safe}
          className={cn('flex items-center gap-2 rounded-md px-2 py-1.5 text-xs font-medium transition-colors', safe ? 'bg-accent text-primary' : 'text-muted-foreground hover:text-foreground')}
        >
          <ScanLine className="size-4" aria-hidden="true" />
          Safe zones
        </button>
        <button
          type="button"
          onClick={toggleFull}
          aria-pressed={full}
          aria-label={full ? 'Exit full screen' : 'Full screen preview'}
          title={full ? 'Exit full screen (Esc)' : 'Full screen preview'}
          className="rounded-md p-1.5 text-muted-foreground transition-colors hover:text-foreground"
        >
          {full ? <Minimize className="size-4" aria-hidden="true" /> : <Maximize className="size-4" aria-hidden="true" />}
        </button>
        {safe && zoneSpecs.length > 1 && (
          <select
            aria-label="Safe zone platform"
            title={zoneSpec?.note}
            value={zoneSpec?.id}
            onChange={(e) => setZoneId(e.target.value)}
            className="rounded-md border border-border bg-background px-2 py-1 text-xs text-foreground"
          >
            {zoneSpecs.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        )}
        {safe && zoneSpecs.length === 1 && <span className="text-xs text-muted-foreground" title={zoneSpec?.note}>{zoneSpec?.name}</span>}
        <div className="flex items-center gap-1">
          <button type="button" aria-label="Go to start" onClick={() => playback.setTime(0)} className="rounded-md p-2 text-muted-foreground hover:text-foreground">
            <SkipBack className="size-4" aria-hidden="true" />
          </button>
          <button
            type="button"
            aria-label={playing ? 'Pause' : 'Play'}
            onClick={() => playback.setPlaying(!playing)}
            className="flex size-9 items-center justify-center rounded-full bg-primary text-primary-foreground transition-transform active:scale-95"
          >
            {playing ? <Pause className="size-4" aria-hidden="true" /> : <Play className="ml-0.5 size-4" aria-hidden="true" />}
          </button>
          <button type="button" aria-label="Go to end" onClick={() => playback.setTime(Math.max(0, duration - 0.01))} className="rounded-md p-2 text-muted-foreground hover:text-foreground">
            <SkipForward className="size-4" aria-hidden="true" />
          </button>
        </div>
        <p className="font-mono text-xs tabular-nums text-muted-foreground">
          <span className="text-foreground">{formatTime(time)}</span> / {formatTime(duration)}
        </p>
      </div>
    </div>
  )
}

function SafeZones({ spec, scale, W, H }: { spec: SafeZoneSpec; scale: number; W: number; H: number }) {
  return (
    <div className="pointer-events-none absolute inset-0" aria-hidden="true">
      {spec.zones.map((z, i) => (
        <div
          key={i}
          className="absolute flex items-center justify-center overflow-hidden border border-dashed border-destructive/70 bg-destructive/25"
          style={{ left: z.x * W * scale, top: z.y * H * scale, width: z.w * W * scale, height: z.h * H * scale }}
        >
          {z.label && (
            <span className="whitespace-nowrap rounded-sm bg-background/70 px-1 text-[10px] font-medium uppercase tracking-wide text-foreground">
              {z.label}
            </span>
          )}
        </div>
      ))}
    </div>
  )
}
