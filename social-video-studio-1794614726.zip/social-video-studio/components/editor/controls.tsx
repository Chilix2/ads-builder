'use client'

import { useId, type ReactNode } from 'react'
import { cn } from '@/lib/utils'

export function Section({ title, children, action }: { title: string; children: ReactNode; action?: ReactNode }) {
  return (
    <section className="flex flex-col gap-3 border-b border-border px-4 py-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{title}</h3>
        {action}
      </div>
      {children}
    </section>
  )
}

export function Field({ label, children, className }: { label: string; children: (id: string) => ReactNode; className?: string }) {
  const id = useId()
  return (
    <div className={cn('flex flex-col gap-1.5', className)}>
      <label htmlFor={id} className="text-xs text-muted-foreground">
        {label}
      </label>
      {children(id)}
    </div>
  )
}

const inputCls =
  'h-8 w-full rounded-md border border-input bg-secondary px-2 text-sm text-foreground outline-none transition-colors focus:border-primary'

export function NumberField({
  label,
  value,
  onChange,
  step = 1,
  min,
  max,
  suffix,
}: {
  label: string
  value: number
  onChange: (v: number) => void
  step?: number
  min?: number
  max?: number
  suffix?: string
}) {
  return (
    <Field label={label}>
      {(id) => (
        <div className="relative">
          <input
            id={id}
            type="number"
            className={cn(inputCls, 'font-mono tabular-nums', suffix && 'pr-7')}
            value={Number.isFinite(value) ? Math.round(value * 100) / 100 : 0}
            step={step}
            min={min}
            max={max}
            onChange={(e) => {
              const v = Number.parseFloat(e.target.value)
              if (Number.isFinite(v)) onChange(v)
            }}
          />
          {suffix && <span className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">{suffix}</span>}
        </div>
      )}
    </Field>
  )
}

export function RangeField({
  label,
  value,
  onChange,
  min = 0,
  max = 1,
  step = 0.01,
  format = (v) => v.toFixed(2),
}: {
  label: string
  value: number
  onChange: (v: number) => void
  min?: number
  max?: number
  step?: number
  format?: (v: number) => string
}) {
  const id = useId()
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <label htmlFor={id} className="text-xs text-muted-foreground">
          {label}
        </label>
        <span className="font-mono text-xs tabular-nums text-foreground">{format(value)}</span>
      </div>
      <input id={id} type="range" className="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </div>
  )
}

export function TextField({ label, value, onChange, multiline }: { label: string; value: string; onChange: (v: string) => void; multiline?: boolean }) {
  return (
    <Field label={label}>
      {(id) =>
        multiline ? (
          <textarea
            id={id}
            rows={3}
            className={cn(inputCls, 'h-auto min-h-20 resize-y py-1.5 leading-relaxed')}
            value={value}
            onChange={(e) => onChange(e.target.value)}
          />
        ) : (
          <input id={id} className={inputCls} value={value} onChange={(e) => onChange(e.target.value)} />
        )
      }
    </Field>
  )
}

export function SelectField<T extends string>({
  label,
  value,
  onChange,
  options,
}: {
  label: string
  value: T
  onChange: (v: T) => void
  options: { value: T; label: string }[]
}) {
  return (
    <Field label={label}>
      {(id) => (
        <select id={id} className={inputCls} value={value} onChange={(e) => onChange(e.target.value as T)}>
          {options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      )}
    </Field>
  )
}

const toHex = (c: string) => (/^#[0-9a-f]{6}$/i.test(c) ? c : '#000000')

export function ColorField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <Field label={label}>
      {(id) => (
        <div className="flex items-center gap-2">
          <input
            type="color"
            aria-label={`${label} picker`}
            className="size-8 shrink-0 cursor-pointer rounded-md border border-input bg-secondary p-0.5"
            value={toHex(value)}
            onChange={(e) => onChange(e.target.value)}
          />
          <input id={id} className={cn(inputCls, 'font-mono text-xs')} value={value} onChange={(e) => onChange(e.target.value)} />
        </div>
      )}
    </Field>
  )
}

export function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="flex items-center justify-between gap-3 text-sm text-foreground"
    >
      <span>{label}</span>
      <span className={cn('relative h-5 w-9 rounded-full transition-colors', checked ? 'bg-primary' : 'bg-input')}>
        <span className={cn('absolute top-0.5 size-4 rounded-full bg-foreground transition-all', checked ? 'left-4.5' : 'left-0.5')} />
      </span>
    </button>
  )
}

export function Segmented<T extends string>({
  value,
  onChange,
  options,
  label,
}: {
  value: T
  onChange: (v: T) => void
  options: { value: T; label: ReactNode; title?: string }[]
  label: string
}) {
  return (
    <div role="radiogroup" aria-label={label} className="flex rounded-md border border-input bg-secondary p-0.5">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          role="radio"
          aria-checked={value === o.value}
          title={o.title}
          onClick={() => onChange(o.value)}
          className={cn(
            'flex h-7 flex-1 items-center justify-center rounded px-2 text-xs font-medium transition-colors',
            value === o.value ? 'bg-accent text-accent-foreground' : 'text-muted-foreground hover:text-foreground',
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}
