'use client'

import { useMemo, useRef, useState } from 'react'
import { Bot, Check, FileText, Film, ImageDown, Loader2, X } from 'lucide-react'
import { downloadText, exportLayerPNGs, exportVideo } from '@/lib/editor/export'
import { playback } from '@/lib/editor/playback'
import { TIERS } from '@/lib/editor/platform-tools'
import { NATIVE_PLATFORMS, buildRebuildPlan, planToManifest, planToMarkdown, strategyOf, summarizePlan, type NativePlatform, type Strategy } from '@/lib/editor/rebuild'
import { getSlides } from '@/lib/editor/types'
import { editor, useEditor } from '@/lib/editor/store'
import { cn } from '@/lib/utils'

const STRATEGY: Record<Strategy, { label: string; cls: string }> = {
  native: { label: 'Native tool', cls: 'bg-primary/15 text-primary' },
  fallback: { label: 'Substitute', cls: 'bg-chart-4/20 text-chart-4' },
  overlay: { label: 'Overlay PNG', cls: 'bg-secondary text-foreground' },
  plate: { label: 'Base plate', cls: 'bg-secondary text-muted-foreground' },
}

const fmt = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toFixed(1).padStart(4, '0')}`

export function RebuildGuide({ onClose }: { onClose: () => void }) {
  const project = useEditor((s) => s.project)
  const target = project.target ?? 'instagram'
  const [platform, setPlatform] = useState<NativePlatform>(target)
  const [done, setDone] = useState<Set<string>>(new Set())
  const [progress, setProgress] = useState<number | null>(null)
  const abort = useRef<AbortController | null>(null)
  const steps = useMemo(() => buildRebuildPlan(project, platform), [project, platform])
  const summary = useMemo(() => summarizePlan(steps), [steps])
  const slides = getSlides(project)
  const overlays = slides.flatMap((s) => s.layers).filter((l) => strategyOf(l, platform) === 'overlay')
  const porting = platform !== target

  const exportPlate = async () => {
    const plate = { ...project, name: `${project.name} plate ${(project.activeSlide ?? 0) + 1}`, layers: project.layers.filter((l) => strategyOf(l, platform) === 'plate') }
    abort.current = new AbortController()
    setProgress(0)
    try {
      await exportVideo(plate, { fps: 30, scale: 1080 / Math.min(project.width, project.height), onProgress: setProgress, signal: abort.current.signal })
    } finally {
      setProgress(null)
    }
  }

  const toggle = (id: string) =>
    setDone((d) => {
      const n = new Set(d)
      n.has(id) ? n.delete(id) : n.add(id)
      return n
    })

  const action = 'flex items-center gap-2 rounded-md border border-border bg-secondary px-3 py-2 text-xs font-medium text-foreground transition-colors hover:border-primary disabled:opacity-50'

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 p-4" role="dialog" aria-modal="true" aria-labelledby="rebuild-title">
      <div className="flex max-h-[90vh] w-full max-w-3xl flex-col overflow-hidden rounded-xl border border-border bg-card shadow-2xl">
        <div className="flex items-start justify-between gap-4 border-b border-border p-5">
          <div className="flex flex-col gap-1">
            <h2 id="rebuild-title" className="text-base font-semibold text-foreground">
              Build plan
            </h2>
            <p className="max-w-xl text-xs leading-relaxed text-muted-foreground text-pretty">
              One exact path per platform. Every step names a single native tool, so anyone (or an agent) can click through it without mixing up Instagram and TikTok features.
            </p>
          </div>
          <button type="button" aria-label="Close" onClick={onClose} className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground">
            <X className="size-4" aria-hidden="true" />
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-3 border-b border-border px-5 py-3">
          <div role="radiogroup" aria-label="Target editor" className="flex rounded-lg border border-border bg-background p-0.5">
            {(Object.keys(NATIVE_PLATFORMS) as NativePlatform[]).map((p) => (
              <button
                key={p}
                type="button"
                role="radio"
                aria-checked={platform === p}
                onClick={() => {
                  setPlatform(p)
                  setDone(new Set())
                }}
                className={cn('rounded-md px-3 py-1.5 text-xs font-medium', platform === p ? 'bg-accent text-foreground' : 'text-muted-foreground hover:text-foreground')}
              >
                {NATIVE_PLATFORMS[p].name}
                {p === target ? ' (target)' : ' (port)'}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap gap-2 text-[11px]">
            {(Object.keys(STRATEGY) as Strategy[]).map((s) => (
              <span key={s} className={cn('rounded px-1.5 py-0.5', STRATEGY[s].cls)}>
                {summary[s]} {STRATEGY[s].label.toLowerCase()}
              </span>
            ))}
            <span className={cn('rounded px-1.5 py-0.5', summary.paid.length ? 'bg-destructive/15 text-destructive' : 'bg-secondary text-muted-foreground')}>
              {summary.paid.length ? `Needs ${summary.paid.map((x) => TIERS[x].label).join(', ')}` : 'All free tools'}
            </span>
          </div>
          <span className="ml-auto text-xs text-muted-foreground">
            {done.size}/{steps.length} done
          </span>
        </div>

        <p className="border-b border-border bg-background px-5 py-2.5 text-xs leading-relaxed text-muted-foreground">
          {porting && (
            <strong className="font-semibold text-chart-4">
              {`Porting a ${NATIVE_PLATFORMS[target].name} design: ${summary.fallback} step(s) use substitutes because the tool doesn't exist here. `}
            </strong>
          )}
          {NATIVE_PLATFORMS[platform].note}
        </p>

        <ol className="flex flex-1 flex-col overflow-y-auto">
          {steps.map((s, i) => {
            const checked = done.has(s.id)
            return (
              <li key={s.id} className="flex gap-3 border-b border-border px-5 py-3.5">
                <button
                  type="button"
                  role="checkbox"
                  aria-checked={checked}
                  aria-label={`Mark step ${i + 1} done`}
                  onClick={() => toggle(s.id)}
                  className={cn(
                    'mt-0.5 flex size-5 shrink-0 items-center justify-center rounded border transition-colors',
                    checked ? 'border-primary bg-primary text-primary-foreground' : 'border-input hover:border-primary',
                  )}
                >
                  {checked && <Check className="size-3.5" aria-hidden="true" />}
                </button>
                <div className={cn('flex min-w-0 flex-1 flex-col gap-1.5', checked && 'opacity-50')}>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-[11px] text-muted-foreground">{fmt(s.at)}</span>
                    <button
                      type="button"
                      className="truncate text-left text-sm font-semibold text-foreground hover:text-primary"
                      onClick={() => {
                        if (slides.length > 1 && s.slide !== (project.activeSlide ?? 0)) editor.selectSlide(s.slide)
                        playback.setTime(s.at + 0.01)
                        if (s.layerIds.length === 1) editor.select(s.layerIds[0])
                      }}
                    >
                      {i + 1}. {s.title}
                    </button>
                    <span className={cn('rounded px-1.5 py-0.5 text-[10px] font-medium', STRATEGY[s.strategy].cls)}>{STRATEGY[s.strategy].label}</span>
                  </div>
                  <p className="flex flex-wrap items-center gap-2 text-xs font-medium text-primary">
                    {s.tool}
                    {s.tier !== 'free' && (
                      <span title={TIERS[s.tier].note} className="rounded bg-destructive/15 px-1.5 py-0.5 text-[10px] text-destructive">
                        {TIERS[s.tier].label}
                      </span>
                    )}
                    {s.verify && (
                      <span title="Menu path moves between app versions — search for the tool name if missing" className="rounded bg-secondary px-1.5 py-0.5 text-[10px] text-muted-foreground">
                        verify path
                      </span>
                    )}
                  </p>
                  <ul className="flex flex-col gap-0.5">
                    {s.settings.map((x) => (
                      <li key={x} className="text-xs leading-relaxed text-muted-foreground">
                        {x}
                      </li>
                    ))}
                  </ul>
                </div>
              </li>
            )
          })}
        </ol>

        <div className="flex flex-wrap items-center gap-2 border-t border-border p-4">
          <button type="button" className={action} onClick={exportPlate} disabled={progress !== null}>
            {progress !== null ? <Loader2 className="size-4 animate-spin text-primary" aria-hidden="true" /> : <Film className="size-4 text-primary" aria-hidden="true" />}
            {progress !== null ? `Plate ${Math.round(progress * 100)}%` : slides.length > 1 ? `Plate for slide ${(project.activeSlide ?? 0) + 1}` : 'Base plate video'}
          </button>
          {progress !== null && (
            <button type="button" className="text-xs text-muted-foreground hover:text-foreground" onClick={() => abort.current?.abort()}>
              Cancel
            </button>
          )}
          <button type="button" className={action} disabled={!overlays.length} onClick={() => void exportLayerPNGs(project, overlays)}>
            <ImageDown className="size-4 text-primary" aria-hidden="true" />
            Overlay pack ({overlays.length} PNG)
          </button>
          <button type="button" className={action} onClick={() => downloadText(planToMarkdown(project, platform, steps), `${project.name}-${platform}-plan.md`, 'text/markdown')}>
            <FileText className="size-4 text-primary" aria-hidden="true" />
            Checklist (.md)
          </button>
          <button
            type="button"
            className={action}
            title="Step manifest for browser automation or an API pipeline"
            onClick={() => downloadText(JSON.stringify(planToManifest(project, platform, steps), null, 2), `${project.name}-${platform}-manifest.json`, 'application/json')}
          >
            <Bot className="size-4 text-primary" aria-hidden="true" />
            Automation manifest
          </button>
        </div>
      </div>
    </div>
  )
}
