'use client'

import { useEffect } from 'react'
import { playback } from '@/lib/editor/playback'
import { editor } from '@/lib/editor/store'
import { Inspector } from './inspector'
import { LibraryPanel } from './library-panel'
import { SlidesBar } from './slides-bar'
import { Stage } from './stage'
import { Timeline } from './timeline'
import { TopBar } from './top-bar'

function isTyping(el: EventTarget | null) {
  const t = el as HTMLElement | null
  return !!t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)
}

export function Editor() {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (isTyping(e.target)) return
      const mod = e.metaKey || e.ctrlKey
      const { selectedId, project } = editor.get()
      const sel = project.layers.find((l) => l.id === selectedId)
      if (mod && e.key.toLowerCase() === 'z') {
        e.preventDefault()
        if (e.shiftKey) editor.redo()
        else editor.undo()
      } else if (mod && e.key.toLowerCase() === 'y') {
        e.preventDefault()
        editor.redo()
      } else if (mod && e.key.toLowerCase() === 'd' && sel) {
        e.preventDefault()
        editor.duplicate(sel.id)
      } else if (e.key === ' ') {
        e.preventDefault()
        playback.setPlaying(!playback.get().playing)
      } else if ((e.key === 'Delete' || e.key === 'Backspace') && sel) {
        e.preventDefault()
        editor.removeLayer(sel.id)
      } else if (e.key.toLowerCase() === 's' && !mod && sel) {
        editor.split(sel.id, playback.get().time)
      } else if (e.key === 'Escape') {
        editor.select(null)
      } else if (sel && !sel.locked && e.key.startsWith('Arrow')) {
        e.preventDefault()
        const step = e.shiftKey ? 10 : 1
        const dx = e.key === 'ArrowLeft' ? -step : e.key === 'ArrowRight' ? step : 0
        const dy = e.key === 'ArrowUp' ? -step : e.key === 'ArrowDown' ? step : 0
        editor.updateLayer(sel.id, { x: sel.x + dx, y: sel.y + dy })
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  return (
    <div className="flex h-dvh flex-col overflow-hidden bg-background text-foreground">
      <TopBar />
      <div className="flex min-h-0 flex-1">
        <aside aria-label="Library" className="hidden shrink-0 border-r border-border md:flex">
          <LibraryPanel />
        </aside>
        <main className="flex min-w-0 flex-1 flex-col">
          <Stage />
        </main>
        <aside aria-label="Inspector" className="hidden w-80 shrink-0 flex-col border-l border-border bg-card lg:flex">
          <Inspector />
        </aside>
      </div>
      <SlidesBar />
      <section aria-label="Timeline" className="h-56 shrink-0 border-t border-border">
        <Timeline />
      </section>
    </div>
  )
}
