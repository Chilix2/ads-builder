'use client'

import { useEffect, useRef, useState } from 'react'
import { AlignCenter, AlignLeft, AlignRight, Copy, FlipHorizontal, Maximize, MousePointerClick, Trash2, Upload } from 'lucide-react'
import { assetFromFile } from '@/lib/editor/assets'
import { FORM_NAMES, createMedia } from '@/lib/editor/factory'
import { FONT_OPTIONS } from '@/lib/editor/fonts'
import { ANIM_IN, ANIM_OUT, DEFAULT_ADJUST, FILTERS, LOOPS } from '@/lib/editor/presets'
import { editor, useEditor, useSelectedLayer } from '@/lib/editor/store'
import type { CommentVariant, FormType, Layer, WarpType } from '@/lib/editor/types'
import { cn } from '@/lib/utils'
import { ColorField, NumberField, RangeField, Section, Segmented, SelectField, TextField, Toggle } from './controls'
import { EDIT_TEXT_EVENT } from './stage'

type Tab = 'edit' | 'animate' | 'adjust'

export function Inspector() {
  const layer = useSelectedLayer()
  const [tab, setTab] = useState<Tab>('edit')
  if (!layer) return <ProjectInspector />
  const set = (patch: Partial<Layer>) => editor.updateLayer(layer.id, patch)
  const visual = layer.kind !== 'audio'
  return (
    <div className="flex min-h-0 flex-col">
      <div className="flex items-center gap-2 border-b border-border px-4 py-3">
        <input
          aria-label="Layer name"
          className="h-8 min-w-0 flex-1 rounded-md bg-transparent px-1 text-sm font-semibold text-foreground outline-none focus:bg-secondary"
          value={layer.name}
          onChange={(e) => set({ name: e.target.value })}
        />
        <button type="button" aria-label="Duplicate layer" onClick={() => editor.duplicate(layer.id)} className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground">
          <Copy className="size-4" aria-hidden="true" />
        </button>
        <button type="button" aria-label="Delete layer" onClick={() => editor.removeLayer(layer.id)} className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-destructive">
          <Trash2 className="size-4" aria-hidden="true" />
        </button>
      </div>
      {visual && (
        <div className="border-b border-border px-4 py-2">
          <Segmented
            label="Inspector section"
            value={tab}
            onChange={setTab}
            options={[
              { value: 'edit', label: 'Edit' },
              { value: 'animate', label: 'Animate' },
              { value: 'adjust', label: 'Adjust' },
            ]}
          />
        </div>
      )}
      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto">
        {(tab === 'edit' || !visual) && <EditTab layer={layer} set={set} />}
        {visual && tab === 'animate' && <AnimateTab layer={layer} set={set} />}
        {visual && tab === 'adjust' && <AdjustTab layer={layer} set={set} />}
      </div>
    </div>
  )
}

type Props<L extends Layer = Layer> = { layer: L; set: (p: Partial<Layer>) => void }

function ProjectInspector() {
  const name = useEditor((s) => s.project.name)
  const bg = useEditor((s) => s.project.background)
  const count = useEditor((s) => s.project.layers.length)
  return (
    <div className="flex flex-col">
      <Section title="Project">
        <TextField label="Name" value={name} onChange={(v) => editor.setProject({ ...editor.get().project, name: v }, false)} />
        <ColorField label="Background" value={bg} onChange={(v) => editor.setProject({ ...editor.get().project, background: v })} />
      </Section>
      <div className="flex flex-col items-center gap-3 px-6 py-10 text-center">
        <MousePointerClick className="size-6 text-muted-foreground" aria-hidden="true" />
        <p className="text-sm leading-relaxed text-muted-foreground">
          {count ? 'Select a layer on the canvas or timeline to edit it.' : 'Pick a template or drag elements from the library to start.'}
        </p>
        <ul className="flex flex-col gap-1 text-xs text-muted-foreground">
          <li>Space — play / pause</li>
          <li>S — split at playhead</li>
          <li>Ctrl+D — duplicate · Del — delete</li>
          <li>Ctrl+Z / Ctrl+Shift+Z — undo / redo</li>
        </ul>
      </div>
    </div>
  )
}

function TransformSection({ layer, set }: Props) {
  if (layer.kind === 'audio' || layer.kind === 'effect') return null
  const { project } = editor.get()
  return (
    <Section
      title="Transform"
      action={
        <button
          type="button"
          onClick={() => set({ x: project.width / 2, y: project.height / 2 })}
          className="text-xs text-primary hover:underline"
        >
          Center
        </button>
      }
    >
      <div className="grid grid-cols-2 gap-3">
        <NumberField label="X" value={layer.x} onChange={(x) => set({ x })} />
        <NumberField label="Y" value={layer.y} onChange={(y) => set({ y })} />
        <NumberField label="Width" value={layer.width} min={1} onChange={(width) => set({ width })} />
        {layer.kind !== 'text' && layer.kind !== 'comment' && layer.kind !== 'form' && <NumberField label="Height" value={layer.height} min={1} onChange={(height) => set({ height })} />}
        <NumberField label="Rotation" value={layer.rotation} suffix="°" onChange={(rotation) => set({ rotation })} />
      </div>
      <RangeField label="Opacity" value={layer.opacity} onChange={(opacity) => set({ opacity })} format={(v) => `${Math.round(v * 100)}%`} />
    </Section>
  )
}

function TimingSection({ layer, set }: Props) {
  return (
    <Section title="Timing">
      <div className="grid grid-cols-2 gap-3">
        <NumberField label="Start" value={layer.start} step={0.1} min={0} suffix="s" onChange={(start) => set({ start: Math.max(0, start) })} />
        <NumberField label="Duration" value={layer.duration} step={0.1} min={0.1} suffix="s" onChange={(duration) => set({ duration: Math.max(0.1, duration) })} />
      </div>
    </Section>
  )
}

function useFocusOnEdit() {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const focus = () => ref.current?.querySelector<HTMLTextAreaElement | HTMLInputElement>('textarea, input')?.focus()
    window.addEventListener(EDIT_TEXT_EVENT, focus)
    return () => window.removeEventListener(EDIT_TEXT_EVENT, focus)
  }, [])
  return ref
}

function EditTab({ layer, set }: Props) {
  const focusRef = useFocusOnEdit()
  return (
    <>
      <div ref={focusRef}>
        {layer.kind === 'text' && <TextSection layer={layer} set={set} />}
        {layer.kind === 'comment' && <CommentSection layer={layer} set={set} />}
        {layer.kind === 'sticker' && <StickerSection layer={layer} set={set} />}
        {layer.kind === 'form' && <FormSection layer={layer} set={set} />}
      </div>
      {layer.kind === 'media' && <MediaSection layer={layer} set={set} />}
      {layer.kind === 'audio' && <AudioSection layer={layer} set={set} />}
      {layer.kind === 'shape' && <ShapeSection layer={layer} set={set} />}
      {layer.kind === 'effect' && <EffectSection layer={layer} set={set} />}
      <TransformSection layer={layer} set={set} />
      <TimingSection layer={layer} set={set} />
      <LayerOrder id={layer.id} />
    </>
  )
}

function LayerOrder({ id }: { id: string }) {
  const btn = 'flex-1 rounded-md border border-input bg-secondary py-1.5 text-xs text-foreground hover:border-primary'
  return (
    <Section title="Arrange">
      <div className="flex gap-2">
        <button type="button" className={btn} onClick={() => editor.reorder(id, 'back')}>Back</button>
        <button type="button" className={btn} onClick={() => editor.reorder(id, 'backward')}>Down</button>
        <button type="button" className={btn} onClick={() => editor.reorder(id, 'forward')}>Up</button>
        <button type="button" className={btn} onClick={() => editor.reorder(id, 'front')}>Front</button>
      </div>
    </Section>
  )
}

function TextSection({ layer, set }: Props<Extract<Layer, { kind: 'text' }>>) {
  return (
    <Section title="Text">
      <TextField label="Content" multiline value={layer.text} onChange={(text) => set({ text })} />
      <div className="grid grid-cols-2 gap-3">
        <SelectField label="Font" value={layer.font} onChange={(font) => set({ font })} options={FONT_OPTIONS.map((f) => ({ value: f.key, label: f.label }))} />
        <SelectField
          label="Weight"
          value={String(layer.fontWeight)}
          onChange={(v) => set({ fontWeight: Number(v) })}
          options={['400', '500', '700', '800', '900'].map((v) => ({ value: v, label: v }))}
        />
        <NumberField label="Size" value={layer.fontSize} min={8} onChange={(fontSize) => set({ fontSize })} />
        <NumberField label="Letter spacing" value={layer.letterSpacing} step={0.5} onChange={(letterSpacing) => set({ letterSpacing })} />
      </div>
      <RangeField label="Line height" value={layer.lineHeight} min={0.8} max={2} onChange={(lineHeight) => set({ lineHeight })} />
      <Segmented
        label="Alignment"
        value={layer.align}
        onChange={(align) => set({ align })}
        options={[
          { value: 'left', label: <AlignLeft className="size-4" aria-label="Left" /> },
          { value: 'center', label: <AlignCenter className="size-4" aria-label="Center" /> },
          { value: 'right', label: <AlignRight className="size-4" aria-label="Right" /> },
        ]}
      />
      <div className="grid grid-cols-2 gap-x-3 gap-y-2">
        <Toggle label="Uppercase" checked={layer.uppercase} onChange={(uppercase) => set({ uppercase })} />
        <Toggle label="Italic" checked={layer.italic} onChange={(italic) => set({ italic })} />
        <Toggle label="Shadow" checked={layer.shadow} onChange={(shadow) => set({ shadow })} />
      </div>
      <ColorField label="Color" value={layer.color} onChange={(color) => set({ color })} />
      <div className="grid grid-cols-[1fr_5rem] items-end gap-3">
        <ColorField label="Outline" value={layer.strokeColor} onChange={(strokeColor) => set({ strokeColor })} />
        <NumberField label="Width" value={layer.strokeWidth} min={0} onChange={(strokeWidth) => set({ strokeWidth: Math.max(0, strokeWidth) })} />
      </div>
      <SelectField
        label="Background"
        value={layer.bgMode}
        onChange={(bgMode) => set({ bgMode })}
        options={[
          { value: 'none', label: 'None' },
          { value: 'box', label: 'Box' },
          { value: 'line', label: 'Per line (TikTok)' },
        ]}
      />
      {layer.bgMode !== 'none' && (
        <>
          <ColorField label="Background color" value={layer.bgColor} onChange={(bgColor) => set({ bgColor })} />
          <div className="grid grid-cols-2 gap-3">
            <NumberField label="Padding" value={layer.bgPadding} min={0} onChange={(bgPadding) => set({ bgPadding })} />
            <NumberField label="Radius" value={layer.bgRadius} min={0} onChange={(bgRadius) => set({ bgRadius })} />
          </div>
        </>
      )}
      {layer.loop?.type === 'karaoke' && <ColorField label="Karaoke highlight" value={layer.highlightColor} onChange={(highlightColor) => set({ highlightColor })} />}
    </Section>
  )
}

const WARPS: { value: WarpType; label: string }[] = [
  { value: 'none', label: 'Flat' },
  { value: 'tilt-left', label: 'Tilted left' },
  { value: 'tilt-right', label: 'Tilted right' },
  { value: 'top-big', label: 'Top bigger' },
  { value: 'bottom-big', label: 'Bottom bigger' },
]

function CommentSection({ layer, set }: Props<Extract<Layer, { kind: 'comment' }>>) {
  const inputRef = useRef<HTMLInputElement>(null)
  const assets = useEditor((s) => s.project.assets)
  const avatar = assets.find((a) => a.id === layer.avatarAssetId)
  return (
    <Section title="Comment">
      <SelectField<CommentVariant>
        label="Style"
        value={layer.variant}
        onChange={(variant) => set({ variant })}
        options={[
          { value: 'card-light', label: 'Card light' },
          { value: 'card-dark', label: 'Card dark' },
          { value: 'tiktok-reply', label: 'TikTok reply bubble' },
        ]}
      />
      <div className="flex items-center gap-3">
        <span className="size-12 shrink-0 overflow-hidden rounded-full bg-secondary">
          {avatar && <img src={avatar.src || '/placeholder.svg'} alt="" className="size-full object-cover" />}
        </span>
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          className="sr-only"
          aria-label="Upload profile picture"
          onChange={async (e) => {
            const file = e.target.files?.[0]
            e.target.value = ''
            if (!file) return
            const asset = await assetFromFile(file)
            if (!asset) return
            const { project } = editor.get()
            editor.setProject({
              ...project,
              assets: [...project.assets, asset],
              layers: project.layers.map((l) => (l.id === layer.id ? { ...l, avatarAssetId: asset.id } : l)),
            })
          }}
        />
        <button type="button" onClick={() => inputRef.current?.click()} className="flex items-center gap-2 rounded-md border border-input bg-secondary px-3 py-1.5 text-xs text-foreground hover:border-primary">
          <Upload className="size-3.5" aria-hidden="true" />
          Profile picture
        </button>
        {avatar && (
          <button type="button" onClick={() => set({ avatarAssetId: null })} className="text-xs text-muted-foreground hover:text-foreground">
            Remove
          </button>
        )}
      </div>
      <TextField label="Comment text" multiline value={layer.text} onChange={(text) => set({ text })} />
      <TextField label={layer.variant === 'tiktok-reply' ? 'Replying to' : 'Display name'} value={layer.author} onChange={(author) => set({ author })} />
      {layer.variant !== 'tiktok-reply' && (
        <>
          <TextField label="Handle" value={layer.handle} onChange={(handle) => set({ handle })} />
          <Toggle label="Verified badge" checked={layer.verified} onChange={(verified) => set({ verified })} />
        </>
      )}
    </Section>
  )
}

function StickerSection({ layer, set }: Props<Extract<Layer, { kind: 'sticker' }>>) {
  const hasSub = layer.sticker === 'lower-third' || layer.sticker === 'question'
  return (
    <Section title="Sticker">
      <TextField label="Label" value={layer.label} onChange={(label) => set({ label })} />
      {hasSub && <TextField label="Subtitle" value={layer.sublabel} onChange={(sublabel) => set({ sublabel })} />}
      <div className="grid grid-cols-1 gap-3">
        <ColorField label="Accent" value={layer.color} onChange={(color) => set({ color })} />
        <ColorField label="Text" value={layer.textColor} onChange={(textColor) => set({ textColor })} />
      </div>
    </Section>
  )
}

const FORM_LABELS: Record<FormType, { title: string; body: string; items: string; primary: string; secondary: string }> = {
  'ios-alert': { title: 'Message', body: 'Detail', items: '', primary: 'Button', secondary: 'Second button' },
  airdrop: { title: 'Title', body: 'Message', items: '', primary: 'Accept', secondary: 'Decline' },
  notes: { title: 'Headline', body: 'Second line', items: '', primary: 'Back label', secondary: '' },
  'google-search': { title: 'Search query', body: '', items: 'Suggestions (one per line)', primary: '', secondary: '' },
  'context-menu': { title: '', body: '', items: 'Menu rows (--- divider, " >" submenu)', primary: '', secondary: '' },
  'id-badge': { title: 'Caption', body: '', items: '', primary: 'Name', secondary: 'Role' },
  imessage: { title: 'Typed reply', body: 'Incoming message', items: '', primary: 'Date label', secondary: '' },
  'safari-tabs': { title: '', body: '', items: 'Tab titles (one per line)', primary: '', secondary: '' },
}

function FormSection({ layer, set }: Props<Extract<Layer, { kind: 'form' }>>) {
  const labels = FORM_LABELS[layer.form]
  const assets = useEditor((s) => s.project.assets).filter((a) => a.type === 'image')
  const photo = layer.form === 'airdrop' || layer.form === 'id-badge' || layer.form === 'safari-tabs'
  return (
    <Section title={FORM_NAMES[layer.form]}>
      <p className="text-xs leading-relaxed text-muted-foreground">Wrap words in *asterisks* to paint them in the accent color.</p>
      {labels.title && <TextField label={labels.title} value={layer.title} multiline onChange={(title) => set({ title })} />}
      {labels.body && <TextField label={labels.body} value={layer.body} multiline onChange={(body) => set({ body })} />}
      {labels.items && (
        <TextField label={labels.items} value={layer.items.join('\n')} multiline onChange={(v) => set({ items: v.split('\n') })} />
      )}
      {labels.primary && <TextField label={labels.primary} value={layer.primary} onChange={(primary) => set({ primary })} />}
      {labels.secondary && <TextField label={labels.secondary} value={layer.secondary} onChange={(secondary) => set({ secondary })} />}
      {layer.form === 'context-menu' && (
        <NumberField label="Highlighted row" value={layer.highlight} min={-1} step={1} onChange={(highlight) => set({ highlight: Math.round(highlight) })} />
      )}
      {photo && (
        <SelectField<string>
          label="Photo"
          value={layer.imageAssetId ?? ''}
          onChange={(v) => set({ imageAssetId: v || null })}
          options={[{ value: '', label: 'None' }, ...assets.map((a) => ({ value: a.id, label: a.name }))]}
        />
      )}
      <ColorField label="Accent" value={layer.accent} onChange={(accent) => set({ accent })} />
      <ColorField label="Surface" value={layer.surface} onChange={(surface) => set({ surface })} />
      <ColorField label="Text" value={layer.textColor} onChange={(textColor) => set({ textColor })} />
    </Section>
  )
}

function MediaSection({ layer, set }: Props<Extract<Layer, { kind: 'media' }>>) {
  const asset = useEditor((s) => s.project.assets.find((a) => a.id === layer.assetId))
  return (
    <Section title={asset?.type === 'video' ? 'Video' : 'Image'}>
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => {
            if (!asset) return
            const { project } = editor.get()
            const fit = createMedia(project, layer.start, asset)
            set({ x: fit.x, y: fit.y, width: fit.width, height: fit.height, rotation: 0 })
          }}
          className="flex flex-1 items-center justify-center gap-2 rounded-md border border-input bg-secondary py-1.5 text-xs text-foreground hover:border-primary"
        >
          <Maximize className="size-3.5" aria-hidden="true" />
          Fill canvas
        </button>
        <button
          type="button"
          aria-pressed={layer.flipX}
          onClick={() => set({ flipX: !layer.flipX })}
          className={cn('flex flex-1 items-center justify-center gap-2 rounded-md border bg-secondary py-1.5 text-xs text-foreground', layer.flipX ? 'border-primary' : 'border-input hover:border-primary')}
        >
          <FlipHorizontal className="size-3.5" aria-hidden="true" />
          Mirror
        </button>
      </div>
      <NumberField label="Corner radius" value={layer.radius} min={0} onChange={(radius) => set({ radius: Math.max(0, radius) })} />
      {asset?.type === 'video' && (
        <>
          <NumberField label="Trim start" value={layer.trimStart} step={0.1} min={0} suffix="s" onChange={(trimStart) => set({ trimStart: Math.max(0, trimStart) })} />
          <RangeField label="Volume" value={layer.volume} onChange={(volume) => set({ volume })} format={(v) => `${Math.round(v * 100)}%`} />
          <Toggle label="Mute" checked={layer.muted} onChange={(muted) => set({ muted })} />
        </>
      )}
    </Section>
  )
}

function AudioSection({ layer, set }: Props<Extract<Layer, { kind: 'audio' }>>) {
  return (
    <Section title="Audio">
      <RangeField label="Volume" value={layer.volume} onChange={(volume) => set({ volume })} format={(v) => `${Math.round(v * 100)}%`} />
      <div className="grid grid-cols-2 gap-3">
        <NumberField label="Trim start" value={layer.trimStart} step={0.1} min={0} suffix="s" onChange={(trimStart) => set({ trimStart: Math.max(0, trimStart) })} />
        <NumberField label="Fade in" value={layer.fadeIn} step={0.1} min={0} suffix="s" onChange={(fadeIn) => set({ fadeIn: Math.max(0, fadeIn) })} />
        <NumberField label="Fade out" value={layer.fadeOut} step={0.1} min={0} suffix="s" onChange={(fadeOut) => set({ fadeOut: Math.max(0, fadeOut) })} />
      </div>
    </Section>
  )
}

function ShapeSection({ layer, set }: Props<Extract<Layer, { kind: 'shape' }>>) {
  const progress = layer.shape === 'progress'
  return (
    <Section title={progress ? 'Progress bar' : 'Shape'}>
      <ColorField label={progress ? 'Fill' : 'Fill'} value={layer.fill} onChange={(fill) => set({ fill })} />
      <ColorField label={progress ? 'Track' : 'Outline'} value={layer.stroke} onChange={(stroke) => set({ stroke })} />
      <div className="grid grid-cols-2 gap-3">
        {!progress && <NumberField label="Outline width" value={layer.strokeWidth} min={0} onChange={(strokeWidth) => set({ strokeWidth: Math.max(0, strokeWidth) })} />}
        {(layer.shape === 'rect' || progress) && <NumberField label="Radius" value={layer.radius} min={0} onChange={(radius) => set({ radius: Math.max(0, radius) })} />}
      </div>
    </Section>
  )
}

function EffectSection({ layer, set }: Props<Extract<Layer, { kind: 'effect' }>>) {
  return (
    <Section title="Effect">
      <RangeField label="Intensity" value={layer.intensity} max={2} onChange={(intensity) => set({ intensity })} />
      {(layer.effect === 'tint' || layer.effect === 'flash') && <ColorField label="Color" value={layer.color} onChange={(color) => set({ color })} />}
      <p className="text-xs leading-relaxed text-muted-foreground">Effects apply to every layer below them in the stack. Use Arrange to change what they affect.</p>
    </Section>
  )
}

function AnimateTab({ layer, set }: Props) {
  return (
    <>
      <Section title="In">
        <SelectField
          label="Animation"
          value={layer.animIn?.type ?? 'none'}
          onChange={(v) => set({ animIn: v === 'none' ? null : { type: v, duration: layer.animIn?.duration ?? 0.5 } })}
          options={[{ value: 'none', label: 'None' }, ...ANIM_IN.map((a) => ({ value: a.id, label: a.name }))]}
        />
        {layer.animIn && (
          <RangeField label="Duration" value={layer.animIn.duration} min={0.1} max={3} onChange={(duration) => set({ animIn: { ...layer.animIn!, duration } })} format={(v) => `${v.toFixed(1)}s`} />
        )}
      </Section>
      <Section title="Out">
        <SelectField
          label="Animation"
          value={layer.animOut?.type ?? 'none'}
          onChange={(v) => set({ animOut: v === 'none' ? null : { type: v, duration: layer.animOut?.duration ?? 0.4 } })}
          options={[{ value: 'none', label: 'None' }, ...ANIM_OUT.map((a) => ({ value: a.id, label: a.name }))]}
        />
        {layer.animOut && (
          <RangeField label="Duration" value={layer.animOut.duration} min={0.1} max={3} onChange={(duration) => set({ animOut: { ...layer.animOut!, duration } })} format={(v) => `${v.toFixed(1)}s`} />
        )}
      </Section>
      <Section title="Loop">
        <SelectField
          label="Animation"
          value={layer.loop?.type ?? 'none'}
          onChange={(v) => set({ loop: v === 'none' ? null : { type: v, speed: layer.loop?.speed ?? 1 } })}
          options={[{ value: 'none', label: 'None' }, ...LOOPS.map((a) => ({ value: a.id, label: a.name }))]}
        />
        {layer.loop && <RangeField label="Speed" value={layer.loop.speed} min={0.25} max={3} onChange={(speed) => set({ loop: { ...layer.loop!, speed } })} format={(v) => `${v.toFixed(2)}x`} />}
      </Section>
      <p className="px-4 py-3 text-xs leading-relaxed text-muted-foreground">Browse live previews of every animation in the Motion library tab.</p>
    </>
  )
}

function AdjustTab({ layer, set }: Props) {
  const a = layer.adjust
  const adj = (patch: Partial<typeof a>) => set({ adjust: { ...a, ...patch } })
  return (
    <>
      <Section title="Perspective">
        <SelectField<WarpType> label="Warp" value={layer.warp} onChange={(warp) => set({ warp })} options={WARPS} />
        {layer.warp !== 'none' && <RangeField label="Amount" value={layer.warpAmount} max={0.6} onChange={(warpAmount) => set({ warpAmount })} />}
      </Section>
      <Section title="Filter">
        <SelectField label="Look" value={layer.filter} onChange={(filter) => set({ filter })} options={FILTERS.map((f) => ({ value: f.id, label: f.name }))} />
      </Section>
      <Section
        title="Adjust"
        action={
          <button type="button" onClick={() => set({ adjust: { ...DEFAULT_ADJUST } })} className="text-xs text-primary hover:underline">
            Reset
          </button>
        }
      >
        <RangeField label="Brightness" value={a.brightness} min={0.3} max={1.8} onChange={(brightness) => adj({ brightness })} />
        <RangeField label="Contrast" value={a.contrast} min={0.3} max={2} onChange={(contrast) => adj({ contrast })} />
        <RangeField label="Saturation" value={a.saturate} min={0} max={3} onChange={(saturate) => adj({ saturate })} />
        <RangeField label="Hue" value={a.hue} min={-180} max={180} step={1} onChange={(hue) => adj({ hue })} format={(v) => `${Math.round(v)}°`} />
        <RangeField label="Blur" value={a.blur} min={0} max={20} step={0.5} onChange={(blur) => adj({ blur })} format={(v) => `${v.toFixed(1)}px`} />
      </Section>
    </>
  )
}
