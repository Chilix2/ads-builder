'use client'

import { useEffect, useRef, useState, type ReactNode } from 'react'
import { AudioLines, Captions, Loader2, Mic, Music, Square, Upload, Wand2 } from 'lucide-react'
import { assetFromFile } from '@/lib/editor/assets'
import { CAPTION_STYLES, buildCaptionLayers, wordsFromTranscript, type CaptionStyleId, type Transcript } from '@/lib/editor/captions'
import { createAudio } from '@/lib/editor/factory'
import { playback } from '@/lib/editor/playback'
import { editor, useEditor } from '@/lib/editor/store'
import type { Asset, LayerOrigin } from '@/lib/editor/types'
import { cn } from '@/lib/utils'

const VOICES = [
  { id: 'nova', name: 'Nova — bright, upbeat' },
  { id: 'shimmer', name: 'Shimmer — soft, warm' },
  { id: 'coral', name: 'Coral — friendly creator' },
  { id: 'alloy', name: 'Alloy — neutral' },
  { id: 'echo', name: 'Echo — calm male' },
  { id: 'onyx', name: 'Onyx — deep narrator' },
  { id: 'fable', name: 'Fable — storyteller' },
  { id: 'ash', name: 'Ash — confident' },
  { id: 'sage', name: 'Sage — measured' },
]

function Group({ title, hint, icon, children }: { title: string; hint?: string; icon: ReactNode; children: ReactNode }) {
  return (
    <section className="flex flex-col gap-3 border-b border-border px-3 py-4">
      <div className="flex items-start gap-2">
        <span className="mt-0.5 text-primary">{icon}</span>
        <div className="flex flex-col gap-0.5">
          <h2 className="text-sm font-semibold text-foreground">{title}</h2>
          {hint && <p className="text-xs leading-relaxed text-muted-foreground">{hint}</p>}
        </div>
      </div>
      {children}
    </section>
  )
}

const fieldCls = 'w-full rounded-md border border-input bg-secondary px-2.5 py-2 text-sm text-foreground focus:border-primary focus:outline-none'
const btnCls =
  'flex items-center justify-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50'

async function fileToAsset(file: File) {
  const asset = await assetFromFile(file)
  if (!asset) throw new Error('Unsupported file')
  return asset
}

function addAudio(asset: Asset, origin: LayerOrigin) {
  const { project } = editor.get()
  const layer = { ...createAudio(project, playback.get().time, asset), origin, name: asset.name }
  editor.setProject({ ...project, assets: [...project.assets, asset], layers: [...project.layers, layer] })
  editor.select(layer.id)
  return layer
}

async function requestTranscript(blob: Blob, name: string): Promise<Transcript> {
  const form = new FormData()
  form.append('file', blob, name)
  const res = await fetch('/api/transcribe', { method: 'POST', body: form })
  const data = await res.json()
  if (!res.ok) throw new Error(data.error ?? 'Transcription failed')
  return data as Transcript
}

function insertCaptions(t: Transcript, style: CaptionStyleId, offset: number) {
  const words = wordsFromTranscript(t)
  if (!words.length) throw new Error('No speech detected')
  const { project } = editor.get()
  editor.addLayers(buildCaptionLayers(project, words, style, offset), false)
  return words.length
}

function CaptionsSection() {
  const layers = useEditor((s) => s.project.layers)
  const assets = useEditor((s) => s.project.assets)
  const sources = layers.filter((l) => {
    if (l.kind === 'audio') return true
    if (l.kind !== 'media') return false
    return assets.find((a) => a.id === l.assetId)?.type === 'video'
  })
  const [sourceId, setSourceId] = useState('')
  const [style, setStyle] = useState<CaptionStyleId>('karaoke')
  const [status, setStatus] = useState<{ busy: boolean; msg: string; error?: boolean }>({ busy: false, msg: '' })
  const active = sources.find((s) => s.id === sourceId) ?? sources[0]

  const run = async () => {
    if (!active || (active.kind !== 'audio' && active.kind !== 'media')) return
    const asset = assets.find((a) => a.id === active.assetId)
    if (!asset) return
    setStatus({ busy: true, msg: 'Transcribing speech…' })
    try {
      const blob = await (await fetch(asset.src)).blob()
      const t = await requestTranscript(blob, asset.name)
      const count = insertCaptions(t, style, active.start - active.trimStart)
      setStatus({ busy: false, msg: `Added captions for ${count} words.` })
    } catch (e) {
      setStatus({ busy: false, msg: e instanceof Error ? e.message : 'Failed', error: true })
    }
  }

  return (
    <Group
      title="Auto captions"
      hint="Speech-to-text with word timing. Mirrors TikTok “Captions” and Instagram Edits “Captions” — both reward using their native captions, so the rebuild guide tells you to regenerate them in-app."
      icon={<Captions className="size-4" aria-hidden="true" />}
    >
      {sources.length === 0 ? (
        <p className="rounded-md bg-secondary px-3 py-2 text-xs leading-relaxed text-muted-foreground">
          Add a video with speech, a voiceover or a generated voice first.
        </p>
      ) : (
        <>
          <label className="flex flex-col gap-1 text-xs text-muted-foreground">
            Source clip
            <select className={fieldCls} value={active?.id} onChange={(e) => setSourceId(e.target.value)}>
              {sources.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </label>
          <fieldset className="flex flex-col gap-1.5">
            <legend className="mb-1 text-xs text-muted-foreground">Caption style</legend>
            <div className="grid grid-cols-2 gap-1.5">
              {CAPTION_STYLES.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  aria-pressed={style === s.id}
                  onClick={() => setStyle(s.id)}
                  className={cn(
                    'rounded-md border px-2 py-1.5 text-left text-xs transition-colors',
                    style === s.id ? 'border-primary bg-accent text-foreground' : 'border-border text-muted-foreground hover:text-foreground',
                  )}
                >
                  {s.name}
                </button>
              ))}
            </div>
          </fieldset>
          <button type="button" className={btnCls} disabled={status.busy} onClick={run}>
            {status.busy ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <Wand2 className="size-4" aria-hidden="true" />}
            Generate captions
          </button>
        </>
      )}
      {status.msg && (
        <p role="status" className={cn('text-xs', status.error ? 'text-destructive' : 'text-muted-foreground')}>
          {status.msg}
        </p>
      )}
    </Group>
  )
}

function VoiceSection() {
  const [text, setText] = useState('Wait — you are editing your Reels the hard way. Here is the trick nobody tells you.')
  const [voice, setVoice] = useState('nova')
  const [speed, setSpeed] = useState(1)
  const [caption, setCaption] = useState(true)
  const [status, setStatus] = useState<{ busy: boolean; msg: string; error?: boolean }>({ busy: false, msg: '' })

  const run = async () => {
    setStatus({ busy: true, msg: 'Generating voice…' })
    try {
      const res = await fetch('/api/speech', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, voice, speed }),
      })
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error ?? 'Voice generation failed')
      const blob = await res.blob()
      const file = new File([blob], `Voice · ${voice}.mp3`, { type: blob.type || 'audio/mpeg' })
      const asset = await fileToAsset(file)
      const layer = addAudio(asset, 'tts')
      if (caption) {
        setStatus({ busy: true, msg: 'Timing captions to the voice…' })
        const t = await requestTranscript(blob, file.name)
        insertCaptions(t, 'karaoke', layer.start)
      }
      setStatus({ busy: false, msg: caption ? 'Voice and captions added.' : 'Voice added at the playhead.' })
    } catch (e) {
      setStatus({ busy: false, msg: e instanceof Error ? e.message : 'Failed', error: true })
    }
  }

  return (
    <Group
      title="Text to speech"
      hint="Like TikTok “Text-to-speech” and Instagram “Voice effects → Text to speech”. Generated here for timing; the guide recreates it with the in-app voice."
      icon={<AudioLines className="size-4" aria-hidden="true" />}
    >
      <label className="flex flex-col gap-1 text-xs text-muted-foreground">
        Script
        <textarea className={cn(fieldCls, 'min-h-24 resize-y leading-relaxed')} value={text} maxLength={4000} onChange={(e) => setText(e.target.value)} />
      </label>
      <div className="flex gap-2">
        <label className="flex flex-1 flex-col gap-1 text-xs text-muted-foreground">
          Voice
          <select className={fieldCls} value={voice} onChange={(e) => setVoice(e.target.value)}>
            {VOICES.map((v) => (
              <option key={v.id} value={v.id}>
                {v.name}
              </option>
            ))}
          </select>
        </label>
        <label className="flex w-24 flex-col gap-1 text-xs text-muted-foreground">
          Speed {speed.toFixed(2)}x
          <input type="range" min={0.5} max={2} step={0.05} value={speed} onChange={(e) => setSpeed(Number(e.target.value))} className="mt-2 accent-primary" />
        </label>
      </div>
      <label className="flex items-center gap-2 text-xs text-muted-foreground">
        <input type="checkbox" checked={caption} onChange={(e) => setCaption(e.target.checked)} className="accent-primary" />
        Also add karaoke captions
      </label>
      <button type="button" className={btnCls} disabled={status.busy || !text.trim()} onClick={run}>
        {status.busy ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <Wand2 className="size-4" aria-hidden="true" />}
        Generate voice
      </button>
      {status.msg && (
        <p role="status" className={cn('text-xs', status.error ? 'text-destructive' : 'text-muted-foreground')}>
          {status.msg}
        </p>
      )}
    </Group>
  )
}

function RecordSection() {
  const [recording, setRecording] = useState(false)
  const [seconds, setSeconds] = useState(0)
  const [error, setError] = useState('')
  const recRef = useRef<MediaRecorder | null>(null)

  useEffect(() => {
    if (!recording) return
    const id = setInterval(() => setSeconds((s) => s + 1), 1000)
    return () => clearInterval(id)
  }, [recording])

  const start = async () => {
    setError('')
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const rec = new MediaRecorder(stream)
      const chunks: Blob[] = []
      rec.ondataavailable = (e) => e.data.size && chunks.push(e.data)
      rec.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop())
        const blob = new Blob(chunks, { type: rec.mimeType || 'audio/webm' })
        const asset = await fileToAsset(new File([blob], `Voiceover ${new Date().toLocaleTimeString()}.webm`, { type: blob.type }))
        addAudio(asset, 'voiceover')
      }
      recRef.current = rec
      rec.start()
      setSeconds(0)
      setRecording(true)
    } catch {
      setError('Microphone access was blocked. Allow it in the browser and try again.')
    }
  }

  const stop = () => {
    recRef.current?.stop()
    setRecording(false)
  }

  return (
    <Group
      title="Voiceover"
      hint="Record over the timeline from the playhead — same as the Voiceover button in both editors."
      icon={<Mic className="size-4" aria-hidden="true" />}
    >
      <button
        type="button"
        onClick={recording ? stop : start}
        className={cn(btnCls, recording && 'bg-destructive text-destructive-foreground')}
        aria-pressed={recording}
      >
        {recording ? <Square className="size-4" aria-hidden="true" /> : <Mic className="size-4" aria-hidden="true" />}
        {recording ? `Stop · ${seconds}s` : 'Record voiceover'}
      </button>
      {error && (
        <p role="alert" className="text-xs text-destructive">
          {error}
        </p>
      )}
    </Group>
  )
}

function MusicSection() {
  const allAssets = useEditor((s) => s.project.assets)
  const assets = allAssets.filter((a) => a.type === 'audio')
  const inputRef = useRef<HTMLInputElement>(null)
  return (
    <Group
      title="Music & sounds"
      hint="Use your own track for timing. On export the guide maps it to the native sound library — trending in-app audio is what boosts reach, so pick the original sound there."
      icon={<Music className="size-4" aria-hidden="true" />}
    >
      <input
        ref={inputRef}
        type="file"
        accept="audio/*"
        className="sr-only"
        aria-label="Upload music"
        onChange={async (e) => {
          const f = e.target.files?.[0]
          e.target.value = ''
          if (f) addAudio(await fileToAsset(f), 'music')
        }}
      />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        className="flex items-center justify-center gap-2 rounded-md border border-dashed border-input px-3 py-3 text-sm text-foreground transition-colors hover:border-primary"
      >
        <Upload className="size-4 text-primary" aria-hidden="true" />
        Upload music
      </button>
      {assets.length > 0 && (
        <ul className="flex flex-col gap-1">
          {assets.map((a) => (
            <li key={a.id}>
              <button
                type="button"
                onClick={() => addAudio({ ...a }, 'music')}
                className="flex w-full items-center gap-2 rounded-md bg-secondary px-2.5 py-2 text-left text-xs text-foreground hover:bg-accent"
              >
                <AudioLines className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                <span className="flex-1 truncate">{a.name}</span>
                <span className="text-muted-foreground">{a.duration.toFixed(1)}s</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </Group>
  )
}

export function AudioPanel() {
  return (
    <div className="flex flex-col">
      <CaptionsSection />
      <VoiceSection />
      <RecordSection />
      <MusicSection />
    </div>
  )
}
