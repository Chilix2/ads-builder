'use client'

import { useMemo, useRef, useState, type DragEvent, type ReactNode } from 'react'
import {
  AudioLines,
  Clapperboard,
  Film,
  Image as ImageIcon,
  LayoutTemplate,
  ScanSearch,
  Mic,
  Shapes,
  Sparkles,
  Type,
  Upload,
  Wand2,
  Waves,
} from 'lucide-react'
import { DRAG_MIME, applyTemplate, getEffectItem, importFiles, insertAsset, insertItemById } from '@/lib/editor/actions'
import { COMMENTS, FORMS, FRAMES, HOOKS, TEXT_FORMS, SHAPES, STICKERS, TEMPLATES, TEXT_STYLES, toolIdForItem, type LibraryItem } from '@/lib/editor/library'
import { AVAILABILITY_LABEL, TOOL_BY_ID, availabilityOf } from '@/lib/editor/platform-tools'
import { ANIM_IN, ANIM_OUT, EFFECTS, FILTERS, LOOPS } from '@/lib/editor/presets'
import { editor, useEditor, useSelectedLayer } from '@/lib/editor/store'
import type { Asset, Project } from '@/lib/editor/types'
import { cn } from '@/lib/utils'
import { AudioPanel } from './audio-panel'
import { AutoCutTemplates, ExtractTab, SavedElements } from './extract-panel'
import { AnimPreview, LayerThumb } from './layer-thumb'

const TABS = [
  { id: 'templates', label: 'Templates', icon: LayoutTemplate },
  { id: 'media', label: 'Media', icon: ImageIcon },
  { id: 'text', label: 'Text', icon: Type },
  { id: 'elements', label: 'Elements', icon: Shapes },
  { id: 'extract', label: 'Extract', icon: ScanSearch },
  { id: 'audio', label: 'Audio', icon: Mic },
  { id: 'effects', label: 'Effects', icon: Sparkles },
  { id: 'filters', label: 'Filters', icon: Wand2 },
  { id: 'motion', label: 'Motion', icon: Waves },
] as const

type TabId = (typeof TABS)[number]['id']

function onDragItem(e: DragEvent, id: string) {
  e.dataTransfer.setData(DRAG_MIME, id)
  e.dataTransfer.effectAllowed = 'copy'
}

export { Group, ItemGrid, useThumbProject }

export function LibraryPanel() {
  const [tab, setTab] = useState<TabId>('templates')
  return (
    <div className="flex h-full min-h-0">
      <nav aria-label="Library" className="scroll-thin flex min-h-0 w-16 shrink-0 flex-col items-center justify-between gap-0 overflow-y-auto border-r border-border bg-sidebar py-1">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            aria-current={tab === t.id ? 'page' : undefined}
            className={cn(
              'flex w-14 shrink-0 flex-col items-center gap-px rounded-md py-0.5 text-[10px] leading-3 font-medium transition-colors',
              tab === t.id ? 'bg-accent text-primary' : 'text-muted-foreground hover:bg-secondary hover:text-foreground',
            )}
          >
            <t.icon className="size-3.5" aria-hidden="true" />
            {t.label}
          </button>
        ))}
      </nav>
      <div className="scroll-thin flex min-h-0 w-72 flex-col overflow-y-auto bg-card">
        {tab === 'templates' && <TemplatesTab />}
        {tab === 'media' && <MediaTab />}
        {tab === 'text' && <TextTab />}
        {tab === 'elements' && <ElementsTab />}
        {tab === 'extract' && <ExtractTab />}
        {tab === 'audio' && <AudioPanel />}
        {tab === 'effects' && <EffectsTab />}
        {tab === 'filters' && <FiltersTab />}
        {tab === 'motion' && <MotionTab />}
      </div>
    </div>
  )
}

function Group({ title, hint, children }: { title: string; hint?: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-3 px-3 py-4">
      <div className="flex flex-col gap-0.5">
        <h2 className="text-sm font-semibold text-foreground">{title}</h2>
        {hint && <p className="text-xs leading-relaxed text-muted-foreground">{hint}</p>}
      </div>
      {children}
    </div>
  )
}

function useThumbProject(): Project {
  const format = useEditor((s) => s.project.format)
  const width = useEditor((s) => s.project.width)
  const height = useEditor((s) => s.project.height)
  const assets = useEditor((s) => s.project.assets)
  return useMemo(() => ({ version: 1, name: '', format, width, height, background: '#000', layers: [], assets }), [format, width, height, assets])
}

function ItemCard({ item, project, dark = true }: { item: LibraryItem; project: Project; dark?: boolean }) {
  const layers = useMemo(() => item.build(project, 0), [item, project])
  return (
    <button
      type="button"
      draggable
      onDragStart={(e) => onDragItem(e, item.id)}
      onClick={() => insertItemById(item.id)}
      className="group flex flex-col gap-1.5 text-left"
      title={`Add ${item.name} — or drag onto the canvas`}
    >
      <span
        className={cn(
          'flex w-full items-center justify-center overflow-hidden rounded-md border border-border transition-colors group-hover:border-primary',
          dark ? 'bg-stage' : 'bg-muted-foreground',
        )}
      >
        <LayerThumb project={project} layers={layers} width={200} height={130} />
      </span>
      <span className="flex items-center gap-1.5">
        <span className="min-w-0 flex-1 truncate text-xs text-muted-foreground group-hover:text-foreground">{item.name}</span>
        <AvailabilityBadge itemId={item.id} />
      </span>
    </button>
  )
}

function AvailabilityBadge({ itemId }: { itemId: string }) {
  const toolId = toolIdForItem(itemId)
  if (!toolId) return null
  const a = availabilityOf(toolId)
  const tool = TOOL_BY_ID.get(toolId)
  return (
    <span
      title={tool ? `Native: ${tool.name}` : 'Add as photo overlay'}
      className={cn(
        'shrink-0 rounded px-1 py-px text-[9px] font-semibold',
        a === 'both' ? 'bg-primary/15 text-primary' : a === 'instagram' || a === 'tiktok' ? 'bg-chart-4/20 text-chart-4' : 'bg-secondary text-muted-foreground',
      )}
    >
      {toolId === 'sticker-photo' ? 'PNG' : AVAILABILITY_LABEL[a]}
    </span>
  )
}

function ItemGrid({ items }: { items: LibraryItem[] }) {
  const project = useThumbProject()
  return (
    <div className="grid grid-cols-2 gap-3">
      {items.map((i) => (
        <ItemCard key={i.id} item={i} project={project} />
      ))}
    </div>
  )
}

function TemplatesTab() {
  return (
    <>
    <AutoCutTemplates />
    <Group title="Scenes" hint="Complete scenes with footage, captions, effects and motion. Applying one replaces the current layers (undo with Ctrl+Z).">
      <div className="flex flex-col gap-3">
        {TEMPLATES.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => applyTemplate(t.id)}
            className="group flex gap-3 rounded-lg border border-border bg-secondary p-2 text-left transition-colors hover:border-primary"
          >
            <img src={t.cover || '/placeholder.svg'} alt="" className="h-20 w-14 shrink-0 rounded object-cover" />
            <span className="flex min-w-0 flex-col gap-1 py-1">
              <span className="text-sm font-semibold text-foreground">{t.name}</span>
              <span className="text-xs leading-relaxed text-muted-foreground">{t.description}</span>
            </span>
          </button>
        ))}
      </div>
    </Group>
    </>
  )
}

function AssetTile({ asset }: { asset: Asset }) {
  const selected = useSelectedLayer()
  const Icon = asset.type === 'video' ? Film : asset.type === 'audio' ? AudioLines : ImageIcon
  return (
    <div className="group relative flex flex-col gap-1">
      <button
        type="button"
        draggable={asset.type !== 'audio'}
        onDragStart={(e) => onDragItem(e, `asset:${asset.id}`)}
        onClick={() => insertAsset(asset)}
        className="relative flex aspect-[3/4] items-center justify-center overflow-hidden rounded-md border border-border bg-stage transition-colors hover:border-primary"
        title={`Add ${asset.name} to the timeline`}
      >
        {asset.type === 'image' && <img src={asset.src || '/placeholder.svg'} alt="" className="size-full object-cover" />}
        {asset.type === 'video' && <video src={asset.src} muted preload="metadata" className="size-full object-cover" />}
        {asset.type === 'audio' && <AudioLines className="size-8 text-muted-foreground" aria-hidden="true" />}
        <span className="absolute left-1 top-1 flex items-center gap-1 rounded bg-background/80 px-1 py-0.5 text-[10px] text-foreground">
          <Icon className="size-3" aria-hidden="true" />
          {asset.type === 'image' ? 'IMG' : `${asset.duration.toFixed(1)}s`}
        </span>
      </button>
      <span className="truncate text-[11px] text-muted-foreground">{asset.name}</span>
      {selected?.kind === 'comment' && asset.type === 'image' && (
        <button
          type="button"
          onClick={() => editor.updateLayer(selected.id, { avatarAssetId: asset.id })}
          className="absolute inset-x-1 bottom-6 rounded bg-primary py-1 text-[10px] font-semibold text-primary-foreground opacity-0 transition-opacity group-hover:opacity-100 focus:opacity-100"
        >
          Use as avatar
        </button>
      )}
    </div>
  )
}

function MediaTab() {
  const assets = useEditor((s) => s.project.assets)
  const inputRef = useRef<HTMLInputElement>(null)
  const [over, setOver] = useState(false)
  return (
    <Group title="Media" hint="Upload video, images or music. Click to add at the playhead, or drag onto the canvas.">
      <input
        ref={inputRef}
        type="file"
        accept="image/*,video/*,audio/*"
        multiple
        className="sr-only"
        aria-label="Upload media files"
        onChange={(e) => {
          if (e.target.files) void importFiles(e.target.files)
          e.target.value = ''
        }}
      />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault()
          setOver(true)
        }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => {
          e.preventDefault()
          setOver(false)
          if (e.dataTransfer.files.length) void importFiles(e.dataTransfer.files)
        }}
        className={cn(
          'flex flex-col items-center gap-2 rounded-lg border border-dashed px-4 py-6 text-center transition-colors',
          over ? 'border-primary bg-accent' : 'border-input hover:border-primary',
        )}
      >
        <Upload className="size-6 text-primary" aria-hidden="true" />
        <span className="text-sm font-medium text-foreground">Upload or drop files</span>
        <span className="text-xs text-muted-foreground">MP4, MOV, WEBM, JPG, PNG, MP3, WAV</span>
      </button>
      <div className="grid grid-cols-3 gap-2">
        {[...assets].reverse().map((a) => (
          <AssetTile key={a.id} asset={a} />
        ))}
      </div>
    </Group>
  )
}

function TextTab() {
  return (
    <>
      <Group title="Text forms" hint="Text inside a UI shape. Edit the words in the inspector; wrap a word in *asterisks* to color it.">
        <ItemGrid items={TEXT_FORMS} />
      </Group>
      <Group title="Hooks" hint="Opening lines with motion already applied.">
        <ItemGrid items={HOOKS} />
      </Group>
      <Group title="Text styles">
        <ItemGrid items={TEXT_STYLES} />
      </Group>
    </>
  )
}

const ELEMENT_GROUPS = [
  { id: 'all', label: 'All' },
  { id: 'forms', label: 'UI forms' },
  { id: 'comments', label: 'Comments' },
  { id: 'stickers', label: 'Stickers' },
  { id: 'frames', label: 'Frames' },
  { id: 'shapes', label: 'Shapes' },
] as const

function ElementsTab() {
  const [group, setGroup] = useState<(typeof ELEMENT_GROUPS)[number]['id']>('all')
  const [query, setQuery] = useState('')
  const q = query.trim().toLowerCase()
  const match = (items: LibraryItem[]) => (q ? items.filter((i) => i.name.toLowerCase().includes(q)) : items)
  const sections = [
    { id: 'forms', title: 'UI forms', hint: 'Alerts, AirDrop, search bars, menus, badges. Every text and color is editable.', items: match(FORMS) },
    { id: 'comments', title: 'Comment cards', hint: 'Edit name, handle, avatar and text in the inspector.', items: match(COMMENTS) },
    { id: 'stickers', title: 'Stickers', hint: 'CTAs, polls, quizzes, badges and interactive boxes.', items: match(STICKERS) },
    { id: 'frames', title: 'Frames', hint: 'Polaroid, film, phone and border frames for photos and slides.', items: match(FRAMES) },
    { id: 'shapes', title: 'Shapes', hint: undefined, items: match(SHAPES) },
  ].filter((s) => (group === 'all' || s.id === group) && s.items.length)
  return (
    <>
      <div className="sticky top-0 z-10 flex flex-col gap-2 border-b border-border bg-card px-3 py-3">
        <label className="sr-only" htmlFor="element-search">
          Search elements
        </label>
        <input
          id="element-search"
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={`Search ${FORMS.length + COMMENTS.length + STICKERS.length + FRAMES.length + SHAPES.length} elements`}
          className="h-8 rounded-md border border-input bg-background px-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
        />
        <div className="flex flex-wrap gap-1" role="tablist" aria-label="Element type">
          {ELEMENT_GROUPS.map((g) => (
            <button
              key={g.id}
              type="button"
              role="tab"
              aria-selected={group === g.id}
              onClick={() => setGroup(g.id)}
              className={cn(
                'rounded-full px-2.5 py-1 text-xs font-medium transition-colors',
                group === g.id ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground',
              )}
            >
              {g.label}
            </button>
          ))}
        </div>
      </div>
      {group === 'all' && !q && <SavedElements />}
      {sections.map((s) => (
        <Group key={s.id} title={s.title} hint={s.hint}>
          <ItemGrid items={s.items} />
        </Group>
      ))}
      {!sections.length && <p className="px-3 py-6 text-sm text-muted-foreground">No elements match that search.</p>}
    </>
  )
}

function EffectsTab() {
  return (
    <>
      {(['Camera moves', 'Overlays & transitions'] as const).map((title, gi) => (
        <Group key={title} title={title} hint={gi === 0 ? 'Move every layer beneath the effect in the stack.' : 'Drawn over everything below them.'}>
          <div className="flex flex-col gap-2">
            {EFFECTS.filter((e) => e.camera === (gi === 0)).map((e) => (
              <button
                key={e.id}
                type="button"
                draggable
                onDragStart={(ev) => onDragItem(ev, `effect:${e.id}`)}
                onClick={() => insertItemById(getEffectItem(`effect:${e.id}`)!.id)}
                className="flex items-center gap-3 rounded-md border border-border bg-secondary px-3 py-2.5 text-left transition-colors hover:border-primary"
              >
                {gi === 0 ? <Clapperboard className="size-4 shrink-0 text-primary" aria-hidden="true" /> : <Sparkles className="size-4 shrink-0 text-primary" aria-hidden="true" />}
                <span className="flex min-w-0 flex-col">
                  <span className="text-sm font-medium text-foreground">{e.name}</span>
                  <span className="truncate text-xs text-muted-foreground">{e.description}</span>
                </span>
              </button>
            ))}
          </div>
        </Group>
      ))}
    </>
  )
}

function NeedsSelection({ what }: { what: string }) {
  return <p className="rounded-md border border-dashed border-input px-3 py-4 text-center text-xs leading-relaxed text-muted-foreground">Select a layer on the canvas or timeline to apply {what}.</p>
}

function FiltersTab() {
  const selected = useSelectedLayer()
  const assets = useEditor((s) => s.project.assets)
  const target = selected && selected.kind !== 'audio' && selected.kind !== 'effect' ? selected : null
  const asset = target?.kind === 'media' ? assets.find((a) => a.id === target.assetId) : null
  const src = asset?.type === 'image' ? asset.src : '/samples/street.png'
  return (
    <Group title="Filters" hint="Color looks for the selected layer. Fine-tune in Inspector → Adjust.">
      {!target ? (
        <NeedsSelection what="a filter" />
      ) : (
        <div className="grid grid-cols-3 gap-2">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => editor.updateLayer(target.id, { filter: f.id })}
              aria-pressed={target.filter === f.id}
              className="group flex flex-col gap-1 text-left"
            >
              <span className={cn('overflow-hidden rounded-md border-2 transition-colors', target.filter === f.id ? 'border-primary' : 'border-transparent group-hover:border-input')}>
                <img src={src || '/placeholder.svg'} alt="" className="aspect-square w-full object-cover" style={{ filter: f.css || 'none' }} />
              </span>
              <span className="truncate text-[11px] text-muted-foreground">{f.name}</span>
            </button>
          ))}
        </div>
      )}
    </Group>
  )
}

function MotionTab() {
  const selected = useSelectedLayer()
  const target = selected && selected.kind !== 'audio' ? selected : null
  const groups = [
    { key: 'in' as const, title: 'In', items: ANIM_IN },
    { key: 'out' as const, title: 'Out', items: ANIM_OUT },
    { key: 'loop' as const, title: 'Loop', items: LOOPS },
  ]
  return (
    <>
      {!target && (
        <div className="px-3 pt-4">
          <NeedsSelection what="an animation" />
        </div>
      )}
      {groups.map((g) => {
        const current = target ? (g.key === 'in' ? target.animIn : g.key === 'out' ? target.animOut : target.loop)?.type : undefined
        return (
          <Group key={g.key} title={`${g.title} animations`}>
            <div className="grid grid-cols-3 gap-2">
              {g.items.map((a) => (
                <button
                  key={a.id}
                  type="button"
                  disabled={!target}
                  aria-pressed={current === a.id}
                  onClick={() => {
                    if (!target) return
                    const patch =
                      g.key === 'in'
                        ? { animIn: current === a.id ? null : { type: a.id, duration: target.animIn?.duration ?? 0.5 } }
                        : g.key === 'out'
                          ? { animOut: current === a.id ? null : { type: a.id, duration: target.animOut?.duration ?? 0.4 } }
                          : { loop: current === a.id ? null : { type: a.id, speed: target.loop?.speed ?? 1 } }
                    editor.updateLayer(target.id, patch)
                  }}
                  className={cn(
                    'flex flex-col items-center gap-1.5 rounded-md border bg-secondary px-1 pb-1.5 pt-3 transition-colors disabled:opacity-50',
                    current === a.id ? 'border-primary' : 'border-border hover:border-input',
                  )}
                >
                  <span className="flex h-9 items-center justify-center overflow-hidden">
                    <AnimPreview kind={g.key} type={a.id} />
                  </span>
                  <span className="truncate text-[11px] text-muted-foreground">{a.name}</span>
                </button>
              ))}
            </div>
          </Group>
        )
      })}
    </>
  )
}
