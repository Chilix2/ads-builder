'use client'

import { useMemo, useRef, useState, type ReactNode } from 'react'
import { Bookmark, Loader2, Music2, Plus, ScanSearch, Trash2, Upload } from 'lucide-react'
import type { ExtractedElement } from '@/app/api/extract/route'
import { DRAG_MIME, insertSaved, removeSaved, saveElement } from '@/lib/editor/actions'
import { assetFromFile } from '@/lib/editor/assets'
import { CUT_TEMPLATES, applyCutTemplate, type CutTemplate } from '@/lib/editor/autocut'
import { FORM_NAMES, SAMPLE_ASSETS, createForm, createMedia } from '@/lib/editor/factory'
import { editor, useEditor } from '@/lib/editor/store'
import type { Asset, Layer, Project } from '@/lib/editor/types'
import { cn } from '@/lib/utils'
import { LayerThumb } from './layer-thumb'

const NO_SAVED: NonNullable<Project['saved']> = []

function Section({ title, hint, children }: { title: string; hint?: string; children: ReactNode }) {
  return (
    <section className="flex flex-col gap-3 px-3 py-4">
      <div className="flex flex-col gap-0.5">
        <h2 className="text-sm font-semibold text-foreground">{title}</h2>
        {hint && <p className="text-xs leading-relaxed text-muted-foreground">{hint}</p>}
      </div>
      {children}
    </section>
  )
}

function useThumb(): Project {
  const p = useEditor((s) => s.project)
  return useMemo(() => ({ ...p, layers: [], background: '#000' }), [p])
}

/* ---------- Auto cut templates ---------- */

function BeatStrip({ tpl }: { tpl: CutTemplate }) {
  const beats: number[] = []
  for (let i = 0; i < tpl.shots; i++) beats.push(tpl.pattern[i % tpl.pattern.length])
  return (
    <span className="flex h-6 w-full items-end gap-px" aria-hidden="true">
      {beats.map((b, i) => (
        <span
          key={i}
          className={cn('rounded-sm', i % 2 ? 'bg-primary/60' : 'bg-primary', tpl.cut && i > 0 ? 'border-l-2 border-foreground' : '')}
          style={{ flexGrow: b, height: `${40 + ((i * 37) % 60)}%` }}
        />
      ))}
    </span>
  )
}

export function AutoCutTemplates() {
  const assets = useEditor((s) => s.project.assets)
  const [busy, setBusy] = useState<string | null>(null)
  const [msg, setMsg] = useState<string | null>(null)
  const own = assets.filter((a) => (a.type === 'image' || a.type === 'video') && !SAMPLE_ASSETS.some((s) => s.id === a.id)).length
  const hasMusic = assets.some((a) => a.type === 'audio')
  return (
    <Section
      title="Auto cut"
      hint="Like CapCut AutoCut: your clips are cut to the beat, with transitions, camera moves and a grade. Upload clips in Media first; add music to sync cuts to the real beat."
    >
      <p className="flex items-center gap-1.5 rounded-md bg-secondary px-2 py-1.5 text-xs text-muted-foreground">
        <Music2 className="size-3.5 shrink-0" aria-hidden="true" />
        {own ? `${own} of your clips` : 'Sample clips'} · {hasMusic ? 'beats from your music' : 'template tempo (no music yet)'}
      </p>
      <div className="flex flex-col gap-2">
        {CUT_TEMPLATES.map((t) => (
          <button
            key={t.id}
            type="button"
            disabled={!!busy}
            onClick={async () => {
              setBusy(t.id)
              setMsg(null)
              const r = await applyCutTemplate(t.id)
              setBusy(null)
              setMsg(r ? `${t.name}: ${r.shots} shots, ${r.beatSynced ? 'synced to your music' : `${t.bpm} BPM grid`}. Ctrl+Z to undo.` : 'Add a photo or video first.')
            }}
            className="group flex flex-col gap-2 rounded-lg border border-border bg-secondary p-3 text-left transition-colors hover:border-primary disabled:opacity-60"
          >
            <span className="flex items-center justify-between gap-2">
              <span className="text-sm font-semibold text-foreground">{t.name}</span>
              <span className="flex items-center gap-1 font-mono text-[10px] text-muted-foreground">
                {busy === t.id && <Loader2 className="size-3 animate-spin" aria-hidden="true" />}
                {t.bpm} BPM
              </span>
            </span>
            <BeatStrip tpl={t} />
            <span className="text-xs leading-relaxed text-muted-foreground">{t.description}</span>
          </button>
        ))}
      </div>
      {msg && (
        <p role="status" className="text-xs leading-relaxed text-foreground">
          {msg}
        </p>
      )}
    </Section>
  )
}

/* ---------- Saved elements ---------- */

export function SavedElements() {
  const saved = useEditor((s) => s.project.saved) ?? NO_SAVED
  const project = useThumb()
  if (!saved.length) return null
  return (
    <Section title="My elements" hint="Saved from the extractor or the inspector. Click to add, drag onto the canvas.">
      <div className="grid grid-cols-2 gap-3">
        {saved.map((el) => (
          <div key={el.id} className="group relative flex flex-col gap-1.5">
            <button
              type="button"
              draggable
              onDragStart={(e) => {
                e.dataTransfer.setData(DRAG_MIME, `saved:${el.id}`)
                e.dataTransfer.effectAllowed = 'copy'
              }}
              onClick={() => insertSaved(el.id)}
              className="flex items-center justify-center overflow-hidden rounded-md border border-border bg-stage transition-colors hover:border-primary"
              title={`Add ${el.name}`}
            >
              <LayerThumb project={project} layers={[{ ...el.layer, start: 0 }]} width={200} height={130} />
            </button>
            <span className="truncate text-xs text-muted-foreground">{el.name}</span>
            <button
              type="button"
              onClick={() => removeSaved(el.id)}
              aria-label={`Delete ${el.name}`}
              className="absolute right-1 top-1 rounded bg-background/80 p-1 text-muted-foreground opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100 focus:opacity-100"
            >
              <Trash2 className="size-3.5" aria-hidden="true" />
            </button>
          </div>
        ))}
      </div>
    </Section>
  )
}

/* ---------- Extractor ---------- */

function loadImage(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image()
    img.crossOrigin = 'anonymous'
    img.onload = () => resolve(img)
    img.onerror = reject
    img.src = src
  })
}

/** Crops the box and, optionally, knocks out a plain background sampled from the crop's corners. */
async function cutOut(src: string, box: ExtractedElement['bbox'], knockout: boolean): Promise<File> {
  const img = await loadImage(src)
  const pad = 0.01
  const x = Math.max(0, (box.x - pad) * img.naturalWidth)
  const y = Math.max(0, (box.y - pad) * img.naturalHeight)
  const w = Math.min(img.naturalWidth - x, (box.w + pad * 2) * img.naturalWidth)
  const h = Math.min(img.naturalHeight - y, (box.h + pad * 2) * img.naturalHeight)
  const c = document.createElement('canvas')
  c.width = Math.max(1, Math.round(w))
  c.height = Math.max(1, Math.round(h))
  const ctx = c.getContext('2d', { willReadFrequently: true })!
  ctx.drawImage(img, x, y, w, h, 0, 0, c.width, c.height)
  if (knockout) {
    const d = ctx.getImageData(0, 0, c.width, c.height)
    const px = d.data
    const at = (cx: number, cy: number) => (cy * c.width + cx) * 4
    const corners = [at(0, 0), at(c.width - 1, 0), at(0, c.height - 1), at(c.width - 1, c.height - 1)]
    const bg = [0, 1, 2].map((k) => corners.reduce((a, i) => a + px[i + k], 0) / 4)
    for (let i = 0; i < px.length; i += 4) {
      const dist = Math.hypot(px[i] - bg[0], px[i + 1] - bg[1], px[i + 2] - bg[2])
      if (dist < 38) px[i + 3] = 0
      else if (dist < 60) px[i + 3] = Math.round(((dist - 38) / 22) * 255)
    }
    ctx.putImageData(d, 0, 0)
  }
  const blob = await new Promise<Blob>((r) => c.toBlob((b) => r(b!), 'image/png'))
  return new File([blob], 'cutout.png', { type: 'image/png' })
}

const PHOTO_FORMS = new Set(['airdrop', 'id-badge', 'safari-tabs'])

function buildFormLayer(project: Project, el: ExtractedElement, photo: Asset | null): Layer | null {
  if (!el.form) return null
  return createForm(project, 0, el.form, {
    name: el.name || FORM_NAMES[el.form],
    title: el.title,
    body: el.body,
    items: el.items,
    primary: el.primary,
    secondary: el.secondary,
    accent: el.accent,
    surface: el.surface,
    textColor: el.textColor,
    imageAssetId: PHOTO_FORMS.has(el.form) ? (photo?.id ?? null) : null,
  })
}

function addAsset(a: Asset) {
  const { project } = editor.get()
  editor.setProject({ ...project, assets: [...project.assets, a] })
}

function stickerLayer(project: Project, a: Asset, name: string): Layer {
  const scale = Math.min((project.width * 0.5) / a.width, (project.height * 0.35) / a.height)
  return { ...createMedia(project, 0, a, { duration: 4 }), name, width: Math.round(a.width * scale), height: Math.round(a.height * scale) }
}

export function ExtractTab() {
  const project = useThumb()
  const inputRef = useRef<HTMLInputElement>(null)
  const [source, setSource] = useState<Asset | null>(null)
  const [elements, setElements] = useState<ExtractedElement[]>([])
  const [status, setStatus] = useState<'idle' | 'loading' | 'error'>('idle')
  const [error, setError] = useState('')
  const [knockout, setKnockout] = useState(true)
  const [done, setDone] = useState<Record<number, string>>({})

  async function analyse(file: File) {
    const asset = await assetFromFile(file)
    if (!asset || asset.type !== 'image') return
    addAsset(asset)
    setSource(asset)
    setElements([])
    setDone({})
    setStatus('loading')
    const body = new FormData()
    body.append('image', file)
    const res = await fetch('/api/extract', { method: 'POST', body }).catch(() => null)
    const json = res ? await res.json().catch(() => null) : null
    if (!res?.ok || !json?.elements) {
      setStatus('error')
      setError(json?.error ?? 'Extraction failed. Try another image.')
      return
    }
    setElements(json.elements)
    setStatus('idle')
  }

  async function materialise(el: ExtractedElement, mode: 'add' | 'save' | 'cutout', i: number) {
    if (!source) return
    const p = editor.get().project
    let layer: Layer | null = null
    if (el.kind === 'form' && mode !== 'cutout') layer = buildFormLayer(p, el, source)
    if (!layer) {
      const file = await cutOut(source.src, el.bbox, el.kind === 'sticker' && knockout)
      const a = await assetFromFile(new File([file], `${el.name || 'sticker'}.png`, { type: 'image/png' }))
      if (!a) return
      addAsset(a)
      layer = stickerLayer(editor.get().project, a, el.name || 'Sticker')
    }
    if (mode === 'save') {
      saveElement(layer, el.name || layer.name)
      setDone((d) => ({ ...d, [i]: 'Saved to My elements' }))
    } else {
      editor.addLayers([layer])
      setDone((d) => ({ ...d, [i]: 'Added to canvas' }))
    }
  }

  return (
    <>
      <Section
        title="Extractor"
        hint="Drop a post or screenshot. AI finds the UI forms (alerts, search bars, menus, cards) and the objects, and turns them into editable elements and cut-out stickers."
      >
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          className="sr-only"
          aria-label="Upload an image to extract elements from"
          onChange={(e) => {
            const f = e.target.files?.[0]
            if (f) void analyse(f)
            e.target.value = ''
          }}
        />
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault()
            const f = e.dataTransfer.files[0]
            if (f) void analyse(f)
          }}
          className="relative flex flex-col items-center gap-2 overflow-hidden rounded-lg border border-dashed border-input px-4 py-6 text-center transition-colors hover:border-primary"
        >
          {source ? (
            <img src={source.src || '/placeholder.svg'} alt="Image being analysed" className="max-h-48 rounded object-contain" />
          ) : (
            <>
              <Upload className="size-6 text-primary" aria-hidden="true" />
              <span className="text-sm font-medium text-foreground">Upload or drop an image</span>
              <span className="text-xs text-muted-foreground">JPG, PNG, WEBP up to 8 MB</span>
            </>
          )}
        </button>
        <label className="flex items-center gap-2 text-xs text-muted-foreground">
          <input type="checkbox" checked={knockout} onChange={(e) => setKnockout(e.target.checked)} className="accent-primary" />
          Remove plain background from stickers
        </label>
        {status === 'loading' && (
          <p role="status" className="flex items-center gap-2 text-xs text-muted-foreground">
            <Loader2 className="size-3.5 animate-spin" aria-hidden="true" /> Finding forms and objects…
          </p>
        )}
        {status === 'error' && (
          <p role="alert" className="text-xs text-destructive">
            {error}
          </p>
        )}
      </Section>

      {elements.length > 0 && (
        <Section title={`Found ${elements.length}`} hint="Forms stay editable (text, colors, buttons). Stickers become transparent PNGs.">
          <ul className="flex flex-col gap-3">
            {elements.map((el, i) => {
              const preview = el.kind === 'form' ? buildFormLayer(project, el, source) : null
              return (
                <li key={i} className="flex flex-col gap-2 rounded-lg border border-border bg-secondary p-2">
                  <div className="flex items-center justify-center overflow-hidden rounded bg-stage">
                    {preview ? (
                      <LayerThumb project={project} layers={[preview]} width={240} height={150} />
                    ) : (
                      <StickerPreview src={source?.src ?? ''} box={el.bbox} />
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="min-w-0 flex-1 truncate text-xs font-medium text-foreground">{el.name}</span>
                    <span className="shrink-0 rounded bg-background px-1.5 py-px text-[10px] text-muted-foreground">
                      {el.kind === 'form' && el.form ? FORM_NAMES[el.form] : 'Sticker'}
                    </span>
                  </div>
                  <div className="flex gap-1.5">
                    <button type="button" onClick={() => materialise(el, 'add', i)} className="flex flex-1 items-center justify-center gap-1 rounded-md bg-primary py-1.5 text-xs font-semibold text-primary-foreground">
                      <Plus className="size-3.5" aria-hidden="true" /> Add
                    </button>
                    <button type="button" onClick={() => materialise(el, 'save', i)} className="flex flex-1 items-center justify-center gap-1 rounded-md bg-background py-1.5 text-xs font-medium text-foreground hover:text-primary">
                      <Bookmark className="size-3.5" aria-hidden="true" /> Save
                    </button>
                    {el.kind === 'form' && (
                      <button type="button" onClick={() => materialise(el, 'cutout', i)} title="Add the original pixels as a picture" className="flex items-center justify-center rounded-md bg-background px-2 py-1.5 text-xs text-muted-foreground hover:text-foreground">
                        <ScanSearch className="size-3.5" aria-hidden="true" />
                        <span className="sr-only">Add original as picture</span>
                      </button>
                    )}
                  </div>
                  {done[i] && (
                    <p role="status" className="text-[11px] text-primary">
                      {done[i]}
                    </p>
                  )}
                </li>
              )
            })}
          </ul>
        </Section>
      )}
      <SavedElements />
    </>
  )
}

function StickerPreview({ src, box }: { src: string; box: ExtractedElement['bbox'] }) {
  const w = Math.max(0.01, box.w)
  const h = Math.max(0.01, box.h)
  return (
    <div className="relative h-36 w-full overflow-hidden">
      <div
        className="absolute inset-0 bg-no-repeat"
        style={{
          backgroundImage: `url(${src})`,
          backgroundSize: `${100 / w}% ${100 / h}%`,
          backgroundPosition: `${w >= 1 ? 0 : (box.x / (1 - w)) * 100}% ${h >= 1 ? 0 : (box.y / (1 - h)) * 100}%`,
          aspectRatio: 'auto',
          backgroundOrigin: 'content-box',
        }}
        role="img"
        aria-label="Sticker crop preview"
      />
    </div>
  )
}
