'use client'

import { ChevronLeft, ChevronRight, Copy, Plus, Trash2 } from 'lucide-react'
import { playback } from '@/lib/editor/playback'
import { editor, useEditor } from '@/lib/editor/store'
import { POST_TYPES, SLIDE_LIMIT, getSlides, type PostType, type TargetPlatform } from '@/lib/editor/types'
import { cn } from '@/lib/utils'

const TARGETS: Record<TargetPlatform, string> = { instagram: 'Instagram', tiktok: 'TikTok' }

export function SlidesBar() {
  const project = useEditor((s) => s.project)
  const postType = project.postType ?? 'reel'
  const target = project.target ?? 'instagram'
  const slides = getSlides(project)
  const active = project.activeSlide ?? 0
  const limit = SLIDE_LIMIT[postType][target]
  const multi = postType !== 'reel'
  const iconBtn = 'rounded p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground disabled:pointer-events-none disabled:opacity-40'
  const set = (patch: Partial<typeof project>) => editor.setProject({ ...editor.get().project, ...patch })

  return (
    <div className="flex h-11 shrink-0 items-center gap-3 border-t border-border bg-sidebar px-3">
      <label className="flex items-center gap-2 text-xs text-muted-foreground">
        <span className="sr-only">Post type</span>
        <select value={postType} onChange={(e) => set({ postType: e.target.value as PostType })} className="h-7 rounded-md border border-input bg-secondary px-2 text-xs text-foreground">
          {(Object.keys(POST_TYPES) as PostType[]).map((p) => (
            <option key={p} value={p}>
              {POST_TYPES[p].label}
            </option>
          ))}
        </select>
      </label>
      <div role="radiogroup" aria-label="Build for" className="flex rounded-md border border-border bg-card p-0.5">
        {(Object.keys(TARGETS) as TargetPlatform[]).map((t) => (
          <button
            key={t}
            type="button"
            role="radio"
            aria-checked={target === t}
            onClick={() => set({ target: t })}
            className={cn('rounded px-2.5 py-1 text-xs font-medium', target === t ? 'bg-accent text-foreground' : 'text-muted-foreground hover:text-foreground')}
          >
            {TARGETS[t]}
          </button>
        ))}
      </div>

      <div className="h-5 w-px bg-border" aria-hidden="true" />

      <ol aria-label="Slides" className="flex min-w-0 flex-1 items-center gap-1.5 overflow-x-auto">
        {slides.map((s, i) => (
          <li key={s.id}>
            <button
              type="button"
              aria-current={i === active ? 'true' : undefined}
              onClick={() => {
                editor.selectSlide(i)
                playback.setTime(0)
              }}
              className={cn(
                'flex h-7 items-center gap-1.5 rounded-md border px-2.5 text-xs font-medium',
                i === active ? 'border-primary bg-primary/15 text-foreground' : 'border-border text-muted-foreground hover:text-foreground',
                i >= limit && 'border-destructive text-destructive',
              )}
            >
              <span className="font-mono">{i + 1}</span>
              <span className="text-[10px] text-muted-foreground">{s.layers.length}</span>
            </button>
          </li>
        ))}
      </ol>

      <span className={cn('text-[11px]', slides.length > limit ? 'text-destructive' : 'text-muted-foreground')}>
        {multi ? `${slides.length}/${limit} on ${TARGETS[target]}` : slides.length > 1 ? 'Reels use 1 slide — switch to Story or Carousel' : POST_TYPES[postType].hint}
      </span>
      <div className="flex items-center">
        <button type="button" className={iconBtn} aria-label="Move slide left" disabled={active === 0} onClick={() => editor.moveSlide(active, active - 1)}>
          <ChevronLeft className="size-4" aria-hidden="true" />
        </button>
        <button type="button" className={iconBtn} aria-label="Move slide right" disabled={active >= slides.length - 1} onClick={() => editor.moveSlide(active, active + 1)}>
          <ChevronRight className="size-4" aria-hidden="true" />
        </button>
        <button type="button" className={iconBtn} aria-label="Add empty slide" disabled={!multi} onClick={() => editor.addSlide(false)}>
          <Plus className="size-4" aria-hidden="true" />
        </button>
        <button type="button" className={iconBtn} aria-label="Duplicate slide" disabled={!multi} onClick={() => editor.addSlide(true)}>
          <Copy className="size-4" aria-hidden="true" />
        </button>
        <button type="button" className={iconBtn} aria-label="Delete slide" disabled={slides.length < 2} onClick={() => editor.removeSlide(active)}>
          <Trash2 className="size-4" aria-hidden="true" />
        </button>
      </div>
    </div>
  )
}
