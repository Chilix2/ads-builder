'use client'

import { useRef, useState, type PointerEvent as ReactPointerEvent } from 'react'
import {
  AudioLines,
  Copy,
  Eye,
  EyeOff,
  Image as ImageIcon,
  Lock,
  MessageSquareText,
  Scissors,
  Shapes,
  Sparkles,
  Sticker,
  Trash2,
  Type,
  Unlock,
  ZoomIn,
  ZoomOut,
  PanelTop,
} from 'lucide-react'
import { playback, usePlayback } from '@/lib/editor/playback'
import { KIND_COLORS } from '@/lib/editor/presets'
import { editor, useEditor } from '@/lib/editor/store'
import { projectDuration, type Layer } from '@/lib/editor/types'
import { cn } from '@/lib/utils'

const ICONS = { media: ImageIcon, audio: AudioLines, text: Type, shape: Shapes, sticker: Sticker, comment: MessageSquareText, effect: Sparkles, form: PanelTop }
const ROW = 36
const LABEL_W = 176

type Drag = { mode: 'move' | 'left' | 'right'; id: string; x0: number; base: Layer }

export function Timeline() {
  const layers = useEditor((s) => s.project.layers)
  const assets = useEditor((s) => s.project.assets)
  const selectedId = useEditor((s) => s.selectedId)
  const duration = useEditor((s) => projectDuration(s.project))
  const { time } = usePlayback()
  const [pps, setPps] = useState(90)
  const drag = useRef<Drag | null>(null)
  const scrubbing = useRef(false)
  const trackRef = useRef<HTMLDivElement>(null)
  const span = Math.max(duration + 4, 12)
  const rows = [...layers].reverse()

  const timeAt = (clientX: number) => {
    const r = trackRef.current!.getBoundingClientRect()
    return Math.max(0, (clientX - r.left) / pps)
  }

  const startClip = (e: ReactPointerEvent, l: Layer, mode: Drag['mode']) => {
    e.stopPropagation()
    editor.select(l.id)
    if (l.locked) return
    editor.checkpoint()
    drag.current = { mode, id: l.id, x0: e.clientX, base: l }
    ;(e.currentTarget as HTMLElement).setPointerCapture(e.pointerId)
  }

  const snapTimes = (excludeId: string) => {
    const out = [0, playback.get().time]
    for (const l of editor.get().project.layers) if (l.id !== excludeId) out.push(l.start, l.start + l.duration)
    return out
  }
  const snap = (t: number, pts: number[]) => {
    const th = 8 / pps
    for (const p of pts) if (Math.abs(p - t) < th) return p
    return t
  }

  const moveClip = (e: ReactPointerEvent) => {
    const d = drag.current
    if (!d) return
    const dt = (e.clientX - d.x0) / pps
    const b = d.base
    const pts = snapTimes(b.id)
    const isTimed = b.kind === 'media' || b.kind === 'audio'
    const asset = isTimed ? assets.find((a) => a.id === b.assetId) : undefined
    const maxLen = asset && asset.type !== 'image' ? asset.duration : Infinity
    if (d.mode === 'move') {
      let start = Math.max(0, b.start + dt)
      const end = snap(start + b.duration, pts)
      start = end !== start + b.duration ? end - b.duration : snap(start, pts)
      editor.updateLayer(b.id, { start: Math.max(0, start) }, false)
    } else if (d.mode === 'right') {
      const trim = isTimed ? b.trimStart : 0
      const end = snap(b.start + b.duration + dt, pts)
      editor.updateLayer(b.id, { duration: Math.min(maxLen - trim, Math.max(0.1, end - b.start)) }, false)
    } else {
      let start = snap(Math.max(0, b.start + dt), pts)
      start = Math.min(start, b.start + b.duration - 0.1)
      let delta = start - b.start
      if (isTimed && b.trimStart + delta < 0) delta = -b.trimStart
      const patch: Partial<Layer> = { start: b.start + delta, duration: b.duration - delta }
      if (isTimed) Object.assign(patch, { trimStart: b.trimStart + delta })
      editor.updateLayer(b.id, patch, false)
    }
  }

  const sel = layers.find((l) => l.id === selectedId)
  const toolBtn = 'flex items-center gap-1.5 rounded-md px-2 py-1.5 text-xs text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground disabled:pointer-events-none disabled:opacity-40'

  return (
    <div className="flex h-full min-h-0 flex-col bg-card">
      <div className="flex h-10 shrink-0 items-center gap-1 border-b border-border px-3">
        <button type="button" className={toolBtn} disabled={!sel} onClick={() => sel && editor.split(sel.id, time)} title="Split at playhead (S)">
          <Scissors className="size-4" aria-hidden="true" />
          Split
        </button>
        <button type="button" className={toolBtn} disabled={!sel} onClick={() => sel && editor.duplicate(sel.id)}>
          <Copy className="size-4" aria-hidden="true" />
          Duplicate
        </button>
        <button type="button" className={toolBtn} disabled={!sel} onClick={() => sel && editor.removeLayer(sel.id)}>
          <Trash2 className="size-4" aria-hidden="true" />
          Delete
        </button>
        <div className="ml-auto flex items-center gap-2">
          <button type="button" aria-label="Zoom out timeline" className={toolBtn} onClick={() => setPps((p) => Math.max(20, p / 1.25))}>
            <ZoomOut className="size-4" aria-hidden="true" />
          </button>
          <input type="range" aria-label="Timeline zoom" className="range w-24" min={20} max={300} value={pps} onChange={(e) => setPps(Number(e.target.value))} />
          <button type="button" aria-label="Zoom in timeline" className={toolBtn} onClick={() => setPps((p) => Math.min(300, p * 1.25))}>
            <ZoomIn className="size-4" aria-hidden="true" />
          </button>
        </div>
      </div>
      <div className="scroll-thin relative min-h-0 flex-1 overflow-auto">
        <div className="relative" style={{ width: LABEL_W + span * pps, minHeight: '100%' }}>
          <div className="sticky top-0 z-20 flex h-7 border-b border-border bg-card">
            <div className="sticky left-0 z-10 shrink-0 border-r border-border bg-card" style={{ width: LABEL_W }} />
            <div
              ref={trackRef}
              className="relative flex-1 cursor-ew-resize"
              onPointerDown={(e) => {
                scrubbing.current = true
                playback.setPlaying(false)
                playback.setTime(timeAt(e.clientX))
                ;(e.currentTarget as HTMLElement).setPointerCapture(e.pointerId)
              }}
              onPointerMove={(e) => scrubbing.current && playback.setTime(timeAt(e.clientX))}
              onPointerUp={() => (scrubbing.current = false)}
            >
              {Array.from({ length: Math.ceil(span) + 1 }, (_, s) => (
                <div key={s} className="absolute top-0 h-full border-l border-border" style={{ left: s * pps }}>
                  <span className="absolute left-1 top-1 font-mono text-[10px] text-muted-foreground">{s}s</span>
                </div>
              ))}
            </div>
          </div>
          {rows.map((l) => {
            const Icon = ICONS[l.kind]
            const active = l.id === selectedId
            return (
              <div key={l.id} className={cn('flex border-b border-border', active && 'bg-secondary')} style={{ height: ROW }}>
                <div
                  className={cn('sticky left-0 z-10 flex shrink-0 items-center gap-2 border-r border-border px-2', active ? 'bg-secondary' : 'bg-card')}
                  style={{ width: LABEL_W }}
                >
                  <button type="button" onClick={() => editor.select(l.id)} className="flex min-w-0 flex-1 items-center gap-2 text-left">
                    <Icon className="size-3.5 shrink-0" style={{ color: KIND_COLORS[l.kind] }} aria-hidden="true" />
                    <span className={cn('truncate text-xs', active ? 'text-foreground' : 'text-muted-foreground')}>{l.name}</span>
                  </button>
                  <button type="button" aria-label={l.hidden ? 'Show layer' : 'Hide layer'} onClick={() => editor.updateLayer(l.id, { hidden: !l.hidden })} className="text-muted-foreground hover:text-foreground">
                    {l.hidden ? <EyeOff className="size-3.5" aria-hidden="true" /> : <Eye className="size-3.5" aria-hidden="true" />}
                  </button>
                  <button type="button" aria-label={l.locked ? 'Unlock layer' : 'Lock layer'} onClick={() => editor.updateLayer(l.id, { locked: !l.locked })} className="text-muted-foreground hover:text-foreground">
                    {l.locked ? <Lock className="size-3.5" aria-hidden="true" /> : <Unlock className="size-3.5" aria-hidden="true" />}
                  </button>
                </div>
                <div className="relative flex-1" onPointerDown={() => editor.select(null)}>
                  <div
                    role="button"
                    tabIndex={0}
                    aria-label={`${l.name} clip, ${l.start.toFixed(1)}s to ${(l.start + l.duration).toFixed(1)}s`}
                    onKeyDown={(e) => e.key === 'Enter' && editor.select(l.id)}
                    onPointerDown={(e) => startClip(e, l, 'move')}
                    onPointerMove={moveClip}
                    onPointerUp={() => (drag.current = null)}
                    className={cn(
                      'absolute top-1 flex h-7 cursor-grab items-center overflow-hidden rounded-md px-3 text-[11px] font-medium text-foreground active:cursor-grabbing',
                      active ? 'ring-2 ring-foreground' : 'ring-1 ring-background/40',
                      l.hidden && 'opacity-40',
                    )}
                    style={{ left: l.start * pps, width: Math.max(8, l.duration * pps), backgroundColor: KIND_COLORS[l.kind] }}
                  >
                    <span className="truncate">{l.name}</span>
                    {!l.locked && (
                      <>
                        <span
                          aria-hidden="true"
                          onPointerDown={(e) => startClip(e, l, 'left')}
                          onPointerMove={moveClip}
                          onPointerUp={() => (drag.current = null)}
                          className="absolute inset-y-0 left-0 w-2 cursor-ew-resize bg-foreground/20 hover:bg-foreground/50"
                        />
                        <span
                          aria-hidden="true"
                          onPointerDown={(e) => startClip(e, l, 'right')}
                          onPointerMove={moveClip}
                          onPointerUp={() => (drag.current = null)}
                          className="absolute inset-y-0 right-0 w-2 cursor-ew-resize bg-foreground/20 hover:bg-foreground/50"
                        />
                      </>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
          {!rows.length && <p className="px-4 py-6 text-xs text-muted-foreground">No layers yet. Add something from the library.</p>}
          <div className="pointer-events-none absolute bottom-0 top-0 z-30 w-px bg-primary" style={{ left: LABEL_W + time * pps }}>
            <span className="absolute -left-1.5 top-0 size-3 rotate-45 bg-primary" />
          </div>
        </div>
      </div>
    </div>
  )
}
