'use client'

import dynamic from 'next/dynamic'

const Editor = dynamic(() => import('./editor').then((m) => m.Editor), {
  ssr: false,
  loading: () => (
    <div className="flex h-dvh items-center justify-center bg-background text-sm text-muted-foreground">Loading editor…</div>
  ),
})

export function EditorClient() {
  return <Editor />
}
