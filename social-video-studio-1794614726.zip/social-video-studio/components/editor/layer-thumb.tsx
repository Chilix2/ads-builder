'use client'

import { useEffect, useRef } from 'react'
import { onAssetsChanged } from '@/lib/editor/assets'
import { loadAllFonts } from '@/lib/editor/fonts'
import { clearLayoutCache, drawLayerThumb } from '@/lib/editor/render'
import type { Layer, Project } from '@/lib/editor/types'
import { previewKeyframes } from '@/lib/editor/animation'

let fontsReady: Promise<void> | null = null
export function whenFontsReady() {
  if (!fontsReady) fontsReady = loadAllFonts().then(() => clearLayoutCache())
  return fontsReady
}

export function LayerThumb({ project, layers, width = 220, height = 150, className }: { project: Project; layers: Layer[]; width?: number; height?: number; className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const canvas = ref.current
    if (!canvas) return
    const dpr = Math.min(2, window.devicePixelRatio || 1)
    canvas.width = width * dpr
    canvas.height = height * dpr
    const draw = () => {
      const ctx = canvas.getContext('2d')
      if (!ctx) return
      ctx.setTransform(1, 0, 0, 1, 0, 0)
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      const visual = layers.filter((l) => l.kind !== 'audio' && l.kind !== 'effect')
      const main = visual[visual.length - 1]
      if (main) drawLayerThumb(ctx, project, main, canvas.width, canvas.height)
    }
    draw()
    let alive = true
    void whenFontsReady().then(() => alive && draw())
    const off = onAssetsChanged(draw)
    return () => {
      alive = false
      off()
    }
  }, [project, layers, width, height])
  return <canvas ref={ref} aria-hidden="true" className={className} style={{ width: '100%', height: 'auto', aspectRatio: `${width} / ${height}` }} />
}

/** Live looping sample of an in/out/loop animation applied to a word. */
export function AnimPreview({ kind, type, label = 'Aa' }: { kind: 'in' | 'out' | 'loop'; type: string; label?: string }) {
  const ref = useRef<HTMLSpanElement>(null)
  useEffect(() => {
    const el = ref.current
    if (!el || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const anim = el.animate(previewKeyframes(kind, type), {
      duration: kind === 'loop' ? 2000 : 1100,
      iterations: Infinity,
      easing: 'linear',
      endDelay: kind === 'loop' ? 0 : 500,
    })
    return () => anim.cancel()
  }, [kind, type])
  return (
    <span ref={ref} className="inline-block text-lg font-extrabold text-foreground will-change-transform">
      {label}
    </span>
  )
}
