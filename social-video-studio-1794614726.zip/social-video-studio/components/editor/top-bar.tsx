'use client'

import { useRef, useState } from 'react'
import { Download, FileJson, FilePlus2, FolderOpen, ImageDown, ListChecks, Loader2, Redo2, Undo2, Video, X } from 'lucide-react'
import { RebuildGuide } from './rebuild-guide'
import { exportPNG, exportProjectJSON, exportVideo, importProjectJSON } from '@/lib/editor/export'
import { changeFormat, emptyProject } from '@/lib/editor/factory'
import { playback } from '@/lib/editor/playback'
import { editor, useEditor } from '@/lib/editor/store'
import { FORMATS, type FormatId } from '@/lib/editor/types'
import { cn } from '@/lib/utils'

export function TopBar() {
  const name = useEditor((s) => s.project.name)
  const format = useEditor((s) => s.project.format)
  const canUndo = useEditor((s) => s.past.length > 0)
  const canRedo = useEditor((s) => s.future.length > 0)
  const [exportOpen, setExportOpen] = useState(false)
  const [guideOpen, setGuideOpen] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const iconBtn = 'rounded-md p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground disabled:pointer-events-none disabled:opacity-40'

  return (
    <header className="flex h-14 shrink-0 items-center gap-3 border-b border-border bg-sidebar px-3">
      <div className="flex items-center gap-2 pr-2">
        <span className="flex size-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
          <Video className="size-4" aria-hidden="true" />
        </span>
        <span className="hidden text-sm font-semibold text-foreground lg:inline">Studio</span>
      </div>
      <input
        aria-label="Project name"
        value={name}
        onChange={(e) => editor.setProject({ ...editor.get().project, name: e.target.value }, false)}
        className="h-8 w-44 rounded-md bg-transparent px-2 text-sm text-foreground outline-none hover:bg-secondary focus:bg-secondary"
      />
      <div className="flex items-center gap-0.5">
        <button type="button" className={iconBtn} aria-label="Undo" disabled={!canUndo} onClick={editor.undo}>
          <Undo2 className="size-4" aria-hidden="true" />
        </button>
        <button type="button" className={iconBtn} aria-label="Redo" disabled={!canRedo} onClick={editor.redo}>
          <Redo2 className="size-4" aria-hidden="true" />
        </button>
      </div>

      <div role="radiogroup" aria-label="Canvas format" className="mx-auto flex rounded-lg border border-border bg-card p-0.5">
        {(Object.keys(FORMATS) as FormatId[]).map((f) => (
          <button
            key={f}
            type="button"
            role="radio"
            aria-checked={format === f}
            title={FORMATS[f].hint}
            onClick={() => editor.setProject(changeFormat(editor.get().project, f))}
            className={cn(
              'flex items-center gap-2 rounded-md px-3 py-1.5 text-xs font-medium transition-colors',
              format === f ? 'bg-accent text-foreground' : 'text-muted-foreground hover:text-foreground',
            )}
          >
            <span
              aria-hidden="true"
              className={cn('rounded-sm border', format === f ? 'border-primary' : 'border-muted-foreground')}
              style={{ width: (FORMATS[f].width / FORMATS[f].height) * 14, height: 14 }}
            />
            <span>{f}</span>
            <span className="hidden text-muted-foreground xl:inline">{FORMATS[f].hint}</span>
          </button>
        ))}
      </div>

      <div className="flex items-center gap-1">
        <button
          type="button"
          className={iconBtn}
          aria-label="New project"
          title="New project"
          onClick={() => {
            const { project } = editor.get()
            editor.setProject({ ...emptyProject(project.format), assets: project.assets })
            editor.select(null)
            playback.setTime(0)
          }}
        >
          <FilePlus2 className="size-4" aria-hidden="true" />
        </button>
        <input
          ref={fileRef}
          type="file"
          accept=".json,application/json"
          className="sr-only"
          aria-label="Open project file"
          onChange={async (e) => {
            const f = e.target.files?.[0]
            e.target.value = ''
            if (!f) return
            try {
              editor.replaceProject(await importProjectJSON(f))
              playback.setTime(0)
            } catch (err) {
              alert(err instanceof Error ? err.message : 'Could not open file')
            }
          }}
        />
        <button type="button" className={iconBtn} aria-label="Open project" title="Open project (.json)" onClick={() => fileRef.current?.click()}>
          <FolderOpen className="size-4" aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={() => setGuideOpen(true)}
          className="ml-1 flex h-9 items-center gap-2 rounded-md border border-border px-3 text-sm font-medium text-foreground transition-colors hover:border-primary"
        >
          <ListChecks className="size-4 text-primary" aria-hidden="true" />
          Build plan
        </button>
        <button
          type="button"
          onClick={() => setExportOpen(true)}
          className="ml-1 flex h-9 items-center gap-2 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
        >
          <Download className="size-4" aria-hidden="true" />
          Export
        </button>
      </div>
      {exportOpen && <ExportDialog onClose={() => setExportOpen(false)} />}
      {guideOpen && <RebuildGuide onClose={() => setGuideOpen(false)} />}
    </header>
  )
}

function ExportDialog({ onClose }: { onClose: () => void }) {
  const [quality, setQuality] = useState<'720' | '1080'>('1080')
  const [fps, setFps] = useState(30)
  const [progress, setProgress] = useState<number | null>(null)
  const [error, setError] = useState<string | null>(null)
  const abort = useRef<AbortController | null>(null)
  const busy = progress !== null

  const runVideo = async () => {
    const { project } = editor.get()
    const short = Math.min(project.width, project.height)
    const scale = quality === '720' ? 720 / short : 1080 / short
    abort.current = new AbortController()
    setError(null)
    setProgress(0)
    try {
      await exportVideo(project, { fps, scale, onProgress: setProgress, signal: abort.current.signal })
      setProgress(null)
      onClose()
    } catch (err) {
      setProgress(null)
      if ((err as DOMException)?.name !== 'AbortError') setError(err instanceof Error ? err.message : 'Export failed')
    }
  }

  const card = 'flex items-center gap-3 rounded-lg border border-border bg-secondary p-3 text-left transition-colors hover:border-primary disabled:opacity-50'
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 p-4" role="dialog" aria-modal="true" aria-labelledby="export-title">
      <div className="flex w-full max-w-md flex-col gap-5 rounded-xl border border-border bg-card p-5 shadow-2xl">
        <div className="flex items-center justify-between">
          <h2 id="export-title" className="text-base font-semibold text-foreground">
            Export
          </h2>
          <button
            type="button"
            aria-label="Close"
            onClick={() => {
              abort.current?.abort()
              onClose()
            }}
            className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
          >
            <X className="size-4" aria-hidden="true" />
          </button>
        </div>

        <div className="flex flex-col gap-3">
          <div className="grid grid-cols-2 gap-3">
            <label className="flex flex-col gap-1.5 text-xs text-muted-foreground">
              Resolution
              <select value={quality} onChange={(e) => setQuality(e.target.value as '720' | '1080')} disabled={busy} className="h-8 rounded-md border border-input bg-secondary px-2 text-sm text-foreground">
                <option value="1080">1080p</option>
                <option value="720">720p</option>
              </select>
            </label>
            <label className="flex flex-col gap-1.5 text-xs text-muted-foreground">
              Frame rate
              <select value={fps} onChange={(e) => setFps(Number(e.target.value))} disabled={busy} className="h-8 rounded-md border border-input bg-secondary px-2 text-sm text-foreground">
                <option value={30}>30 fps</option>
                <option value={60}>60 fps</option>
                <option value={24}>24 fps</option>
              </select>
            </label>
          </div>
          <button type="button" className={card} onClick={runVideo} disabled={busy}>
            {busy ? <Loader2 className="size-5 shrink-0 animate-spin text-primary" aria-hidden="true" /> : <Video className="size-5 shrink-0 text-primary" aria-hidden="true" />}
            <span className="flex flex-1 flex-col">
              <span className="text-sm font-medium text-foreground">{busy ? `Rendering ${Math.round((progress ?? 0) * 100)}%` : 'Video (MP4 / WebM)'}</span>
              <span className="text-xs text-muted-foreground">Rendered in real time with audio. Keep this tab visible.</span>
            </span>
          </button>
          {busy && (
            <div className="flex items-center gap-3">
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-input">
                <div className="h-full bg-primary transition-[width]" style={{ width: `${(progress ?? 0) * 100}%` }} />
              </div>
              <button type="button" onClick={() => abort.current?.abort()} className="text-xs text-muted-foreground hover:text-foreground">
                Cancel
              </button>
            </div>
          )}
          <button type="button" className={card} disabled={busy} onClick={() => void exportPNG(editor.get().project, playback.get().time)}>
            <ImageDown className="size-5 shrink-0 text-primary" aria-hidden="true" />
            <span className="flex flex-col">
              <span className="text-sm font-medium text-foreground">Current frame (PNG)</span>
              <span className="text-xs text-muted-foreground">Thumbnails, feed posts and covers at full resolution.</span>
            </span>
          </button>
          <button type="button" className={card} disabled={busy} onClick={() => void exportProjectJSON(editor.get().project)}>
            <FileJson className="size-5 shrink-0 text-primary" aria-hidden="true" />
            <span className="flex flex-col">
              <span className="text-sm font-medium text-foreground">Project file (JSON)</span>
              <span className="text-xs text-muted-foreground">Re-open later or import into your internal pipeline.</span>
            </span>
          </button>
          {error && <p className="text-xs text-destructive" role="alert">{error}</p>}
        </div>
      </div>
    </div>
  )
}
