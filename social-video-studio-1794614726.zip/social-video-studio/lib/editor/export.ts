'use client'

import { pauseAllMedia, startAudioCapture, syncMedia } from './assets'
import { loadAllFonts } from './fonts'
import { playback } from './playback'
import { drawFrame } from './render'
import { projectDuration, type Layer, type Project } from './types'

/** Each layer alone on a transparent canvas, captured once its in-animation has settled. */
export async function exportLayerPNGs(project: Project, layers: Layer[]) {
  await loadAllFonts()
  const canvas = document.createElement('canvas')
  canvas.width = project.width
  canvas.height = project.height
  const ctx = canvas.getContext('2d')!
  for (const l of layers) {
    const t = l.start + Math.min(l.duration / 2, (l.animIn?.duration ?? 0) + 0.05)
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    drawFrame(ctx, { ...project, background: 'rgba(0,0,0,0)', layers: [{ ...l, animIn: null, animOut: null }] }, t)
    const blob = await new Promise<Blob | null>((r) => canvas.toBlob(r, 'image/png'))
    if (blob) download(blob, `${l.name}.png`)
    await new Promise((r) => setTimeout(r, 250))
  }
}

export function downloadText(text: string, filename: string, type = 'text/plain') {
  download(new Blob([text], { type }), filename)
}

function download(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 2000)
}

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'post'

export async function exportPNG(project: Project, t: number) {
  await loadAllFonts()
  const canvas = document.createElement('canvas')
  canvas.width = project.width
  canvas.height = project.height
  drawFrame(canvas.getContext('2d')!, project, t)
  const blob = await new Promise<Blob | null>((r) => canvas.toBlob(r, 'image/png'))
  if (blob) download(blob, `${slug(project.name)}.png`)
}

export function pickVideoMime() {
  const candidates = ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']
  return candidates.find((m) => typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(m)) ?? ''
}

export interface VideoExportOptions {
  fps: number
  scale: number
  onProgress: (p: number) => void
  signal: AbortSignal
}

/** Renders the timeline in real time into a MediaRecorder (video + mixed audio). */
export async function exportVideo(project: Project, opts: VideoExportOptions) {
  await loadAllFonts()
  const mime = pickVideoMime()
  if (!mime) throw new Error('This browser cannot record video. Try Chrome, Edge or Safari.')
  const duration = projectDuration(project)
  const canvas = document.createElement('canvas')
  canvas.width = Math.round((project.width * opts.scale) / 2) * 2
  canvas.height = Math.round((project.height * opts.scale) / 2) * 2
  const ctx = canvas.getContext('2d')!
  const stream = canvas.captureStream(opts.fps)
  for (const track of startAudioCapture()) stream.addTrack(track)
  const recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 12_000_000 * opts.scale })
  const chunks: Blob[] = []
  recorder.ondataavailable = (e) => e.data.size && chunks.push(e.data)

  playback.setPlaying(false)
  playback.setRecording(true)
  playback.setTime(0)
  syncMedia(project, 0, false)
  await new Promise((r) => setTimeout(r, 350))

  const render = (t: number) => {
    ctx.setTransform(1, 0, 0, 1, 0, 0)
    ctx.save()
    ctx.scale(opts.scale, opts.scale)
    drawFrame(ctx, project, t)
    ctx.restore()
  }

  return new Promise<void>((resolve, reject) => {
    let raf = 0
    const finish = (aborted: boolean) => {
      cancelAnimationFrame(raf)
      pauseAllMedia()
      playback.setRecording(false)
      if (recorder.state !== 'inactive') recorder.stop()
      if (aborted) reject(new DOMException('Export cancelled', 'AbortError'))
    }
    recorder.onstop = () => {
      if (opts.signal.aborted) return
      const type = mime.split(';')[0]
      download(new Blob(chunks, { type }), `${slug(project.name)}.${type === 'video/mp4' ? 'mp4' : 'webm'}`)
      resolve()
    }
    opts.signal.addEventListener('abort', () => finish(true), { once: true })
    render(0)
    recorder.start(250)
    const t0 = performance.now()
    const tick = () => {
      const t = (performance.now() - t0) / 1000
      if (t >= duration) {
        render(duration - 0.001)
        opts.onProgress(1)
        finish(false)
        return
      }
      syncMedia(project, t, true)
      playback.setTime(t)
      render(t)
      opts.onProgress(t / duration)
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
  })
}

async function toDataUrl(src: string): Promise<string> {
  const blob = await (await fetch(src)).blob()
  return new Promise((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(String(r.result))
    r.onerror = reject
    r.readAsDataURL(blob)
  })
}

const MAX_EMBED = 25 * 1024 * 1024

/** Saves a self-contained project file. Uploaded files are embedded so it opens anywhere. */
export async function exportProjectJSON(project: Project) {
  const assets = await Promise.all(
    project.assets.map(async (a) => {
      if (!a.src.startsWith('blob:')) return a
      try {
        const head = await fetch(a.src)
        const size = Number(head.headers.get('content-length') ?? 0)
        if (size > MAX_EMBED) return a
        return { ...a, src: await toDataUrl(a.src) }
      } catch {
        return a
      }
    }),
  )
  const json = JSON.stringify({ ...project, assets }, null, 2)
  download(new Blob([json], { type: 'application/json' }), `${slug(project.name)}.studio.json`)
}

export async function importProjectJSON(file: File): Promise<Project> {
  const data = JSON.parse(await file.text()) as Project
  if (data?.version !== 1 || !Array.isArray(data.layers) || !Array.isArray(data.assets)) {
    throw new Error('Not a valid project file')
  }
  return data
}
