/**
 * Native tool catalog for the two target editors.
 *
 * Instagram → Edits app (free; "Edits Plus" paid tier is in limited testing: cloud storage + more AI credits).
 * TikTok    → in-app editor + TikTok Studio (both free). TikTok has no paid editor tier of its own —
 *             the paid tier is CapCut Pro (ByteDance), which publishes straight to TikTok.
 *
 * Menu paths change between app versions; `verify: true` marks paths that move often or are region-gated.
 */

export type NativePlatform = 'instagram' | 'tiktok'
export type Tier = 'free' | 'edits-plus' | 'capcut-pro' | 'studio-web'

export const TIERS: Record<Tier, { label: string; note: string }> = {
  free: { label: 'Free', note: 'Included in the app' },
  'edits-plus': { label: 'Edits Plus', note: 'Meta paid tier — limited test, adds cloud storage and more AI usage' },
  'capcut-pro': { label: 'CapCut Pro', note: 'Paid tier — use “Share to TikTok” so it still posts natively' },
  'studio-web': { label: 'Studio Web', note: 'TikTok Studio on desktop (tiktok.com/tiktokstudio)' },
}

export interface NativePath {
  path: string
  tier: Tier
  verify?: boolean
}

export type ToolCategory =
  | 'Post type'
  | 'Clips'
  | 'Text'
  | 'Captions & voice'
  | 'Audio'
  | 'Stickers'
  | 'Frames & overlays'
  | 'Look'
  | 'Motion'
  | 'AI'
  | 'Publish'

export interface NativeTool {
  id: string
  name: string
  category: ToolCategory
  instagram: NativePath | null
  tiktok: NativePath | null
  /** What to do on the platform that lacks this tool. */
  fallback?: Partial<Record<NativePlatform, string>>
}

const ig = (path: string, tier: Tier = 'free', verify = false): NativePath => ({ path, tier, verify })
const tt = ig

export const NATIVE_TOOLS: NativeTool[] = [
  // Post types
  { id: 'reel', name: 'Reel / video post', category: 'Post type', instagram: ig('Edits → New project'), tiktok: tt('Create (+) → Upload') },
  { id: 'story', name: 'Story (multi-slide)', category: 'Post type', instagram: ig('Your story (+) → each slide ≤ 60 s'), tiktok: tt('Create (+) → Story tab', 'free', true) },
  { id: 'carousel', name: 'Carousel / photo mode', category: 'Post type', instagram: ig('Post → select up to 20 items'), tiktok: tt('Create (+) → Upload → Photos (up to 35)') },
  { id: 'smart-split', name: 'Smart Split (long → shorts)', category: 'Post type', instagram: null, tiktok: tt('TikTok Studio → Tools → Smart Split', 'studio-web'), fallback: { instagram: 'Split manually into separate Edits projects' } },

  // Clips
  { id: 'trim', name: 'Trim / split', category: 'Clips', instagram: ig('Tap clip → Split / drag edges'), tiktok: tt('Edit → tap clip → Split') },
  { id: 'speed', name: 'Speed', category: 'Clips', instagram: ig('Tap clip → Speed'), tiktok: tt('Edit → Speed') },
  { id: 'speed-curve', name: 'Speed curve / ramp', category: 'Clips', instagram: ig('Tap clip → Speed → Curve', 'free', true), tiktok: tt('CapCut → Speed → Curve', 'capcut-pro'), fallback: { tiktok: 'Split clip and set different speeds per piece' } },
  { id: 'reverse', name: 'Reverse', category: 'Clips', instagram: ig('Tap clip → Reverse', 'free', true), tiktok: tt('Effects → Time → Reverse') },
  { id: 'freeze', name: 'Freeze frame', category: 'Clips', instagram: ig('Tap clip → Freeze'), tiktok: tt('CapCut → Freeze', 'free'), fallback: { tiktok: 'Screenshot the frame and add it as a photo clip' } },
  { id: 'keyframes', name: 'Keyframes (position/scale)', category: 'Clips', instagram: ig('Tap clip → Keyframe ◇'), tiktok: tt('CapCut → Keyframe ◇', 'free'), fallback: { tiktok: 'Bake into base plate' } },
  { id: 'overlay', name: 'Overlay / picture-in-picture', category: 'Clips', instagram: ig('Overlay → add from camera roll'), tiktok: tt('Edit → Overlay', 'free', true) },
  { id: 'green-screen', name: 'Green screen', category: 'Clips', instagram: ig('Green screen'), tiktok: tt('Effects → Green Screen') },
  { id: 'cutout', name: 'Cutout / remove background', category: 'Clips', instagram: ig('Tap clip → Cutout'), tiktok: tt('CapCut → Remove background', 'capcut-pro'), fallback: { tiktok: 'Bake cutout into base plate' } },
  { id: 'transitions', name: 'Transitions', category: 'Clips', instagram: ig('Tap the | between clips → Transitions'), tiktok: tt('Edit → tap the | between clips') },
  { id: 'templates', name: 'Templates', category: 'Clips', instagram: ig('Edits → Templates'), tiktok: tt('Create (+) → Templates') },

  // Text
  { id: 'text', name: 'Text', category: 'Text', instagram: ig('Text (Aa)'), tiktok: tt('Text (Aa)') },
  { id: 'text-animation', name: 'Text in / out animation', category: 'Text', instagram: ig('Tap text → Animation'), tiktok: tt('Tap text → Animation', 'free', true), fallback: { tiktok: 'Use timing only (show/hide) or bake into base plate' } },
  { id: 'text-bg', name: 'Text background box', category: 'Text', instagram: ig('Tap text → A highlight button'), tiktok: tt('Tap text → A button') },

  // Captions & voice
  { id: 'auto-captions', name: 'Auto captions', category: 'Captions & voice', instagram: ig('Captions → Generate captions'), tiktok: tt('Captions (CC) → Auto captions') },
  { id: 'tts', name: 'Text-to-speech', category: 'Captions & voice', instagram: ig('Tap text → Text to speech'), tiktok: tt('Tap text → Text-to-speech') },
  { id: 'voiceover', name: 'Voiceover', category: 'Captions & voice', instagram: ig('Voiceover (mic)'), tiktok: tt('Voiceover (mic)') },
  { id: 'voice-effects', name: 'Voice effects', category: 'Captions & voice', instagram: ig('Audio → Voice effects'), tiktok: tt('Voice effects') },
  { id: 'voice-enhance', name: 'Voice enhance / noise reduction', category: 'Captions & voice', instagram: ig('Audio → Enhance voice'), tiktok: tt('CapCut → Enhance voice', 'capcut-pro'), fallback: { tiktok: 'Clean the audio before upload (bake into base plate)' } },

  // Audio
  { id: 'music', name: 'Music / trending sound', category: 'Audio', instagram: ig('Audio → search / trending'), tiktok: tt('Add sound → search / trending') },
  { id: 'beat-sync', name: 'Beat sync / auto cut', category: 'Audio', instagram: ig('Audio → Beat markers', 'free', true), tiktok: tt('Templates → Sync to beat', 'free', true) },
  { id: 'sfx', name: 'Sound effects', category: 'Audio', instagram: ig('Audio → Sound effects'), tiktok: tt('Add sound → search SFX', 'free', true) },

  // Stickers
  { id: 'sticker-poll', name: 'Poll sticker', category: 'Stickers', instagram: ig('Stickers → Poll'), tiktok: tt('Stickers → Poll') },
  { id: 'sticker-quiz', name: 'Quiz sticker', category: 'Stickers', instagram: ig('Stickers → Quiz'), tiktok: null, fallback: { tiktok: 'Use Poll sticker with the answer options' } },
  { id: 'sticker-slider', name: 'Emoji slider', category: 'Stickers', instagram: ig('Stickers → Emoji slider'), tiktok: null, fallback: { tiktok: 'Overlay PNG (non-interactive)' } },
  { id: 'sticker-question', name: 'Questions / Q&A', category: 'Stickers', instagram: ig('Stickers → Questions (Stories)'), tiktok: tt('Stickers → Q&A') },
  { id: 'sticker-add-yours', name: 'Add Yours', category: 'Stickers', instagram: ig('Stickers → Add Yours'), tiktok: null, fallback: { tiktok: 'Overlay PNG + call to action in caption' } },
  { id: 'sticker-countdown', name: 'Countdown', category: 'Stickers', instagram: ig('Stickers → Countdown'), tiktok: null, fallback: { tiktok: 'Overlay PNG with date text' } },
  { id: 'sticker-mention', name: 'Mention', category: 'Stickers', instagram: ig('Stickers → Mention'), tiktok: tt('Stickers → Mention') },
  { id: 'sticker-hashtag', name: 'Hashtag', category: 'Stickers', instagram: ig('Stickers → Hashtag'), tiktok: tt('Stickers → Hashtag') },
  { id: 'sticker-location', name: 'Location', category: 'Stickers', instagram: ig('Stickers → Location'), tiktok: tt('Post screen → Location'), fallback: {} },
  { id: 'sticker-link', name: 'Link', category: 'Stickers', instagram: ig('Stickers → Link (Stories)'), tiktok: null, fallback: { tiktok: '“Link in bio” overlay PNG' } },
  { id: 'sticker-music', name: 'Music sticker', category: 'Stickers', instagram: ig('Stickers → Music (Stories)'), tiktok: null, fallback: { tiktok: 'Add sound — the sound label shows automatically' } },
  { id: 'sticker-gif', name: 'GIF', category: 'Stickers', instagram: ig('Stickers → GIF'), tiktok: tt('Stickers → GIFs') },
  { id: 'sticker-reveal', name: 'Reveal', category: 'Stickers', instagram: ig('Stickers → Reveal (Stories)'), tiktok: null, fallback: { tiktok: 'Overlay PNG' } },
  { id: 'sticker-frame', name: 'Frame (polaroid)', category: 'Stickers', instagram: ig('Stickers → Frame (Stories)'), tiktok: null, fallback: { tiktok: 'Overlay PNG frame' } },
  { id: 'sticker-photo', name: 'Photo sticker / overlay PNG', category: 'Frames & overlays', instagram: ig('Stickers → Photo (camera roll)'), tiktok: tt('Stickers → Add photo / Overlay', 'free', true) },
  { id: 'comment-reply', name: 'Reply-to-comment sticker', category: 'Stickers', instagram: ig('Comment → Reply with Reel'), tiktok: tt('Comment → Reply with video') },

  // Look
  { id: 'filters', name: 'Filters', category: 'Look', instagram: ig('Filters'), tiktok: tt('Filters') },
  { id: 'adjust', name: 'Adjust (bright/contrast/sat)', category: 'Look', instagram: ig('Tap clip → Adjust'), tiktok: tt('Filters → Adjust') },
  { id: 'effects', name: 'Visual effects', category: 'Look', instagram: ig('Effects'), tiktok: tt('Effects') },
  { id: 'camera-shake', name: 'Shake / zoom effects', category: 'Motion', instagram: ig('Effects → Motion', 'free', true), tiktok: tt('Effects → Visual → Shake / Zoom') },
  { id: 'ken-burns', name: 'Slow zoom (Ken Burns)', category: 'Motion', instagram: ig('Keyframe scale 100 → 115%'), tiktok: tt('Effects → Zoom', 'free', true) },

  // AI
  { id: 'ai-restyle', name: 'AI restyle', category: 'AI', instagram: ig('Tap clip → Restyle', 'free', true), tiktok: tt('Effects → AI', 'free', true) },
  { id: 'ai-animate', name: 'AI animate photo', category: 'AI', instagram: ig('Tap photo → Animate', 'free', true), tiktok: tt('Create → AI Alive', 'free', true) },
  { id: 'ai-outline', name: 'AI script / hook outline', category: 'AI', instagram: null, tiktok: tt('TikTok Studio → AI Outline', 'studio-web'), fallback: { instagram: 'Write hook in the builder, then type it as Text' } },

  // Publish
  { id: 'cover', name: 'Cover / thumbnail', category: 'Publish', instagram: ig('Next → Edit cover'), tiktok: tt('Next → Select cover') },
  { id: 'publish', name: 'Publish natively', category: 'Publish', instagram: ig('Share to Instagram'), tiktok: tt('Post') },
]

export const TOOL_BY_ID = new Map(NATIVE_TOOLS.map((t) => [t.id, t]))

export type Availability = 'both' | 'instagram' | 'tiktok' | 'overlay'

export function availabilityOf(toolId: string | null | undefined): Availability {
  const t = toolId ? TOOL_BY_ID.get(toolId) : undefined
  if (!t) return 'overlay'
  if (t.instagram && t.tiktok) return 'both'
  return t.instagram ? 'instagram' : 'tiktok'
}

export const AVAILABILITY_LABEL: Record<Availability, string> = {
  both: 'IG + TT',
  instagram: 'IG only',
  tiktok: 'TT only',
  overlay: 'PNG',
}
