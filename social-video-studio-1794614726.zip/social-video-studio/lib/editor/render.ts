'use client'

import { computeAnim, identityAnim, type AnimState } from './animation'
import { getImage, getVideoFrame } from './assets'
import { fontFamily } from './fonts'
import { filterString } from './presets'
import { drawForm, formHeight } from './render-forms'
import {
  CAMERA_EFFECTS,
  clamp,
  type CommentLayer,
  type EffectLayer,
  type Layer,
  type MediaLayer,
  type Project,
  type ShapeLayer,
  type StickerLayer,
  type TextLayer,
  type WarpType,
} from './types'

type Ctx = CanvasRenderingContext2D
const HELV = '"Helvetica Neue", Helvetica, Arial, sans-serif'

let measureCanvas: HTMLCanvasElement | null = null
function mctx(): Ctx {
  if (!measureCanvas) measureCanvas = document.createElement('canvas')
  return measureCanvas.getContext('2d')!
}

const layoutCache = new Map<string, unknown>()
export function clearLayoutCache() {
  layoutCache.clear()
}

function wrap(ctx: Ctx, text: string, maxW: number): string[] {
  const out: string[] = []
  for (const para of text.split('\n')) {
    const words = para.split(' ')
    let line = ''
    for (const word of words) {
      const test = line ? `${line} ${word}` : word
      if (line && ctx.measureText(test).width > maxW) {
        out.push(line)
        line = word
      } else line = test
    }
    out.push(line)
  }
  return out
}

/* ---------- Text ---------- */

export interface TextLayout {
  lines: string[]
  font: string
  lineH: number
  height: number
  padX: number
  padY: number
  lineWidths: number[]
}

function textFont(l: TextLayer) {
  return `${l.italic ? 'italic ' : ''}${l.fontWeight} ${l.fontSize}px ${fontFamily(l.font)}`
}

export function layoutText(l: TextLayer): TextLayout {
  const key = `t|${l.text}|${l.font}|${l.fontSize}|${l.fontWeight}|${l.italic}|${l.width}|${l.bgMode}|${l.bgPadding}|${l.uppercase}|${l.lineHeight}|${l.letterSpacing}`
  const hit = layoutCache.get(key) as TextLayout | undefined
  if (hit) return hit
  const ctx = mctx()
  const font = textFont(l)
  ctx.font = font
  ctx.letterSpacing = `${l.letterSpacing}px`
  const padX = l.bgMode !== 'none' ? l.bgPadding : 0
  const padY = l.bgMode !== 'none' ? l.bgPadding * 0.55 : 0
  const raw = l.uppercase ? l.text.toUpperCase() : l.text
  const lines = wrap(ctx, raw, Math.max(10, l.width - padX * 2))
  const lineH = l.fontSize * l.lineHeight
  const layout: TextLayout = {
    lines,
    font,
    lineH,
    height: lines.length * lineH + padY * 2,
    padX,
    padY,
    lineWidths: lines.map((ln) => ctx.measureText(ln).width),
  }
  ctx.letterSpacing = '0px'
  layoutCache.set(key, layout)
  return layout
}

function drawText(ctx: Ctx, l: TextLayer, st: AnimState) {
  const L = layoutText(l)
  const w = l.width
  const h = L.height
  ctx.font = L.font
  ctx.letterSpacing = `${l.letterSpacing}px`
  ctx.textBaseline = 'middle'
  ctx.textAlign = 'left'

  const lineX = (i: number) => {
    const lw = L.lineWidths[i]
    if (l.align === 'left') return -w / 2 + L.padX
    if (l.align === 'right') return w / 2 - L.padX - lw
    return -lw / 2
  }

  const allWords = L.lines.flatMap((ln) => ln.split(' ').filter(Boolean))
  const totalChars = L.lines.reduce((n, ln) => n + ln.length, 0)
  let charBudget = st.revealMode === 'chars' ? Math.round(totalChars * st.reveal) : Infinity
  let wordBudget = st.revealMode === 'words' ? Math.ceil(allWords.length * st.reveal) : Infinity
  const activeWord = st.karaoke >= 0 ? Math.min(allWords.length - 1, Math.floor(st.karaoke * allWords.length)) : -1

  if (l.bgMode === 'box') {
    const maxW = Math.max(...L.lineWidths)
    const bw = maxW + L.padX * 2
    const bx = l.align === 'left' ? -w / 2 : l.align === 'right' ? w / 2 - bw : -bw / 2
    ctx.fillStyle = l.bgColor
    ctx.beginPath()
    ctx.roundRect(bx, -h / 2, bw, h, l.bgRadius)
    ctx.fill()
  } else if (l.bgMode === 'line') {
    ctx.fillStyle = l.bgColor
    L.lines.forEach((ln, i) => {
      if (!ln) return
      const y = -h / 2 + L.padY + i * L.lineH
      ctx.beginPath()
      ctx.roundRect(lineX(i) - L.padX, y - L.padY * 0.5, L.lineWidths[i] + L.padX * 2, L.lineH + L.padY, l.bgRadius)
      ctx.fill()
    })
  }

  if (l.shadow) {
    ctx.shadowColor = l.shadowColor
    ctx.shadowBlur = l.fontSize * 0.25
    ctx.shadowOffsetY = l.fontSize * 0.04
  }
  ctx.lineJoin = 'round'
  ctx.miterLimit = 2
  const space = ctx.measureText(' ').width
  let wordIndex = 0
  L.lines.forEach((ln, i) => {
    const y = -h / 2 + L.padY + i * L.lineH + L.lineH / 2
    let x = lineX(i)
    const words = ln.split(' ')
    for (const word of words) {
      if (!word) {
        x += space
        continue
      }
      if (wordBudget <= 0 || charBudget <= 0) return
      const visible = charBudget < word.length ? word.slice(0, charBudget) : word
      charBudget -= word.length + 1
      wordBudget -= 1
      if (l.strokeWidth > 0) {
        ctx.strokeStyle = l.strokeColor
        ctx.lineWidth = l.strokeWidth * 2
        ctx.strokeText(visible, x, y)
      }
      ctx.fillStyle = wordIndex === activeWord ? l.highlightColor : l.color
      ctx.fillText(visible, x, y)
      x += ctx.measureText(word).width + space
      wordIndex++
    }
  })
  ctx.letterSpacing = '0px'
}

/* ---------- Comment card ---------- */

const CARD = { W: 286, padT: 14, padX: 16, padB: 17, avatar: 31, gap: 8, name: 18.5, handle: 9.5, text: 15.5, lh: 1.3, textGap: 8.5, radius: 14 }
const REPLY = { W: 286, padT: 11, padX: 12, padB: 12, avatar: 26, gap: 9, header: 10.5, text: 14.5, lh: 1.25, radius: 10 }

const isReplyVariant = (v: CommentLayer['variant']) => v === 'tiktok-reply' || v === 'ig-reply'

const CARD_THEME: Record<string, { bg: string; name: string; handle: string; text: string }> = {
  'card-light': { bg: '#ffffff', name: '#0f0f0f', handle: '#6b6b6b', text: '#0f0f0f' },
  'card-dark': { bg: '#16181c', name: '#ffffff', handle: '#8b98a5', text: '#e7e9ea' },
  'yt-comment': { bg: '#0f0f0f', name: '#f1f1f1', handle: '#aaaaaa', text: '#f1f1f1' },
  'x-post': { bg: '#ffffff', name: '#0f1419', handle: '#536471', text: '#0f1419' },
  'chat-bubble': { bg: '#0a84ff', name: '#ffffff', handle: '#d6e9ff', text: '#ffffff' },
}

export interface CommentLayout {
  s: number
  lines: string[]
  height: number
}

export function layoutComment(l: CommentLayer): CommentLayout {
  const key = `c|${l.variant}|${l.text}|${l.width}`
  const hit = layoutCache.get(key) as CommentLayout | undefined
  if (hit) return hit
  const ctx = mctx()
  let out: CommentLayout
  if (isReplyVariant(l.variant)) {
    const s = l.width / REPLY.W
    ctx.font = `700 ${REPLY.text * s}px ${HELV}`
    const lines = wrap(ctx, l.text, (REPLY.W - REPLY.padX * 2 - REPLY.avatar - REPLY.gap) * s)
    const body = REPLY.header * 1.3 + 3 + lines.length * REPLY.text * REPLY.lh
    out = { s, lines, height: (REPLY.padT + Math.max(REPLY.avatar, body) + REPLY.padB) * s }
  } else {
    const s = l.width / CARD.W
    ctx.font = `400 ${CARD.text * s}px ${HELV}`
    const lines = wrap(ctx, l.text, (CARD.W - CARD.padX * 2) * s)
    out = { s, lines, height: (CARD.padT + CARD.avatar + CARD.textGap + lines.length * CARD.text * CARD.lh + CARD.padB) * s }
  }
  layoutCache.set(key, out)
  return out
}

function drawAvatar(ctx: Ctx, project: Project, l: CommentLayer, x: number, y: number, size: number) {
  ctx.save()
  ctx.beginPath()
  ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2)
  ctx.clip()
  const asset = l.avatarAssetId ? project.assets.find((a) => a.id === l.avatarAssetId) : null
  const img = asset ? getImage(asset) : null
  if (img) {
    const sc = Math.max(size / img.naturalWidth, size / img.naturalHeight)
    const cw = size / sc
    const ch = size / sc
    ctx.drawImage(img, (img.naturalWidth - cw) / 2, (img.naturalHeight - ch) / 2, cw, ch, x, y, size, size)
  } else {
    ctx.fillStyle = '#d9d9d9'
    ctx.fillRect(x, y, size, size)
    ctx.fillStyle = '#a8a8a8'
    ctx.beginPath()
    ctx.arc(x + size / 2, y + size * 0.4, size * 0.19, 0, Math.PI * 2)
    ctx.fill()
    ctx.beginPath()
    ctx.ellipse(x + size / 2, y + size * 0.98, size * 0.34, size * 0.3, 0, Math.PI, 0)
    ctx.fill()
  }
  ctx.restore()
}

function drawVerified(ctx: Ctx, x: number, y: number, r: number) {
  ctx.fillStyle = '#1d9bf0'
  ctx.beginPath()
  ctx.arc(x + r, y, r, 0, Math.PI * 2)
  ctx.fill()
  ctx.strokeStyle = '#fff'
  ctx.lineWidth = r * 0.28
  ctx.lineCap = 'round'
  ctx.lineJoin = 'round'
  ctx.beginPath()
  ctx.moveTo(x + r * 0.55, y)
  ctx.lineTo(x + r * 0.9, y + r * 0.35)
  ctx.lineTo(x + r * 1.5, y - r * 0.35)
  ctx.stroke()
}

function drawComment(ctx: Ctx, project: Project, l: CommentLayer) {
  const L = layoutComment(l)
  const s = L.s
  const w = l.width
  const h = L.height
  ctx.translate(-w / 2, -h / 2)
  const isReply = isReplyVariant(l.variant)
  const theme = CARD_THEME[l.variant] ?? CARD_THEME['card-light']
  const isBubble = l.variant === 'chat-bubble'
  ctx.save()
  ctx.shadowColor = 'rgba(0,0,0,0.2)'
  ctx.shadowBlur = 12 * s
  ctx.shadowOffsetY = 2 * s
  ctx.fillStyle = isReply ? '#ffffff' : theme.bg
  ctx.beginPath()
  const r = (isReply ? REPLY.radius : isBubble ? 22 : CARD.radius) * s
  ctx.roundRect(0, 0, w, h, isBubble ? [r, r, 4 * s, r] : r)
  ctx.fill()
  ctx.restore()
  ctx.textBaseline = 'alphabetic'
  ctx.textAlign = 'left'

  if (isReply) {
    const ax = REPLY.padX * s
    const ay = REPLY.padT * s
    drawAvatar(ctx, project, l, ax, ay, REPLY.avatar * s)
    const tx = ax + (REPLY.avatar + REPLY.gap) * s
    ctx.fillStyle = '#7a7a7a'
    ctx.font = `500 ${REPLY.header * s}px ${HELV}`
    ctx.fillText(l.variant === 'ig-reply' ? `Replying to ${l.handle}` : `Reply to ${l.author}'s comment`, tx, ay + REPLY.header * s)
    ctx.fillStyle = '#121212'
    ctx.font = `700 ${REPLY.text * s}px ${HELV}`
    L.lines.forEach((ln, i) => {
      ctx.fillText(ln, tx, ay + (REPLY.header * 1.3 + 3 + REPLY.text * 0.95 + i * REPLY.text * REPLY.lh) * s)
    })
    return
  }

  const ax = CARD.padX * s
  const ay = CARD.padT * s
  drawAvatar(ctx, project, l, ax, ay, CARD.avatar * s)
  const nx = ax + (CARD.avatar + CARD.gap) * s
  ctx.fillStyle = theme.name
  ctx.font = `700 ${CARD.name * s}px ${HELV}`
  const nameY = ay + CARD.name * 0.95 * s
  ctx.fillText(l.author, nx, nameY)
  if (l.verified) drawVerified(ctx, nx + ctx.measureText(l.author).width + 4 * s, nameY - CARD.name * 0.36 * s, 6.5 * s)
  ctx.fillStyle = theme.handle
  ctx.font = `400 ${CARD.handle * s}px ${HELV}`
  ctx.fillText(l.variant === 'yt-comment' ? `${l.handle} \u00b7 2h ago` : l.handle, nx, ay + (CARD.avatar - 1.5) * s)
  ctx.fillStyle = theme.text
  ctx.font = `400 ${CARD.text * s}px ${HELV}`
  const y0 = ay + (CARD.avatar + CARD.textGap) * s
  L.lines.forEach((ln, i) => {
    ctx.fillText(ln, ax, y0 + (i * CARD.text * CARD.lh + CARD.text * 0.98) * s)
  })
}

/* ---------- Shapes ---------- */

function shapePath(ctx: Ctx, l: ShapeLayer, w: number, h: number) {
  ctx.beginPath()
  switch (l.shape) {
    case 'rect':
    case 'progress':
      ctx.roundRect(-w / 2, -h / 2, w, h, Math.min(l.radius, w / 2, h / 2))
      break
    case 'circle':
      ctx.ellipse(0, 0, w / 2, h / 2, 0, 0, Math.PI * 2)
      break
    case 'triangle':
      ctx.moveTo(0, -h / 2)
      ctx.lineTo(w / 2, h / 2)
      ctx.lineTo(-w / 2, h / 2)
      ctx.closePath()
      break
    case 'star':
      for (let i = 0; i < 10; i++) {
        const r = i % 2 === 0 ? 1 : 0.45
        const a = -Math.PI / 2 + (i * Math.PI) / 5
        const px = Math.cos(a) * r * (w / 2)
        const py = Math.sin(a) * r * (h / 2) + h * 0.05
        if (i === 0) ctx.moveTo(px, py)
        else ctx.lineTo(px, py)
      }
      ctx.closePath()
      break
    case 'heart': {
      const sx = w / 2
      const sy = h / 2
      ctx.moveTo(0, 0.9 * sy)
      ctx.bezierCurveTo(-1.3 * sx, 0.1 * sy, -0.75 * sx, -1.05 * sy, 0, -0.45 * sy)
      ctx.bezierCurveTo(0.75 * sx, -1.05 * sy, 1.3 * sx, 0.1 * sy, 0, 0.9 * sy)
      ctx.closePath()
      break
    }
    case 'arrow': {
      const hl = Math.min(w * 0.45, h)
      const sh = h * 0.18
      ctx.moveTo(-w / 2, -sh)
      ctx.lineTo(w / 2 - hl, -sh)
      ctx.lineTo(w / 2 - hl, -h / 2)
      ctx.lineTo(w / 2, 0)
      ctx.lineTo(w / 2 - hl, h / 2)
      ctx.lineTo(w / 2 - hl, sh)
      ctx.lineTo(-w / 2, sh)
      ctx.closePath()
      break
    }
  }
}

function drawShape(ctx: Ctx, l: ShapeLayer, t: number) {
  const w = l.width
  const h = l.height
  if (l.shape === 'progress') {
    shapePath(ctx, l, w, h)
    ctx.fillStyle = l.stroke
    ctx.fill()
    const p = clamp((t - l.start) / l.duration)
    ctx.save()
    shapePath(ctx, l, w, h)
    ctx.clip()
    ctx.fillStyle = l.fill
    ctx.fillRect(-w / 2, -h / 2, w * p, h)
    ctx.restore()
    return
  }
  shapePath(ctx, l, w, h)
  if (l.fill !== 'transparent') {
    ctx.fillStyle = l.fill
    ctx.fill()
  }
  if (l.strokeWidth > 0) {
    ctx.strokeStyle = l.stroke
    ctx.lineWidth = l.strokeWidth
    ctx.lineJoin = 'round'
    ctx.stroke()
  }
}

/* ---------- Stickers ---------- */

function fitFont(ctx: Ctx, text: string, maxW: number, size: number, weight: number, family: string) {
  let s = size
  ctx.font = `${weight} ${s}px ${family}`
  while (s > 6 && ctx.measureText(text).width > maxW) {
    s *= 0.92
    ctx.font = `${weight} ${s}px ${family}`
  }
  return s
}

function drawSticker(ctx: Ctx, l: StickerLayer, t: number) {
  const w = l.width
  const h = l.height
  const sans = fontFamily('geist')
  ctx.translate(-w / 2, -h / 2)
  ctx.textBaseline = 'middle'
  ctx.textAlign = 'center'
  const pill = (fill: string, r = h / 2) => {
    ctx.fillStyle = fill
    ctx.beginPath()
    ctx.roundRect(0, 0, w, h, r)
    ctx.fill()
  }
  switch (l.sticker) {
    case 'subscribe': {
      pill(l.color, h * 0.22)
      const icon = h * 0.42
      const ix = h * 0.32
      ctx.fillStyle = '#fff'
      ctx.beginPath()
      ctx.roundRect(ix, (h - icon * 0.72) / 2, icon, icon * 0.72, icon * 0.2)
      ctx.fill()
      ctx.fillStyle = l.color
      ctx.beginPath()
      ctx.moveTo(ix + icon * 0.4, h / 2 - icon * 0.18)
      ctx.lineTo(ix + icon * 0.68, h / 2)
      ctx.lineTo(ix + icon * 0.4, h / 2 + icon * 0.18)
      ctx.fill()
      ctx.fillStyle = l.textColor
      const tx = ix + icon + h * 0.22
      fitFont(ctx, l.label, w - tx - h * 0.3, h * 0.4, 800, sans)
      ctx.textAlign = 'left'
      ctx.fillText(l.label, tx, h / 2 + h * 0.02)
      break
    }
    case 'follow':
    case 'label':
    case 'new':
    case 'live': {
      pill(l.color, l.sticker === 'live' || l.sticker === 'new' ? h * 0.18 : h / 2)
      if (l.sticker === 'live') {
        ctx.fillStyle = l.textColor
        ctx.beginPath()
        ctx.arc(h * 0.42, h / 2, h * 0.11, 0, Math.PI * 2)
        ctx.fill()
        fitFont(ctx, l.label, w - h * 0.9, h * 0.46, 800, sans)
        ctx.fillText(l.label, w / 2 + h * 0.18, h / 2 + h * 0.02)
      } else {
        fitFont(ctx, l.label, w - h * 0.6, h * 0.46, 800, sans)
        ctx.fillStyle = l.textColor
        ctx.fillText(l.label, w / 2, h / 2 + h * 0.02)
      }
      break
    }
    case 'like': {
      pill('#ffffff')
      const r = h * 0.26
      const cx = h * 0.55
      ctx.fillStyle = l.color
      ctx.beginPath()
      ctx.moveTo(cx, h / 2 + r * 0.9)
      ctx.bezierCurveTo(cx - r * 1.3, h / 2 + r * 0.1, cx - r * 0.75, h / 2 - r * 1.05, cx, h / 2 - r * 0.45)
      ctx.bezierCurveTo(cx + r * 0.75, h / 2 - r * 1.05, cx + r * 1.3, h / 2 + r * 0.1, cx, h / 2 + r * 0.9)
      ctx.fill()
      ctx.fillStyle = l.textColor
      ctx.textAlign = 'left'
      fitFont(ctx, l.label, w - h * 1.2, h * 0.42, 800, sans)
      ctx.fillText(l.label, h * 0.98, h / 2 + h * 0.02)
      break
    }
    case 'lower-third': {
      ctx.fillStyle = 'rgba(12,12,14,0.86)'
      ctx.beginPath()
      ctx.roundRect(0, 0, w, h, h * 0.08)
      ctx.fill()
      ctx.fillStyle = l.color
      ctx.fillRect(0, 0, h * 0.07, h)
      ctx.textAlign = 'left'
      ctx.fillStyle = l.textColor
      fitFont(ctx, l.label, w - h * 0.5, h * 0.34, 800, sans)
      ctx.fillText(l.label, h * 0.3, h * 0.38)
      ctx.fillStyle = '#a1a1aa'
      fitFont(ctx, l.sublabel, w - h * 0.5, h * 0.2, 500, sans)
      ctx.fillText(l.sublabel, h * 0.3, h * 0.72)
      break
    }
    case 'question': {
      ctx.save()
      ctx.shadowColor = 'rgba(0,0,0,0.25)'
      ctx.shadowBlur = h * 0.08
      pill('#ffffff', h * 0.12)
      ctx.restore()
      ctx.fillStyle = l.color
      ctx.beginPath()
      ctx.roundRect(0, 0, w, h * 0.5, [h * 0.12, h * 0.12, 0, 0])
      ctx.fill()
      ctx.fillStyle = l.textColor
      fitFont(ctx, l.label, w * 0.86, h * 0.16, 700, sans)
      ctx.fillText(l.label, w / 2, h * 0.26)
      ctx.fillStyle = '#efefef'
      ctx.beginPath()
      ctx.roundRect(w * 0.08, h * 0.6, w * 0.84, h * 0.26, h * 0.08)
      ctx.fill()
      ctx.fillStyle = '#8e8e8e'
      fitFont(ctx, l.sublabel, w * 0.76, h * 0.11, 500, sans)
      ctx.fillText(l.sublabel, w / 2, h * 0.73)
      break
    }
    case 'countdown': {
      pill('rgba(12,12,14,0.86)', h * 0.14)
      const remaining = Math.max(0, l.duration - (t - l.start))
      const secs = Math.ceil(remaining)
      ctx.fillStyle = '#a1a1aa'
      fitFont(ctx, l.label, w * 0.86, h * 0.14, 600, sans)
      ctx.fillText(l.label, w / 2, h * 0.2)
      ctx.fillStyle = l.color
      const txt = `00:${String(secs).padStart(2, '0')}`
      fitFont(ctx, txt, w * 0.86, h * 0.48, 700, fontFamily('mono'))
      ctx.fillText(txt, w / 2, h * 0.6)
      break
    }
    case 'mention':
    case 'hashtag':
    case 'location':
    case 'link':
    case 'save':
    case 'share':
    case 'tap': {
      ctx.save()
      ctx.shadowColor = 'rgba(0,0,0,0.22)'
      ctx.shadowBlur = h * 0.12
      pill(l.color, l.sticker === 'tap' ? h / 2 : h * 0.22)
      ctx.restore()
      const icon = h * 0.42
      const ix = h * 0.3
      drawStickerIcon(ctx, l.sticker, ix, (h - icon) / 2, icon, l.textColor)
      ctx.fillStyle = l.textColor
      ctx.textAlign = 'left'
      const tx = ix + icon + h * 0.16
      fitFont(ctx, l.label.toUpperCase(), w - tx - h * 0.26, h * 0.4, 800, sans)
      ctx.fillText(l.label.toUpperCase(), tx, h / 2 + h * 0.02)
      break
    }
    case 'poll':
    case 'quiz': {
      const opts = l.sublabel.split('|').map((o) => o.trim()).filter(Boolean)
      ctx.save()
      ctx.shadowColor = 'rgba(0,0,0,0.25)'
      ctx.shadowBlur = h * 0.06
      pill('#ffffff', w * 0.05)
      ctx.restore()
      const headH = h * (l.sticker === 'quiz' ? 0.26 : 0.32)
      ctx.fillStyle = l.color
      ctx.beginPath()
      ctx.roundRect(0, 0, w, headH, [w * 0.05, w * 0.05, 0, 0])
      ctx.fill()
      ctx.fillStyle = l.textColor
      fitFont(ctx, l.label, w * 0.86, headH * 0.36, 800, sans)
      ctx.fillText(l.label, w / 2, headH / 2)
      const n = Math.max(1, opts.length)
      const pad = w * 0.06
      const gap = h * 0.04
      const rowH = (h - headH - pad * 2 - gap * (n - 1)) / n
      opts.forEach((o, i) => {
        const y = headH + pad + i * (rowH + gap)
        ctx.fillStyle = '#f1f1f3'
        ctx.beginPath()
        ctx.roundRect(pad, y, w - pad * 2, rowH, rowH * 0.3)
        ctx.fill()
        ctx.textAlign = l.sticker === 'quiz' ? 'left' : 'center'
        if (l.sticker === 'quiz') {
          const r = rowH * 0.26
          ctx.fillStyle = '#d4d4d8'
          ctx.beginPath()
          ctx.arc(pad + rowH * 0.5, y + rowH / 2, r, 0, Math.PI * 2)
          ctx.fill()
          ctx.fillStyle = '#ffffff'
          fitFont(ctx, String.fromCharCode(65 + i), r * 1.4, r * 1.2, 800, sans)
          ctx.textAlign = 'center'
          ctx.fillText(String.fromCharCode(65 + i), pad + rowH * 0.5, y + rowH / 2 + r * 0.06)
          ctx.textAlign = 'left'
        }
        ctx.fillStyle = '#18181b'
        const ox = l.sticker === 'quiz' ? pad + rowH : w / 2
        fitFont(ctx, o, w - pad * 2 - (l.sticker === 'quiz' ? rowH * 1.2 : rowH * 0.6), rowH * 0.4, 700, sans)
        ctx.fillText(o, ox, y + rowH / 2 + rowH * 0.02)
      })
      break
    }
    case 'slider': {
      ctx.save()
      ctx.shadowColor = 'rgba(0,0,0,0.25)'
      ctx.shadowBlur = h * 0.1
      pill('#ffffff', h * 0.14)
      ctx.restore()
      ctx.fillStyle = l.textColor
      fitFont(ctx, l.label, w * 0.86, h * 0.17, 800, sans)
      ctx.fillText(l.label, w / 2, h * 0.3)
      const v = clamp(Number.parseFloat(l.sublabel) || 0.5, 0, 1)
      const bx = w * 0.1
      const bw = w * 0.8
      const by = h * 0.66
      const bh = h * 0.07
      ctx.fillStyle = '#e4e4e7'
      ctx.beginPath()
      ctx.roundRect(bx, by - bh / 2, bw, bh, bh / 2)
      ctx.fill()
      ctx.fillStyle = l.color
      ctx.beginPath()
      ctx.roundRect(bx, by - bh / 2, bw * v, bh, bh / 2)
      ctx.fill()
      ctx.beginPath()
      ctx.arc(bx + bw * v, by, h * 0.11, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = h * 0.025
      ctx.stroke()
      break
    }
    case 'add-yours': {
      ctx.save()
      ctx.shadowColor = 'rgba(0,0,0,0.3)'
      ctx.shadowBlur = h * 0.08
      pill(l.color, h * 0.12)
      ctx.restore()
      ctx.fillStyle = l.textColor
      fitFont(ctx, l.label, w * 0.8, h * 0.18, 800, sans)
      ctx.fillText(l.label, w / 2, h * 0.28)
      ctx.globalAlpha = 0.85
      fitFont(ctx, l.sublabel, w * 0.86, h * 0.13, 500, sans)
      ctx.fillText(l.sublabel, w / 2, h * 0.52)
      ctx.globalAlpha = 1
      ctx.fillStyle = 'rgba(255,255,255,0.16)'
      ctx.beginPath()
      ctx.roundRect(w * 0.3, h * 0.66, w * 0.4, h * 0.2, h * 0.1)
      ctx.fill()
      ctx.fillStyle = l.textColor
      fitFont(ctx, 'Add yours', w * 0.34, h * 0.1, 700, sans)
      ctx.fillText('Add yours', w / 2, h * 0.76)
      break
    }
    case 'notification': {
      ctx.save()
      ctx.shadowColor = 'rgba(0,0,0,0.25)'
      ctx.shadowBlur = h * 0.14
      pill(l.color, h * 0.22)
      ctx.restore()
      const a = h * 0.5
      ctx.fillStyle = '#34c759'
      ctx.beginPath()
      ctx.roundRect(h * 0.2, (h - a) / 2, a, a, a * 0.24)
      ctx.fill()
      ctx.fillStyle = '#ffffff'
      ctx.beginPath()
      ctx.ellipse(h * 0.2 + a / 2, h / 2, a * 0.3, a * 0.24, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.textAlign = 'left'
      const tx = h * 0.2 + a + h * 0.16
      ctx.fillStyle = l.textColor
      fitFont(ctx, l.label, w - tx - h * 0.9, h * 0.2, 700, sans)
      ctx.fillText(l.label, tx, h * 0.36)
      ctx.fillStyle = '#71717a'
      ctx.textAlign = 'right'
      fitFont(ctx, 'now', h * 0.6, h * 0.15, 500, sans)
      ctx.fillText('now', w - h * 0.22, h * 0.36)
      ctx.textAlign = 'left'
      ctx.fillStyle = '#3f3f46'
      fitFont(ctx, l.sublabel, w - tx - h * 0.22, h * 0.18, 400, sans)
      ctx.fillText(l.sublabel, tx, h * 0.64)
      break
    }
    case 'music': {
      pill(l.color, h * 0.2)
      const a = h * 0.64
      const ax = h * 0.18
      ctx.fillStyle = '#ff2d55'
      ctx.beginPath()
      ctx.roundRect(ax, (h - a) / 2, a, a, a * 0.16)
      ctx.fill()
      ctx.fillStyle = '#ffffff'
      ctx.beginPath()
      ctx.arc(ax + a * 0.42, h / 2 + a * 0.16, a * 0.13, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillRect(ax + a * 0.52, h / 2 - a * 0.28, a * 0.07, a * 0.44)
      const tx = ax + a + h * 0.16
      const barsW = h * 0.5
      ctx.textAlign = 'left'
      ctx.fillStyle = l.textColor
      fitFont(ctx, l.label, w - tx - barsW - h * 0.2, h * 0.22, 800, sans)
      ctx.fillText(l.label, tx, h * 0.38)
      ctx.fillStyle = '#71717a'
      fitFont(ctx, l.sublabel, w - tx - barsW - h * 0.2, h * 0.17, 500, sans)
      ctx.fillText(l.sublabel, tx, h * 0.64)
      ctx.fillStyle = '#ff2d55'
      for (let i = 0; i < 4; i++) {
        const bh = h * (0.14 + 0.2 * Math.abs(Math.sin(t * 6 + i * 1.3)))
        ctx.fillRect(w - barsW - h * 0.12 + i * barsW * 0.26, h / 2 - bh / 2, barsW * 0.14, bh)
      }
      break
    }
    case 'gif': {
      const bounce = 1 + 0.06 * Math.sin(t * 8)
      ctx.save()
      ctx.translate(w / 2, h / 2)
      ctx.scale(bounce, bounce)
      ctx.rotate(Math.sin(t * 5) * 0.06)
      ctx.fillStyle = l.color
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = w * 0.03
      ctx.beginPath()
      const spikes = 12
      for (let i = 0; i < spikes * 2; i++) {
        const r = (i % 2 ? 0.36 : 0.48) * w
        const a = (i / (spikes * 2)) * Math.PI * 2
        ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r)
      }
      ctx.closePath()
      ctx.fill()
      ctx.stroke()
      ctx.fillStyle = l.textColor
      fitFont(ctx, l.label, w * 0.6, w * 0.22, 900, sans)
      ctx.fillText(l.label, 0, w * 0.01)
      ctx.restore()
      break
    }
    case 'reveal': {
      pill(l.color, h * 0.1)
      ctx.save()
      ctx.globalAlpha = 0.18
      ctx.fillStyle = l.textColor
      for (let y = h * 0.08; y < h; y += h * 0.08) ctx.fillRect(w * 0.06, y, w * 0.88, h * 0.03)
      ctx.restore()
      const r = h * 0.12
      ctx.strokeStyle = l.textColor
      ctx.lineWidth = r * 0.28
      ctx.beginPath()
      ctx.arc(w / 2, h * 0.3, r * 0.7, Math.PI, 0)
      ctx.stroke()
      ctx.fillStyle = l.textColor
      ctx.beginPath()
      ctx.roundRect(w / 2 - r, h * 0.3, r * 2, r * 1.5, r * 0.25)
      ctx.fill()
      fitFont(ctx, l.label, w * 0.86, h * 0.13, 800, sans)
      ctx.fillText(l.label, w / 2, h * 0.68)
      ctx.globalAlpha = 0.7
      fitFont(ctx, l.sublabel, w * 0.86, h * 0.08, 500, sans)
      ctx.fillText(l.sublabel, w / 2, h * 0.84)
      ctx.globalAlpha = 1
      break
    }
    case 'frame-polaroid': {
      ctx.save()
      ctx.shadowColor = 'rgba(0,0,0,0.3)'
      ctx.shadowBlur = w * 0.04
      ctx.shadowOffsetY = w * 0.015
      const m = w * 0.06
      ctx.fillStyle = l.color
      ctx.beginPath()
      ctx.rect(0, 0, w, h)
      ctx.rect(m, m, w - m * 2, w - m * 2)
      ctx.fill('evenodd')
      ctx.restore()
      ctx.fillStyle = l.textColor
      fitFont(ctx, l.label, w - m * 2, (h - w) * 0.42, 400, fontFamily('marker'))
      ctx.fillText(l.label, w / 2, w - m + (h - w + m) / 2)
      break
    }
    case 'frame-film': {
      const band = h * 0.12
      ctx.fillStyle = l.color
      ctx.fillRect(0, 0, w, band)
      ctx.fillRect(0, h - band, w, band)
      ctx.fillStyle = '#e4e4e7'
      const holeW = band * 0.42
      const offset = (t * band * 2) % (holeW * 2.2)
      for (let x = -holeW * 2.2 + offset; x < w; x += holeW * 2.2) {
        ctx.beginPath()
        ctx.roundRect(x, band * 0.3, holeW, band * 0.4, band * 0.08)
        ctx.roundRect(x, h - band * 0.7, holeW, band * 0.4, band * 0.08)
        ctx.fill()
      }
      ctx.fillStyle = l.textColor
      ctx.textAlign = 'left'
      ctx.font = `700 ${band * 0.26}px ${fontFamily('mono')}`
      ctx.fillText('KODAK 400  ▸ 24A', w * 0.04, h - band * 0.12)
      break
    }
    case 'frame-phone': {
      const bezel = w * 0.045
      const r = w * 0.14
      ctx.fillStyle = l.color
      ctx.beginPath()
      ctx.roundRect(0, 0, w, h, r)
      ctx.roundRect(bezel, bezel, w - bezel * 2, h - bezel * 2, r - bezel)
      ctx.fill('evenodd')
      ctx.beginPath()
      ctx.roundRect(w * 0.36, bezel * 1.6, w * 0.28, bezel * 1.4, bezel * 0.7)
      ctx.fill()
      ctx.strokeStyle = 'rgba(255,255,255,0.12)'
      ctx.lineWidth = w * 0.006
      ctx.beginPath()
      ctx.roundRect(1, 1, w - 2, h - 2, r)
      ctx.stroke()
      break
    }
    case 'frame-border': {
      const b = Math.min(w, h) * 0.035
      ctx.fillStyle = l.color
      ctx.beginPath()
      ctx.rect(0, 0, w, h)
      ctx.roundRect(b, b, w - b * 2, h - b * 2, b * 1.2)
      ctx.fill('evenodd')
      break
    }
    case 'frame-tape': {
      ctx.globalAlpha = 0.82
      ctx.fillStyle = l.color
      ctx.beginPath()
      const teeth = 7
      ctx.moveTo(0, 0)
      ctx.lineTo(w, 0)
      for (let i = 0; i <= teeth; i++) ctx.lineTo(w - (i % 2 ? w * 0.03 : 0), (i / teeth) * h)
      ctx.lineTo(0, h)
      for (let i = teeth; i >= 0; i--) ctx.lineTo(i % 2 ? w * 0.03 : 0, (i / teeth) * h)
      ctx.closePath()
      ctx.fill()
      ctx.globalAlpha = 1
      break
    }
  }
}

function drawStickerIcon(ctx: Ctx, type: StickerLayer['sticker'], x: number, y: number, s: number, color: string) {
  ctx.save()
  ctx.fillStyle = color
  ctx.strokeStyle = color
  ctx.lineWidth = s * 0.14
  ctx.lineCap = 'round'
  ctx.lineJoin = 'round'
  const cx = x + s / 2
  const cy = y + s / 2
  switch (type) {
    case 'mention':
    case 'hashtag':
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.font = `900 ${s * 1.05}px ${fontFamily('geist')}`
      ctx.fillText(type === 'mention' ? '@' : '#', cx, cy + s * 0.04)
      break
    case 'location':
      ctx.beginPath()
      ctx.arc(cx, y + s * 0.38, s * 0.34, Math.PI * 0.85, Math.PI * 2.15)
      ctx.lineTo(cx, y + s)
      ctx.closePath()
      ctx.fill()
      ctx.fillStyle = '#ffffff'
      ctx.beginPath()
      ctx.arc(cx, y + s * 0.38, s * 0.13, 0, Math.PI * 2)
      ctx.fill()
      break
    case 'link':
      ctx.translate(cx, cy)
      ctx.rotate(-Math.PI / 4)
      ctx.beginPath()
      ctx.roundRect(-s * 0.5, -s * 0.18, s * 0.58, s * 0.36, s * 0.18)
      ctx.roundRect(-s * 0.08, -s * 0.18, s * 0.58, s * 0.36, s * 0.18)
      ctx.stroke()
      break
    case 'save':
      ctx.beginPath()
      ctx.moveTo(x + s * 0.2, y)
      ctx.lineTo(x + s * 0.8, y)
      ctx.lineTo(x + s * 0.8, y + s)
      ctx.lineTo(cx, y + s * 0.7)
      ctx.lineTo(x + s * 0.2, y + s)
      ctx.closePath()
      ctx.stroke()
      break
    case 'share':
      ctx.beginPath()
      ctx.moveTo(x, y + s * 0.42)
      ctx.lineTo(x + s, y)
      ctx.lineTo(x + s * 0.62, y + s)
      ctx.lineTo(x + s * 0.44, y + s * 0.56)
      ctx.closePath()
      ctx.stroke()
      break
    case 'tap':
      ctx.beginPath()
      ctx.arc(cx, cy, s * 0.2, 0, Math.PI * 2)
      ctx.fill()
      ctx.beginPath()
      ctx.arc(cx, cy, s * 0.45, 0, Math.PI * 2)
      ctx.stroke()
      break
  }
  ctx.restore()
}

/* ---------- Media ---------- */

function drawMedia(ctx: Ctx, project: Project, l: MediaLayer) {
  const w = l.width
  const h = l.height
  const asset = project.assets.find((a) => a.id === l.assetId)
  let src: CanvasImageSource | null = null
  let sw = 0
  let sh = 0
  if (asset?.type === 'image') {
    const img = getImage(asset)
    if (img) {
      src = img
      sw = img.naturalWidth
      sh = img.naturalHeight
    }
  } else if (asset?.type === 'video') {
    const v = getVideoFrame(l.id)
    if (v) {
      src = v
      sw = v.videoWidth
      sh = v.videoHeight
    }
  }
  ctx.save()
  if (l.radius > 0) {
    ctx.beginPath()
    ctx.roundRect(-w / 2, -h / 2, w, h, Math.min(l.radius, w / 2, h / 2))
    ctx.clip()
  }
  if (l.flipX) ctx.scale(-1, 1)
  if (!src || !sw || !sh) {
    ctx.fillStyle = '#1f1f24'
    ctx.fillRect(-w / 2, -h / 2, w, h)
  } else {
    const sc = Math.max(w / sw, h / sh)
    const cw = w / sc
    const ch = h / sc
    ctx.drawImage(src, (sw - cw) / 2, (sh - ch) / 2, cw, ch, -w / 2, -h / 2, w, h)
  }
  ctx.restore()
}

/* ---------- Effects ---------- */

let grainCanvas: HTMLCanvasElement | null = null
function grain() {
  if (grainCanvas) return grainCanvas
  grainCanvas = document.createElement('canvas')
  grainCanvas.width = 256
  grainCanvas.height = 256
  const g = grainCanvas.getContext('2d')!
  const data = g.createImageData(256, 256)
  for (let i = 0; i < data.data.length; i += 4) {
    const v = Math.random() * 255
    data.data[i] = v
    data.data[i + 1] = v
    data.data[i + 2] = v
    data.data[i + 3] = 255
  }
  g.putImageData(data, 0, 0)
  return grainCanvas
}

function drawEffect(ctx: Ctx, project: Project, l: EffectLayer, t: number) {
  const W = project.width
  const H = project.height
  const local = t - l.start
  const p = clamp(local / l.duration)
  const I = l.intensity
  switch (l.effect) {
    case 'vignette': {
      const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.72)
      g.addColorStop(0, 'rgba(0,0,0,0)')
      g.addColorStop(1, `rgba(0,0,0,${0.9 * I})`)
      ctx.fillStyle = g
      ctx.fillRect(0, 0, W, H)
      break
    }
    case 'grain': {
      const pat = ctx.createPattern(grain(), 'repeat')
      if (!pat) break
      const f = Math.floor(t * 24)
      pat.setTransform(new DOMMatrix().translate((f * 73) % 256, (f * 151) % 256).scale(1.6))
      ctx.globalAlpha *= 0.28 * I
      ctx.globalCompositeOperation = 'overlay'
      ctx.fillStyle = pat
      ctx.fillRect(0, 0, W, H)
      break
    }
    case 'letterbox': {
      const bar = (W > H ? H * 0.12 : H * 0.09) * I
      ctx.fillStyle = '#000'
      ctx.fillRect(0, 0, W, bar)
      ctx.fillRect(0, H - bar, W, bar)
      break
    }
    case 'flash': {
      ctx.globalAlpha *= I * (1 - easeOutQuad(p))
      ctx.fillStyle = l.color
      ctx.fillRect(0, 0, W, H)
      break
    }
    case 'fade-black': {
      ctx.globalAlpha *= I * p
      ctx.fillStyle = '#000'
      ctx.fillRect(0, 0, W, H)
      break
    }
    case 'light-leak': {
      ctx.globalCompositeOperation = 'screen'
      const cx = W * (0.2 + 0.6 * (0.5 + 0.5 * Math.sin(t * 0.9)))
      const cy = H * (0.25 + 0.2 * Math.cos(t * 0.7))
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(W, H) * 0.6)
      g.addColorStop(0, `rgba(255,140,60,${0.75 * I})`)
      g.addColorStop(0.45, `rgba(255,60,120,${0.35 * I})`)
      g.addColorStop(1, 'rgba(0,0,0,0)')
      ctx.fillStyle = g
      ctx.fillRect(0, 0, W, H)
      break
    }
    case 'tint': {
      ctx.globalCompositeOperation = 'soft-light'
      ctx.globalAlpha *= I
      ctx.fillStyle = l.color
      ctx.fillRect(0, 0, W, H)
      break
    }
    case 'scanlines': {
      ctx.fillStyle = `rgba(0,0,0,${0.28 * I})`
      for (let y = 0; y < H; y += 6) ctx.fillRect(0, y, W, 2)
      const by = ((t * 0.35) % 1) * H
      ctx.fillStyle = `rgba(255,255,255,${0.08 * I})`
      ctx.fillRect(0, by, W, H * 0.06)
      break
    }
  }
}

const easeOutQuad = (p: number) => 1 - (1 - p) * (1 - p)

interface Camera {
  scale: number
  dx: number
  dy: number
}

function cameraOf(l: EffectLayer, t: number): Camera {
  const local = t - l.start
  const p = clamp(local / l.duration)
  const I = l.intensity
  const cam: Camera = { scale: 1, dx: 0, dy: 0 }
  switch (l.effect) {
    case 'shake': {
      const decay = 1 - p * 0.6
      cam.dx = (Math.sin(t * 61) + Math.sin(t * 37)) * 12 * I * decay
      cam.dy = (Math.cos(t * 47) + Math.sin(t * 29)) * 12 * I * decay
      break
    }
    case 'zoom-punch': {
      const k = p < 0.2 ? p / 0.2 : 1 - (p - 0.2) / 0.8
      cam.scale = 1 + 0.18 * I * (1 - Math.pow(1 - clamp(k), 3))
      break
    }
    case 'ken-burns':
      cam.scale = 1 + 0.16 * I * p
      break
    case 'zoom-pulse': {
      const c = (local % 0.5) / 0.5
      cam.scale = 1 + 0.07 * I * Math.pow(1 - c, 3)
      break
    }
  }
  return cam
}

/* ---------- Layer drawing ---------- */

export function isActive(l: Layer, t: number) {
  return !l.hidden && t >= l.start && t < l.start + l.duration
}

export function getLayerSize(l: Layer): { w: number; h: number } {
  if (l.kind === 'text') return { w: l.width, h: layoutText(l).height }
  if (l.kind === 'comment') return { w: l.width, h: layoutComment(l).height }
  if (l.kind === 'form') return { w: l.width, h: formHeight(l) }
  return { w: l.width, h: l.height }
}

function drawContent(ctx: Ctx, project: Project, l: Layer, t: number, st: AnimState) {
  switch (l.kind) {
    case 'media':
      drawMedia(ctx, project, l)
      break
    case 'text':
      drawText(ctx, l, st)
      break
    case 'shape':
      drawShape(ctx, l, t)
      break
    case 'sticker':
      drawSticker(ctx, l, t)
      break
    case 'comment':
      drawComment(ctx, project, l)
      break
    case 'form':
      drawForm(ctx, project, l)
      break
  }
}

let offscreen: HTMLCanvasElement | null = null
const WARP_MARGIN = 40

function drawWarped(ctx: Ctx, src: HTMLCanvasElement, w: number, h: number, type: WarpType, amount: number) {
  const N = 56
  const W2 = w + WARP_MARGIN * 2
  const H2 = h + WARP_MARGIN * 2
  if (type === 'tilt-left' || type === 'tilt-right') {
    for (let i = 0; i < N; i++) {
      const u = (i + 0.5) / N
      const k = type === 'tilt-left' ? 1 - amount * u : 1 - amount * (1 - u)
      const dh = H2 * k
      ctx.drawImage(src, (i * src.width) / N, 0, src.width / N, src.height, -W2 / 2 + (i * W2) / N, -dh / 2, W2 / N + 0.6, dh)
    }
  } else {
    for (let i = 0; i < N; i++) {
      const v = (i + 0.5) / N
      const k = type === 'bottom-big' ? 1 - amount * (1 - v) : 1 - amount * v
      const dw = W2 * k
      ctx.drawImage(src, 0, (i * src.height) / N, src.width, src.height / N, -dw / 2, -H2 / 2 + (i * H2) / N, dw, H2 / N + 0.6)
    }
  }
}

function drawLayer(ctx: Ctx, project: Project, l: Layer, t: number, cam: Camera, animate = true) {
  if (l.kind === 'audio') return
  const st = animate ? computeAnim(l, t) : identityAnim()
  if (l.kind === 'effect') {
    if (CAMERA_EFFECTS.has(l.effect)) return
    ctx.save()
    ctx.globalAlpha = clamp(st.opacity * l.opacity)
    drawEffect(ctx, project, l, t)
    ctx.restore()
    return
  }
  const { w, h } = getLayerSize(l)
  ctx.save()
  if (cam.scale !== 1 || cam.dx || cam.dy) {
    ctx.translate(project.width / 2 + cam.dx, project.height / 2 + cam.dy)
    ctx.scale(cam.scale, cam.scale)
    ctx.translate(-project.width / 2, -project.height / 2)
  }
  ctx.translate(l.x + st.dx, l.y + st.dy)
  ctx.rotate(((l.rotation + st.rotate) * Math.PI) / 180)
  ctx.scale(st.scale * st.scaleX, st.scale)
  ctx.globalAlpha = clamp(l.opacity * st.opacity)
  const filter = filterString(l, st.blur)
  if (l.warp !== 'none' && l.warpAmount > 0) {
    if (!offscreen) offscreen = document.createElement('canvas')
    offscreen.width = Math.ceil(w + WARP_MARGIN * 2)
    offscreen.height = Math.ceil(h + WARP_MARGIN * 2)
    const octx = offscreen.getContext('2d')!
    octx.save()
    octx.translate(offscreen.width / 2, offscreen.height / 2)
    drawContent(octx, project, l, t, st)
    octx.restore()
    ctx.filter = filter
    drawWarped(ctx, offscreen, w, h, l.warp, l.warpAmount)
  } else {
    ctx.filter = filter
    drawContent(ctx, project, l, t, st)
  }
  ctx.restore()
}

const NO_CAM: Camera = { scale: 1, dx: 0, dy: 0 }

export function drawFrame(ctx: Ctx, project: Project, t: number) {
  const { width: W, height: H, layers } = project
  ctx.setTransform(1, 0, 0, 1, 0, 0)
  ctx.globalAlpha = 1
  ctx.filter = 'none'
  ctx.globalCompositeOperation = 'source-over'
  ctx.fillStyle = project.background
  ctx.fillRect(0, 0, W, H)
  const cams: Camera[] = new Array(layers.length)
  let acc: Camera = NO_CAM
  for (let i = layers.length - 1; i >= 0; i--) {
    cams[i] = acc
    const l = layers[i]
    if (l.kind === 'effect' && CAMERA_EFFECTS.has(l.effect) && isActive(l, t)) {
      const c = cameraOf(l, t)
      acc = { scale: acc.scale * c.scale, dx: acc.dx + c.dx, dy: acc.dy + c.dy }
    }
  }
  for (let i = 0; i < layers.length; i++) {
    if (isActive(layers[i], t)) drawLayer(ctx, project, layers[i], t, cams[i])
  }
}

/** Draws one layer centered and fit inside a thumbnail canvas. */
export function drawLayerThumb(ctx: Ctx, project: Project, l: Layer, cw: number, ch: number) {
  ctx.setTransform(1, 0, 0, 1, 0, 0)
  ctx.clearRect(0, 0, cw, ch)
  const { w, h } = getLayerSize(l)
  const s = Math.min((cw * 0.86) / w, (ch * 0.8) / h)
  ctx.scale(s, s)
  const clone = { ...l, x: cw / 2 / s, y: ch / 2 / s } as Layer
  const t = l.kind === 'shape' && l.shape === 'progress' ? l.start + l.duration * 0.6 : l.start + 0.01
  drawLayer(ctx, project, clone, t, NO_CAM, false)
}

export function hitTest(project: Project, t: number, px: number, py: number): Layer | null {
  for (let i = project.layers.length - 1; i >= 0; i--) {
    const l = project.layers[i]
    if (l.kind === 'audio' || l.kind === 'effect' || !isActive(l, t)) continue
    const { w, h } = getLayerSize(l)
    const a = (-l.rotation * Math.PI) / 180
    const dx = px - l.x
    const dy = py - l.y
    const lx = dx * Math.cos(a) - dy * Math.sin(a)
    const ly = dx * Math.sin(a) + dy * Math.cos(a)
    if (Math.abs(lx) <= w / 2 && Math.abs(ly) <= h / 2) return l
  }
  return null
}
