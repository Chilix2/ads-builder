'use client'

import { useSyncExternalStore } from 'react'

interface PlaybackState {
  time: number
  playing: boolean
  recording: boolean
}

let state: PlaybackState = { time: 0, playing: false, recording: false }
const listeners = new Set<() => void>()

function emit() {
  listeners.forEach((l) => l())
}

export const playback = {
  get: () => state,
  setTime(time: number) {
    if (time === state.time) return
    state = { ...state, time: Math.max(0, time) }
    emit()
  },
  setPlaying(playing: boolean) {
    if (playing === state.playing) return
    state = { ...state, playing }
    emit()
  },
  setRecording(recording: boolean) {
    state = { ...state, recording }
    emit()
  },
  subscribe(listener: () => void) {
    listeners.add(listener)
    return () => {
      listeners.delete(listener)
    }
  },
}

export function usePlayback() {
  return useSyncExternalStore(playback.subscribe, playback.get, playback.get)
}

export function formatTime(t: number) {
  const m = Math.floor(t / 60)
  const s = Math.floor(t % 60)
  const f = Math.floor((t % 1) * 100)
  return `${m}:${String(s).padStart(2, '0')}.${String(f).padStart(2, '0')}`
}
