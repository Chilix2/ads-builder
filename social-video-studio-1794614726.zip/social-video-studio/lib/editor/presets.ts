import type { Adjust, EffectType, Layer } from './types'

export const DEFAULT_ADJUST: Adjust = { brightness: 1, contrast: 1, saturate: 1, blur: 0, hue: 0 }

export const FILTERS: { id: string; name: string; css: string }[] = [
  { id: 'none', name: 'Original', css: '' },
  { id: 'vivid', name: 'Vivid', css: 'saturate(1.45) contrast(1.08)' },
  { id: 'pop', name: 'Pop', css: 'saturate(1.8) contrast(1.15)' },
  { id: 'warm', name: 'Warm', css: 'sepia(0.25) saturate(1.3) hue-rotate(-8deg)' },
  { id: 'golden', name: 'Golden hour', css: 'sepia(0.35) saturate(1.5) brightness(1.05) hue-rotate(-12deg)' },
  { id: 'cool', name: 'Cool', css: 'saturate(1.1) hue-rotate(14deg) brightness(1.03)' },
  { id: 'mono', name: 'Mono', css: 'grayscale(1) contrast(1.1)' },
  { id: 'noir', name: 'Noir', css: 'grayscale(1) contrast(1.5) brightness(0.9)' },
  { id: 'vintage', name: 'Vintage', css: 'sepia(0.45) contrast(0.92) brightness(1.05) saturate(0.85)' },
  { id: 'faded', name: 'Faded', css: 'contrast(0.82) brightness(1.1) saturate(0.8)' },
  { id: 'matte', name: 'Matte', css: 'contrast(0.9) saturate(0.7) brightness(1.05)' },
  { id: 'drama', name: 'Drama', css: 'contrast(1.35) saturate(1.2) brightness(0.92)' },
  { id: 'cyber', name: 'Cyber', css: 'hue-rotate(160deg) saturate(1.6) contrast(1.1)' },
  { id: 'dreamy', name: 'Dreamy', css: 'brightness(1.12) saturate(1.15) blur(1px)' },
]

export function filterString(layer: Pick<Layer, 'filter' | 'adjust'>, extraBlur = 0) {
  const parts: string[] = []
  const preset = FILTERS.find((f) => f.id === layer.filter)
  if (preset?.css) parts.push(preset.css)
  const a = layer.adjust
  if (a.brightness !== 1) parts.push(`brightness(${a.brightness})`)
  if (a.contrast !== 1) parts.push(`contrast(${a.contrast})`)
  if (a.saturate !== 1) parts.push(`saturate(${a.saturate})`)
  if (a.hue !== 0) parts.push(`hue-rotate(${a.hue}deg)`)
  const blur = a.blur + extraBlur
  if (blur > 0.05) parts.push(`blur(${blur.toFixed(2)}px)`)
  return parts.length ? parts.join(' ') : 'none'
}

export const ANIM_IN = [
  { id: 'fade', name: 'Fade' },
  { id: 'pop', name: 'Pop' },
  { id: 'slide-up', name: 'Slide up' },
  { id: 'slide-down', name: 'Slide down' },
  { id: 'slide-left', name: 'Slide left' },
  { id: 'slide-right', name: 'Slide right' },
  { id: 'zoom-in', name: 'Zoom in' },
  { id: 'zoom-out', name: 'Zoom out' },
  { id: 'drop', name: 'Drop bounce' },
  { id: 'spin', name: 'Spin' },
  { id: 'flip', name: 'Flip' },
  { id: 'blur-in', name: 'Blur in' },
  { id: 'typewriter', name: 'Typewriter' },
  { id: 'word-pop', name: 'Word by word' },
]

export const ANIM_OUT = [
  { id: 'fade', name: 'Fade' },
  { id: 'shrink', name: 'Shrink' },
  { id: 'slide-up', name: 'Slide up' },
  { id: 'slide-down', name: 'Slide down' },
  { id: 'slide-left', name: 'Slide left' },
  { id: 'slide-right', name: 'Slide right' },
  { id: 'zoom-in', name: 'Zoom in' },
  { id: 'zoom-out', name: 'Zoom out' },
  { id: 'spin', name: 'Spin' },
  { id: 'flip', name: 'Flip' },
  { id: 'blur-out', name: 'Blur out' },
  { id: 'typewriter', name: 'Erase' },
]

export const LOOPS = [
  { id: 'pulse', name: 'Pulse' },
  { id: 'heartbeat', name: 'Heartbeat' },
  { id: 'float', name: 'Float' },
  { id: 'wiggle', name: 'Wiggle' },
  { id: 'swing', name: 'Swing' },
  { id: 'shake', name: 'Shake' },
  { id: 'spin', name: 'Rotate' },
  { id: 'flicker', name: 'Flicker' },
  { id: 'glitch', name: 'Glitch' },
  { id: 'karaoke', name: 'Karaoke words' },
]

export const EFFECTS: { id: EffectType; name: string; description: string; camera: boolean; duration: number }[] = [
  { id: 'zoom-punch', name: 'Zoom punch', description: 'Fast punch-in on the beat', camera: true, duration: 0.6 },
  { id: 'zoom-pulse', name: 'Beat pulse', description: 'Rhythmic zoom every half second', camera: true, duration: 3 },
  { id: 'ken-burns', name: 'Slow zoom', description: 'Cinematic push-in', camera: true, duration: 5 },
  { id: 'shake', name: 'Camera shake', description: 'Handheld impact shake', camera: true, duration: 0.8 },
  { id: 'flash', name: 'Flash', description: 'White flash transition', camera: false, duration: 0.5 },
  { id: 'fade-black', name: 'Fade to black', description: 'Ending transition', camera: false, duration: 1 },
  { id: 'vignette', name: 'Vignette', description: 'Dark cinematic edges', camera: false, duration: 5 },
  { id: 'grain', name: 'Film grain', description: 'Animated analog noise', camera: false, duration: 5 },
  { id: 'letterbox', name: 'Letterbox', description: 'Cinema bars', camera: false, duration: 5 },
  { id: 'light-leak', name: 'Light leak', description: 'Warm drifting glow', camera: false, duration: 4 },
  { id: 'scanlines', name: 'VHS lines', description: 'Retro scanlines', camera: false, duration: 4 },
  { id: 'tint', name: 'Color tint', description: 'Wash the frame in a color', camera: false, duration: 5 },
]

export const KIND_COLORS: Record<Layer['kind'], string> = {
  media: '#2563eb',
  audio: '#16a34a',
  text: '#c026d3',
  shape: '#ea580c',
  sticker: '#db2777',
  comment: '#0891b2',
  effect: '#7c3aed',
  form: '#0d9488',
}
