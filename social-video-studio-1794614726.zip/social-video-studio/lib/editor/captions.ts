import { createText, unit } from './factory'
import type { Project, TextLayer } from './types'

export interface TimedWord {
  text: string
  start: number
  end: number
}

export interface Transcript {
  text: string
  words: TimedWord[]
  segments: TimedWord[]
  duration: number | null
}

export type CaptionStyleId = 'karaoke' | 'bold-pop' | 'boxed' | 'minimal' | 'one-word'

export const CAPTION_STYLES: { id: CaptionStyleId; name: string; wordsPerChunk: number; note: string }[] = [
  { id: 'karaoke', name: 'Karaoke highlight', wordsPerChunk: 3, note: 'TikTok "Auto captions" + highlight / IG Edits "Captions" karaoke style' },
  { id: 'bold-pop', name: 'Bold pop', wordsPerChunk: 2, note: 'Outlined uppercase words, pop in' },
  { id: 'boxed', name: 'Boxed', wordsPerChunk: 4, note: 'White box behind text — closest to the default native caption look' },
  { id: 'minimal', name: 'Minimal', wordsPerChunk: 6, note: 'Clean sentence captions' },
  { id: 'one-word', name: 'One word', wordsPerChunk: 1, note: 'Single word at a time, fast-paced edits' },
]

/** Whisper sometimes returns segments only — spread their duration evenly across their words. */
export function wordsFromTranscript(t: Transcript): TimedWord[] {
  if (t.words.length) return t.words
  const source = t.segments.length ? t.segments : [{ text: t.text, start: 0, end: t.duration ?? Math.max(2, t.text.split(/\s+/).length * 0.4) }]
  return source.flatMap((seg) => {
    const parts = seg.text.split(/\s+/).filter(Boolean)
    const step = (seg.end - seg.start) / Math.max(1, parts.length)
    return parts.map((text, i) => ({ text, start: seg.start + i * step, end: seg.start + (i + 1) * step }))
  })
}

function chunk(words: TimedWord[], size: number): TimedWord[] {
  const out: TimedWord[] = []
  for (let i = 0; i < words.length; i += size) {
    const group = words.slice(i, i + size)
    out.push({ text: group.map((w) => w.text).join(' '), start: group[0].start, end: group[group.length - 1].end })
  }
  return out
}

export function buildCaptionLayers(project: Project, words: TimedWord[], styleId: CaptionStyleId, offset: number): TextLayer[] {
  const style = CAPTION_STYLES.find((s) => s.id === styleId) ?? CAPTION_STYLES[0]
  const u = unit(project)
  const y = project.height * (project.width > project.height ? 0.82 : 0.66)
  return chunk(words, style.wordsPerChunk).map((c, i, arr) => {
    const next = arr[i + 1]
    const start = offset + c.start
    const end = offset + Math.max(c.end, next ? Math.min(next.start, c.end + 0.4) : c.end + 0.3)
    const base = { name: `Caption ${i + 1}`, text: c.text, start, duration: Math.max(0.2, end - start), y, origin: 'auto-caption' as const }
    switch (style.id) {
      case 'karaoke':
        return createText(project, start, { ...base, uppercase: true, fontSize: Math.round(68 * u), strokeColor: '#000000', strokeWidth: Math.round(8 * u), loop: { type: 'karaoke', speed: 1 } })
      case 'bold-pop':
        return createText(project, start, { ...base, uppercase: true, fontSize: Math.round(92 * u), strokeColor: '#000000', strokeWidth: Math.round(10 * u), animIn: { type: 'pop', duration: 0.18 } })
      case 'boxed':
        return createText(project, start, { ...base, fontSize: Math.round(54 * u), fontWeight: 700, color: '#111111', bgMode: 'line', bgColor: '#ffffff', shadow: false })
      case 'one-word':
        return createText(project, start, { ...base, uppercase: true, fontSize: Math.round(120 * u), strokeColor: '#000000', strokeWidth: Math.round(10 * u), y: project.height * 0.5, animIn: { type: 'zoom-in', duration: 0.12 } })
      default:
        return createText(project, start, { ...base, fontSize: Math.round(48 * u), fontWeight: 600 })
    }
  })
}
