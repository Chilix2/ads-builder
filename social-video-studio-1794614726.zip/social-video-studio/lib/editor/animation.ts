import { clamp, type Layer } from './types'

export interface AnimState {
  dx: number
  dy: number
  scale: number
  scaleX: number
  rotate: number
  opacity: number
  blur: number
  reveal: number
  revealMode: 'none' | 'chars' | 'words'
  karaoke: number
}

export function identityAnim(): AnimState {
  return { dx: 0, dy: 0, scale: 1, scaleX: 1, rotate: 0, opacity: 1, blur: 0, reveal: 1, revealMode: 'none', karaoke: -1 }
}

const easeOut = (p: number) => 1 - Math.pow(1 - p, 3)
const backOut = (p: number) => {
  const c1 = 1.70158
  const c3 = c1 + 1
  return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2)
}
const bounceOut = (x: number) => {
  const n1 = 7.5625
  const d1 = 2.75
  if (x < 1 / d1) return n1 * x * x
  if (x < 2 / d1) return n1 * (x -= 1.5 / d1) * x + 0.75
  if (x < 2.5 / d1) return n1 * (x -= 2.25 / d1) * x + 0.9375
  return n1 * (x -= 2.625 / d1) * x + 0.984375
}
const hash = (n: number) => {
  const s = Math.sin(n * 12.9898) * 43758.5453
  return s - Math.floor(s)
}

const DIST = 240

function applyIn(type: string, p: number, s: AnimState) {
  const e = easeOut(p)
  const fadeQuick = Math.min(1, p * 2.5)
  switch (type) {
    case 'fade':
      s.opacity *= p
      break
    case 'slide-up':
      s.dy += (1 - e) * DIST
      s.opacity *= fadeQuick
      break
    case 'slide-down':
      s.dy -= (1 - e) * DIST
      s.opacity *= fadeQuick
      break
    case 'slide-left':
      s.dx += (1 - e) * DIST * 1.4
      s.opacity *= fadeQuick
      break
    case 'slide-right':
      s.dx -= (1 - e) * DIST * 1.4
      s.opacity *= fadeQuick
      break
    case 'pop':
      s.scale *= Math.max(0, backOut(p))
      s.opacity *= Math.min(1, p * 3)
      break
    case 'zoom-in':
      s.scale *= 0.5 + 0.5 * e
      s.opacity *= e
      break
    case 'zoom-out':
      s.scale *= 1.8 - 0.8 * e
      s.opacity *= e
      break
    case 'drop':
      s.dy -= (1 - bounceOut(p)) * DIST * 2
      s.opacity *= fadeQuick
      break
    case 'spin':
      s.rotate -= (1 - e) * 180
      s.scale *= e
      break
    case 'flip':
      s.scaleX *= Math.max(0.001, e)
      break
    case 'blur-in':
      s.blur += (1 - e) * 24
      s.opacity *= e
      break
    case 'typewriter':
      s.reveal = p
      s.revealMode = 'chars'
      break
    case 'word-pop':
      s.reveal = p
      s.revealMode = 'words'
      break
  }
}

const OUT_MAP: Record<string, string> = {
  'slide-up': 'slide-down',
  'slide-down': 'slide-up',
  'slide-left': 'slide-right',
  'slide-right': 'slide-left',
  shrink: 'pop',
  'zoom-in': 'zoom-out',
  'zoom-out': 'zoom-in',
  'blur-out': 'blur-in',
}

function applyOut(type: string, p: number, s: AnimState) {
  const mapped = OUT_MAP[type] ?? type
  if (mapped === 'pop') {
    s.scale *= 1 - easeOut(p)
    s.opacity *= 1 - p
    return
  }
  applyIn(mapped, 1 - p, s)
}

function applyLoop(type: string, local: number, speed: number, duration: number, s: AnimState) {
  const w = local * speed
  const TAU = Math.PI * 2
  switch (type) {
    case 'pulse':
      s.scale *= 1 + 0.06 * Math.sin(w * TAU)
      break
    case 'heartbeat': {
      const c = w % 1
      const b = c < 0.15 ? Math.sin((c / 0.15) * Math.PI) : c > 0.25 && c < 0.4 ? Math.sin(((c - 0.25) / 0.15) * Math.PI) * 0.7 : 0
      s.scale *= 1 + 0.12 * b
      break
    }
    case 'float':
      s.dy += 16 * Math.sin(w * TAU * 0.6)
      break
    case 'wiggle':
      s.rotate += 5 * Math.sin(w * TAU * 2)
      break
    case 'swing':
      s.rotate += 8 * Math.sin(w * TAU * 0.8)
      break
    case 'shake':
      s.dx += Math.sin(w * 71) * 8
      s.dy += Math.cos(w * 53) * 8
      break
    case 'spin':
      s.rotate += w * 120
      break
    case 'flicker':
      s.opacity *= Math.sin(w * 37) + Math.sin(w * 23) > -0.7 ? 1 : 0.3
      break
    case 'glitch': {
      const f = Math.floor(w * 14)
      if (hash(f) > 0.72) {
        s.dx += (hash(f + 1) - 0.5) * 48
        s.scaleX *= 1 + (hash(f + 2) - 0.5) * 0.12
      }
      break
    }
    case 'karaoke':
      s.karaoke = clamp(local / Math.max(0.01, duration))
      break
  }
}

export function computeAnim(layer: Layer, t: number): AnimState {
  const s = identityAnim()
  const local = t - layer.start
  if (layer.animIn) {
    const d = Math.min(layer.animIn.duration, layer.duration)
    if (d > 0 && local < d) applyIn(layer.animIn.type, clamp(local / d), s)
  }
  if (layer.animOut) {
    const d = Math.min(layer.animOut.duration, layer.duration)
    const outStart = layer.duration - d
    if (d > 0 && local > outStart) applyOut(layer.animOut.type, clamp((local - outStart) / d), s)
  }
  if (layer.loop) applyLoop(layer.loop.type, local, layer.loop.speed, layer.duration, s)
  return s
}

/** Samples an animation into Web Animations keyframes for gallery previews. */
export function previewKeyframes(kind: 'in' | 'out' | 'loop', type: string): Keyframe[] {
  const frames: Keyframe[] = []
  const steps = 24
  for (let i = 0; i <= steps; i++) {
    const p = i / steps
    const s = identityAnim()
    if (kind === 'in') applyIn(type, p, s)
    else if (kind === 'out') applyOut(type, p, s)
    else applyLoop(type, p * 2, 1, 2, s)
    const k = 0.12
    const clip =
      s.revealMode !== 'none' || (kind === 'loop' && type === 'karaoke')
        ? `inset(0 ${(1 - (kind === 'loop' ? s.karaoke : s.reveal)) * 100}% 0 0)`
        : 'inset(0 0 0 0)'
    frames.push({
      offset: p,
      transform: `translate(${s.dx * k}px, ${s.dy * k}px) rotate(${s.rotate}deg) scale(${s.scale * s.scaleX}, ${s.scale})`,
      opacity: s.opacity,
      filter: `blur(${s.blur * 0.15}px)`,
      clipPath: clip,
    })
  }
  return frames
}
