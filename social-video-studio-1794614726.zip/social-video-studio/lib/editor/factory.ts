import { DEFAULT_ADJUST, EFFECTS } from './presets'
import {
  FORMATS,
  uid,
  type Asset,
  type AudioLayer,
  type CommentLayer,
  type CommentVariant,
  type EffectLayer,
  type EffectType,
  type FormatId,
  type FormLayer,
  type FormType,
  type Layer,
  type MediaLayer,
  type Project,
  type ShapeLayer,
  type ShapeType,
  type StickerLayer,
  type StickerType,
  type TextLayer,
} from './types'

export const SAMPLE_ASSETS: Asset[] = [
  { id: 'sample_street', name: 'Street (vertical)', type: 'image', src: '/samples/street.png', width: 640, height: 1136, duration: 5 },
  { id: 'sample_creator', name: 'Creator (vertical)', type: 'image', src: '/samples/creator.png', width: 768, height: 1376, duration: 5 },
  { id: 'sample_product', name: 'Product (vertical)', type: 'image', src: '/samples/product.png', width: 768, height: 1376, duration: 5 },
  { id: 'sample_scholars', name: 'Scholars (wide)', type: 'image', src: '/samples/scholars.png', width: 1199, height: 673, duration: 5 },
]

type Dims = Pick<Project, 'width' | 'height'>

function base(name: string, p: Dims, start: number, width: number, height: number, duration = 5) {
  return {
    id: uid(),
    name,
    start,
    duration,
    x: p.width / 2,
    y: p.height / 2,
    width,
    height,
    rotation: 0,
    opacity: 1,
    animIn: null,
    animOut: null,
    loop: null,
    filter: 'none',
    adjust: { ...DEFAULT_ADJUST },
    warp: 'none' as const,
    warpAmount: 0.28,
    hidden: false,
    locked: false,
  }
}

/** Scale relative to a 1080px-wide reference so presets look the same on every format. */
export const unit = (p: Dims) => Math.min(p.width, p.height) / 1080

export function createText(p: Dims, start: number, patch: Partial<TextLayer> = {}): TextLayer {
  const u = unit(p)
  return {
    ...base('Text', p, start, Math.round(p.width * 0.8), 0, 4),
    kind: 'text',
    text: 'Your text here',
    font: 'geist',
    fontSize: Math.round(72 * u),
    fontWeight: 800,
    italic: false,
    color: '#ffffff',
    align: 'center',
    strokeColor: '#000000',
    strokeWidth: 0,
    bgMode: 'none',
    bgColor: '#000000',
    bgPadding: Math.round(18 * u),
    bgRadius: Math.round(14 * u),
    shadow: true,
    shadowColor: 'rgba(0,0,0,0.55)',
    uppercase: false,
    lineHeight: 1.15,
    letterSpacing: 0,
    highlightColor: '#ffd400',
    ...patch,
  }
}

export function createShape(p: Dims, start: number, shape: ShapeType, patch: Partial<ShapeLayer> = {}): ShapeLayer {
  const u = unit(p)
  const size = Math.round(320 * u)
  const progress = shape === 'progress'
  return {
    ...base(shape[0].toUpperCase() + shape.slice(1), p, start, progress ? Math.round(p.width * 0.86) : size, progress ? Math.round(14 * u) : shape === 'arrow' ? size * 0.6 : size),
    kind: 'shape',
    shape,
    fill: progress ? '#ffffff' : '#ff3b5c',
    stroke: progress ? 'rgba(255,255,255,0.25)' : '#ffffff',
    strokeWidth: 0,
    radius: progress ? 999 : Math.round(24 * u),
    ...(progress ? { y: p.height - Math.round(60 * u) } : {}),
    ...patch,
  }
}

const STICKER_DEFAULTS: Record<StickerType, { w: number; h: number; label: string; sublabel: string; color: string; textColor: string }> = {
  subscribe: { w: 420, h: 110, label: 'SUBSCRIBE', sublabel: '', color: '#ff0033', textColor: '#ffffff' },
  follow: { w: 300, h: 96, label: '+ Follow', sublabel: '', color: '#fe2c55', textColor: '#ffffff' },
  like: { w: 300, h: 100, label: '12.4K', sublabel: '', color: '#fe2c55', textColor: '#111111' },
  live: { w: 220, h: 84, label: 'LIVE', sublabel: '', color: '#ff1f4b', textColor: '#ffffff' },
  new: { w: 200, h: 84, label: 'NEW', sublabel: '', color: '#ffd400', textColor: '#111111' },
  label: { w: 380, h: 96, label: 'Link in bio', sublabel: '', color: '#ffffff', textColor: '#111111' },
  'lower-third': { w: 700, h: 170, label: 'Alex Rivera', sublabel: 'Founder · Studio North', color: '#22d3ee', textColor: '#ffffff' },
  question: { w: 620, h: 360, label: 'Ask me anything', sublabel: 'Type something...', color: '#7c3aed', textColor: '#ffffff' },
  countdown: { w: 520, h: 260, label: 'DROP STARTS IN', sublabel: '', color: '#ffffff', textColor: '#ffffff' },
  poll: { w: 620, h: 340, label: 'Which one would you pick?', sublabel: 'Option A|Option B', color: '#111111', textColor: '#ffffff' },
  quiz: { w: 620, h: 440, label: 'Guess the price', sublabel: '$9|$19|$49', color: '#2563eb', textColor: '#ffffff' },
  slider: { w: 560, h: 230, label: 'How hyped are you?', sublabel: '0.72', color: '#fe2c55', textColor: '#111111' },
  'add-yours': { w: 600, h: 270, label: 'Add Yours', sublabel: 'Show your morning setup', color: '#111111', textColor: '#ffffff' },
  mention: { w: 380, h: 96, label: '@yourhandle', sublabel: '', color: '#ffffff', textColor: '#c026d3' },
  hashtag: { w: 360, h: 96, label: '#trending', sublabel: '', color: '#ffffff', textColor: '#f97316' },
  location: { w: 420, h: 96, label: 'Madrid, Spain', sublabel: '', color: '#ffffff', textColor: '#7c3aed' },
  link: { w: 440, h: 96, label: 'shop.yoursite.com', sublabel: '', color: '#ffffff', textColor: '#2563eb' },
  save: { w: 400, h: 100, label: 'Save for later', sublabel: '', color: '#111111', textColor: '#ffffff' },
  share: { w: 420, h: 100, label: 'Send to a friend', sublabel: '', color: '#111111', textColor: '#ffffff' },
  tap: { w: 300, h: 100, label: 'Tap here', sublabel: '', color: '#ffd400', textColor: '#111111' },
  notification: { w: 680, h: 160, label: 'New message', sublabel: 'you are not going to believe this...', color: '#f4f4f5', textColor: '#111111' },
  music: { w: 560, h: 150, label: 'Song title', sublabel: 'Artist name', color: '#ffffff', textColor: '#111111' },
  gif: { w: 300, h: 300, label: 'OMG', sublabel: '', color: '#ff2d55', textColor: '#ffffff' },
  reveal: { w: 520, h: 340, label: 'Tap to reveal', sublabel: 'DM me to unlock', color: '#1f1f23', textColor: '#ffffff' },
  'frame-polaroid': { w: 640, h: 760, label: 'summer 26', sublabel: '', color: '#fafaf9', textColor: '#27272a' },
  'frame-film': { w: 1080, h: 720, label: '', sublabel: '', color: '#111111', textColor: '#f5d76e' },
  'frame-phone': { w: 560, h: 1120, label: '', sublabel: '', color: '#18181b', textColor: '#ffffff' },
  'frame-border': { w: 1080, h: 1920, label: '', sublabel: '', color: '#ffffff', textColor: '#ffffff' },
  'frame-tape': { w: 260, h: 80, label: '', sublabel: '', color: '#f5e6a8', textColor: '#111111' },
}

export function createSticker(p: Dims, start: number, sticker: StickerType, patch: Partial<StickerLayer> = {}): StickerLayer {
  const u = unit(p)
  const d = STICKER_DEFAULTS[sticker]
  return {
    ...base(d.label || sticker, p, start, Math.round(d.w * u), Math.round(d.h * u), sticker === 'countdown' ? 10 : 4),
    kind: 'sticker',
    sticker,
    label: d.label,
    sublabel: d.sublabel,
    color: d.color,
    textColor: d.textColor,
    ...patch,
  }
}

export function createComment(p: Dims, start: number, variant: CommentVariant, patch: Partial<CommentLayer> = {}): CommentLayer {
  const ratio = p.width > p.height ? 0.42 : 0.78
  return {
    ...base('Comment', p, start, Math.round(p.width * ratio), 0, 4),
    kind: 'comment',
    variant,
    author: 'Niki Cole',
    handle: '@nikii_colee',
    text:
      variant === 'tiktok-reply' || variant === 'ig-reply'
        ? 'what happens if you put diesel in a gas car??'
        : variant === 'chat-bubble'
          ? 'ok but did you actually try it??'
          : 'what happens to your car if you put diesel in it instead of gas ????\n\nasking for myself bc i\u2019m an idiot',
    avatarAssetId: null,
    verified: false,
    y: Math.round(p.height * 0.58),
    ...patch,
  }
}

export function createEffect(p: Dims, start: number, effect: EffectType, patch: Partial<EffectLayer> = {}): EffectLayer {
  const meta = EFFECTS.find((e) => e.id === effect)
  return {
    ...base(meta?.name ?? effect, p, start, p.width, p.height, meta?.duration ?? 3),
    kind: 'effect',
    effect,
    intensity: 1,
    color: effect === 'tint' ? '#ff7a00' : '#ffffff',
    ...patch,
  }
}

export function createMedia(p: Dims, start: number, asset: Asset, patch: Partial<MediaLayer> = {}): MediaLayer {
  const aw = asset.width || p.width
  const ah = asset.height || p.height
  const cover = Math.max(p.width / aw, p.height / ah)
  return {
    ...base(asset.name, p, start, Math.round(aw * cover), Math.round(ah * cover), asset.type === 'video' ? Math.max(0.5, asset.duration) : 5),
    kind: 'media',
    assetId: asset.id,
    trimStart: 0,
    volume: 1,
    muted: false,
    radius: 0,
    flipX: false,
    ...patch,
  }
}

export function createAudio(p: Dims, start: number, asset: Asset): AudioLayer {
  return {
    ...base(asset.name, p, start, 0, 0, Math.max(0.5, asset.duration)),
    kind: 'audio',
    assetId: asset.id,
    trimStart: 0,
    volume: 1,
    fadeIn: 0,
    fadeOut: 0.5,
  }
}

type FormDefaults = Pick<FormLayer, 'title' | 'body' | 'items' | 'primary' | 'secondary' | 'accent' | 'surface' | 'textColor' | 'highlight'> & { w: number }

export const FORM_DEFAULTS: Record<FormType, FormDefaults> = {
  'ios-alert': { w: 900, title: 'Coming in June', body: '', items: [], primary: 'Save', secondary: '', accent: '#1d6ff2', surface: '#f2f2f4', textColor: '#111111', highlight: -1 },
  airdrop: { w: 760, title: 'AirDrop', body: 'Take the next step toward “Premium Packaging”', items: [], primary: 'Accept', secondary: 'Decline', accent: '#2457d6', surface: '#f2f2f4', textColor: '#111111', highlight: -1 },
  notes: { w: 960, title: 'We are *hiring*', body: 'Creators & Influencers', items: [], primary: 'Notes', secondary: '', accent: '#e5aa00', surface: '#ffffff', textColor: '#111111', highlight: -1 },
  'google-search': {
    w: 900,
    title: '¿Por qué *no veo resultados*?',
    body: '',
    items: ['No estás en *déficit calórico*', 'Falta de *constancia*', 'Estás comprando el *suplemento equivocado*', '*Expectativas* poco realistas'],
    primary: '',
    secondary: '',
    accent: '#1a73e8',
    surface: '#ffffff',
    textColor: '#3c4043',
    highlight: -1,
  },
  'context-menu': { w: 600, title: '', body: '', items: ['View >', 'Sort by >', 'Refresh', '---', 'Happy Skin', 'Display settings', 'Personalise'], primary: '', secondary: '', accent: '#f2c4d0', surface: '#e9e9e4', textColor: '#111111', highlight: 4 },
  'id-badge': { w: 640, title: 'THIS IS WHO SAID "ALMOST DONE" TWO HOURS AGO', body: '', items: [], primary: 'Anna', secondary: 'Creative Director', accent: '#c0c4c8', surface: '#f4f4f2', textColor: '#111111', highlight: -1 },
  imessage: { w: 820, title: 'hmmm let me think', body: 'what do you want to do today?', items: [], primary: 'Saturday', secondary: '', accent: '#1a84ff', surface: '#f4f4f6', textColor: '#111111', highlight: -1 },
  'safari-tabs': { w: 760, title: 'sunnei.it - Google Search', body: '', items: ['', '', '', ''], primary: 'Done', secondary: 'Private', accent: '#ffffff', surface: '#ffffff', textColor: '#111111', highlight: -1 },
}

export const FORM_NAMES: Record<FormType, string> = {
  'ios-alert': 'iOS alert',
  airdrop: 'AirDrop card',
  notes: 'Notes header',
  'google-search': 'Google search',
  'context-menu': 'Context menu',
  'id-badge': 'ID badge',
  imessage: 'iMessage',
  'safari-tabs': 'Safari tabs',
}

export function createForm(p: Dims, start: number, form: FormType, patch: Partial<FormLayer> = {}): FormLayer {
  const { w, ...d } = FORM_DEFAULTS[form]
  const width = Math.round(Math.min(w * unit(p), p.width * 0.92))
  return {
    ...base(FORM_NAMES[form], p, start, width, width, 4),
    kind: 'form',
    form,
    ...d,
    items: [...d.items],
    imageAssetId: null,
    ...patch,
  }
}

export function emptyProject(format: FormatId = '9:16'): Project {
  const f = FORMATS[format]
  return {
    version: 1,
    name: 'Untitled post',
    format,
    width: f.width,
    height: f.height,
    background: '#000000',
    layers: [],
    assets: [...SAMPLE_ASSETS],
  }
}

export function createDemoProject(): Project {
  const p = emptyProject('9:16')
  const street = SAMPLE_ASSETS[0]
  p.name = 'Diesel question reply'
  p.layers = [
    { ...createMedia(p, 0, street, { duration: 6 }), name: 'Street background' },
    createEffect(p, 0, 'ken-burns', { duration: 6, intensity: 0.8 }),
    createComment(p, 0.3, 'card-light', {
      duration: 5.4,
      y: 1180,
      animIn: { type: 'pop', duration: 0.5 },
      animOut: { type: 'fade', duration: 0.3 },
      warp: 'tilt-left',
      warpAmount: 0.14,
    }),
    createText(p, 1.2, {
      text: 'What happens to your car if',
      y: 1560,
      fontSize: 64,
      duration: 4.5,
      animIn: { type: 'word-pop', duration: 0.9 },
      name: 'Subtitle',
    }),
    createShape(p, 0, 'progress', { duration: 6, name: 'Progress bar' }),
  ]
  return p
}

/** Re-maps every layer into a new canvas format while keeping relative position and scale. */
export function changeFormat(project: Project, format: FormatId): Project {
  const f = FORMATS[format]
  const sx = f.width / project.width
  const sy = f.height / project.height
  const s = Math.min(sx, sy)
  const layers = project.layers.map((l): Layer => {
    if (l.kind === 'effect') return { ...l, x: f.width / 2, y: f.height / 2, width: f.width, height: f.height }
    if (l.kind === 'media') {
      const asset = project.assets.find((a) => a.id === l.assetId)
      const wasCover = Math.abs(l.width - project.width) < 4 || Math.abs(l.height - project.height) < 4
      if (asset && wasCover) {
        const c = Math.max(f.width / (asset.width || f.width), f.height / (asset.height || f.height))
        return { ...l, x: l.x * sx, y: l.y * sy, width: Math.round((asset.width || f.width) * c), height: Math.round((asset.height || f.height) * c) }
      }
    }
    const next = { ...l, x: l.x * sx, y: l.y * sy, width: l.width * s, height: l.height * s } as Layer
    if (next.kind === 'text') {
      next.fontSize = l.kind === 'text' ? l.fontSize * s : next.fontSize
      next.bgPadding *= s
      next.bgRadius *= s
    }
    if (next.kind === 'shape' && next.shape === 'progress') {
      next.width = f.width * 0.86
      next.x = f.width / 2
    }
    return next
  })
  return { ...project, format, width: f.width, height: f.height, layers }
}
