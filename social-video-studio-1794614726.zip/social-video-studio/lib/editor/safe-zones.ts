import type { FormatId } from './types'

/** A blocked UI region, expressed in fractions of the canvas width/height. */
export interface SafeZoneRect {
  label: string
  x: number
  y: number
  w: number
  h: number
}

export interface SafeZoneSpec {
  id: string
  name: string
  /** Source/basis for the measurements, shown as a tooltip. */
  note: string
  zones: SafeZoneRect[]
}

/**
 * Builds the standard vertical layout: header strip, caption/nav block at the bottom,
 * an engagement rail on the right, and a thin left margin. Values are in px on a 1080x1920 frame.
 */
function vertical(top: number, bottom: number, right: number, left: number, railTop = top): SafeZoneRect[] {
  const W = 1080
  const H = 1920
  return [
    { label: 'Header', x: 0, y: 0, w: 1, h: top / H },
    { label: 'Caption & nav', x: 0, y: 1 - bottom / H, w: 1, h: bottom / H },
    { label: 'Buttons', x: 1 - right / W, y: railTop / H, w: right / W, h: (H - railTop - bottom) / H },
    { label: '', x: 0, y: top / H, w: left / W, h: (H - top - bottom) / H },
  ]
}

export const SAFE_ZONES: Record<FormatId, SafeZoneSpec[]> = {
  '9:16': [
    {
      id: 'tiktok',
      name: 'TikTok',
      note: 'TikTok: top 130px, bottom 484px, right 140px, left 60px (1080x1920)',
      zones: vertical(130, 484, 140, 60),
    },
    {
      id: 'ig-reels',
      name: 'Instagram Reels',
      note: 'Meta Reels: keep top 14% (270px), bottom 35% (670px) and 6% sides clear',
      zones: vertical(270, 670, 120, 65),
    },
    {
      id: 'yt-shorts',
      name: 'YouTube Shorts',
      note: 'Shorts: top 200px, bottom 420px, right 190px, left 48px (1080x1920)',
      zones: vertical(200, 420, 190, 48),
    },
    {
      id: 'x-video',
      name: 'X vertical video',
      note: 'X immersive video: top 150px, bottom 340px, right 130px, left 48px (1080x1920)',
      zones: vertical(150, 340, 130, 48, 900),
    },
  ],
  '4:5': [
    {
      id: 'ig-feed',
      name: 'Instagram feed',
      note: 'Feed post: center 1:1 shows in grid and profile crops; keep text 5% from edges',
      zones: [
        { label: 'Grid crop', x: 0, y: 0, w: 1, h: 0.1 },
        { label: 'Grid crop', x: 0, y: 0.9, w: 1, h: 0.1 },
        { label: '', x: 0, y: 0.1, w: 0.05, h: 0.8 },
        { label: '', x: 0.95, y: 0.1, w: 0.05, h: 0.8 },
      ],
    },
  ],
  '1:1': [
    {
      id: 'square',
      name: 'Feed square (X / IG)',
      note: 'Square post: keep text 5% from edges; X overlays tag/duration bottom-left on video',
      zones: [
        { label: '', x: 0, y: 0, w: 1, h: 0.05 },
        { label: 'Video badges', x: 0, y: 0.9, w: 1, h: 0.1 },
        { label: '', x: 0, y: 0.05, w: 0.05, h: 0.85 },
        { label: '', x: 0.95, y: 0.05, w: 0.05, h: 0.85 },
      ],
    },
  ],
  '16:9': [
    {
      id: 'youtube',
      name: 'YouTube video',
      note: 'YouTube player: title bar on top, progress & controls bottom, timestamp badge bottom-right on thumbnails',
      zones: [
        { label: 'Title bar', x: 0, y: 0, w: 1, h: 0.1 },
        { label: 'Controls', x: 0, y: 0.86, w: 1, h: 0.14 },
        { label: 'Duration', x: 0.84, y: 0.74, w: 0.16, h: 0.12 },
      ],
    },
    {
      id: 'x-landscape',
      name: 'X video post',
      note: 'X timeline video: duration badge bottom-left, mute control bottom-right',
      zones: [
        { label: 'Duration', x: 0, y: 0.86, w: 0.18, h: 0.14 },
        { label: 'Mute', x: 0.88, y: 0.86, w: 0.12, h: 0.14 },
      ],
    },
  ],
}
