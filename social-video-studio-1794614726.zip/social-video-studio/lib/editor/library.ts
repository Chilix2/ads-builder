import {
  SAMPLE_ASSETS,
  createComment,
  createEffect,
  createForm,
  FORM_NAMES,
  createMedia,
  createShape,
  createSticker,
  createText,
  unit,
} from './factory'
import type { CommentVariant, FormType, EffectType, Layer, Project, ShapeType, StickerType, TextLayer, WarpType } from './types'

export interface LibraryItem {
  id: string
  name: string
  /** Builds layers for a project at time t (centered unless pos is given). */
  build: (p: Project, t: number) => Layer[]
}

type Dims = Pick<Project, 'width' | 'height'>

const S = (p: Dims, n: number) => Math.round(n * unit(p))

/* ---------- Text styles ---------- */

const textStyle = (id: string, name: string, patch: (p: Dims) => Partial<TextLayer>): LibraryItem => ({
  id: `text:${id}`,
  name,
  build: (p, t) => [createText(p, t, { name, ...patch(p) })],
})

export const TEXT_STYLES: LibraryItem[] = [
  textStyle('headline', 'Bold headline', (p) => ({ text: 'BIG HEADLINE', fontSize: S(p, 110), uppercase: true, font: 'anton', fontWeight: 400 })),
  textStyle('subtitle', 'Subtitle', (p) => ({ text: 'What happens to your car if', fontSize: S(p, 62), y: p.height * 0.8 })),
  textStyle('tiktok-box', 'TikTok box', (p) => ({
    text: 'pov: you finally tried it',
    fontSize: S(p, 58),
    fontWeight: 700,
    color: '#111111',
    bgMode: 'line',
    bgColor: '#ffffff',
    shadow: false,
    font: 'helvetica',
  })),
  textStyle('hook-red', 'Hook red', (p) => ({
    text: 'NOBODY TALKS ABOUT THIS',
    fontSize: S(p, 76),
    uppercase: true,
    bgMode: 'box',
    bgColor: '#ff1f4b',
    shadow: false,
    y: p.height * 0.22,
    animIn: { type: 'pop', duration: 0.45 },
  })),
  textStyle('meme', 'Meme classic', (p) => ({
    text: 'WHEN THE CODE WORKS',
    font: 'anton',
    fontWeight: 400,
    fontSize: S(p, 104),
    uppercase: true,
    strokeColor: '#000000',
    strokeWidth: S(p, 10),
    shadow: false,
    y: p.height * 0.15,
  })),
  textStyle('karaoke', 'Karaoke caption', (p) => ({
    text: 'every word lights up as you speak',
    fontSize: S(p, 70),
    uppercase: true,
    strokeColor: '#000000',
    strokeWidth: S(p, 8),
    highlightColor: '#ffd400',
    y: p.height * 0.72,
    loop: { type: 'karaoke', speed: 1 },
  })),
  textStyle('typewriter', 'Typewriter', (p) => ({
    text: 'Loading the plot...',
    font: 'mono',
    fontWeight: 700,
    fontSize: S(p, 60),
    animIn: { type: 'typewriter', duration: 1.4 },
  })),
  textStyle('serif', 'Editorial serif', (p) => ({
    text: 'A quiet morning in Madrid',
    font: 'playfair',
    fontWeight: 700,
    italic: true,
    fontSize: S(p, 84),
    animIn: { type: 'blur-in', duration: 0.9 },
  })),
  textStyle('marker', 'Handwritten', (p) => ({ text: 'wait for it...', font: 'marker', fontWeight: 400, fontSize: S(p, 92), color: '#ffd400', rotation: -6 })),
  textStyle('neon', 'Neon glow', (p) => ({
    text: 'OPEN LATE',
    fontSize: S(p, 120),
    font: 'anton',
    fontWeight: 400,
    color: '#ffffff',
    shadowColor: '#22d3ee',
    loop: { type: 'flicker', speed: 1 },
  })),
  textStyle('outline', 'Outline only', (p) => ({
    text: 'OUTLINE',
    font: 'anton',
    fontWeight: 400,
    fontSize: S(p, 150),
    color: 'rgba(0,0,0,0)',
    strokeColor: '#ffffff',
    strokeWidth: S(p, 4),
    shadow: false,
  })),
  textStyle('label', 'Small label', (p) => ({
    text: 'PART 2',
    fontSize: S(p, 40),
    fontWeight: 700,
    letterSpacing: S(p, 6),
    color: '#111111',
    bgMode: 'box',
    bgColor: '#ffd400',
    shadow: false,
    width: S(p, 360),
    y: p.height * 0.1,
  })),
  textStyle('quote', 'Quote', (p) => ({
    text: '\u201CThe best camera is the one you have with you.\u201D',
    font: 'playfair',
    fontWeight: 400,
    fontSize: S(p, 64),
    lineHeight: 1.3,
  })),
]

/* ---------- Hooks: text with built-in motion ---------- */

const hook = (id: string, text: string, patch: (p: Dims) => Partial<TextLayer>): LibraryItem => ({
  id: `hook:${id}`,
  name: text,
  build: (p, t) => [createText(p, t, { name: `Hook: ${text}`, text, y: p.height * 0.22, duration: 3, ...patch(p) })],
})

export const HOOKS: LibraryItem[] = [
  hook('wait', 'Wait for it...', (p) => ({ font: 'marker', fontWeight: 400, fontSize: S(p, 96), loop: { type: 'pulse', speed: 1.4 }, animIn: { type: 'pop', duration: 0.4 } })),
  hook('pov', 'POV: you just found this', (p) => ({ fontSize: S(p, 66), color: '#111111', bgMode: 'line', bgColor: '#ffffff', shadow: false, animIn: { type: 'slide-up', duration: 0.5 } })),
  hook('stop', 'STOP SCROLLING', (p) => ({ font: 'anton', fontWeight: 400, uppercase: true, fontSize: S(p, 130), color: '#ff1f4b', strokeColor: '#ffffff', strokeWidth: S(p, 6), loop: { type: 'shake', speed: 1 }, animIn: { type: 'zoom-out', duration: 0.35 } })),
  hook('3things', '3 things nobody tells you', (p) => ({ fontSize: S(p, 76), uppercase: true, bgMode: 'box', bgColor: '#ffd400', color: '#111111', shadow: false, animIn: { type: 'word-pop', duration: 0.8 } })),
  hook('tried', 'I tried this for 30 days', (p) => ({ fontSize: S(p, 72), animIn: { type: 'typewriter', duration: 1.1 } })),
  hook('end', 'Watch till the end', (p) => ({ fontSize: S(p, 70), y: p.height * 0.8, loop: { type: 'float', speed: 1 }, animIn: { type: 'fade', duration: 0.4 } })),
  hook('why', "Here's why it works", (p) => ({ font: 'playfair', fontWeight: 700, italic: true, fontSize: S(p, 84), animIn: { type: 'blur-in', duration: 0.7 } })),
  hook('dont', "Don't make this mistake", (p) => ({ fontSize: S(p, 74), uppercase: true, bgMode: 'box', bgColor: '#ff1f4b', shadow: false, loop: { type: 'wiggle', speed: 1 }, animIn: { type: 'drop', duration: 0.8 } })),
  hook('secret', 'The secret is...', (p) => ({ font: 'anton', fontWeight: 400, fontSize: S(p, 120), loop: { type: 'glitch', speed: 1 }, animIn: { type: 'flip', duration: 0.45 } })),
  hook('part', 'Part 2', (p) => ({ fontSize: S(p, 56), width: S(p, 300), color: '#111111', bgMode: 'box', bgColor: '#ffffff', shadow: false, y: p.height * 0.1, animIn: { type: 'slide-right', duration: 0.4 } })),
]

/* ---------- Elements ---------- */

export const STICKERS: LibraryItem[] = (
  [
    ['subscribe', 'Subscribe', { animIn: { type: 'pop', duration: 0.45 }, loop: { type: 'pulse', speed: 1 } }],
    ['follow', 'Follow', { animIn: { type: 'pop', duration: 0.4 } }],
    ['like', 'Like counter', { loop: { type: 'heartbeat', speed: 1 } }],
    ['live', 'Live badge', { loop: { type: 'flicker', speed: 0.6 } }],
    ['new', 'New badge', { rotation: -8, animIn: { type: 'spin', duration: 0.5 } }],
    ['label', 'Link in bio', { animIn: { type: 'slide-up', duration: 0.4 } }],
    ['lower-third', 'Lower third', { animIn: { type: 'slide-right', duration: 0.5 }, animOut: { type: 'slide-left', duration: 0.4 } }],
    ['question', 'Question box', { animIn: { type: 'pop', duration: 0.5 } }],
    ['countdown', 'Countdown', { animIn: { type: 'zoom-in', duration: 0.4 } }],
    ['poll', 'Poll', { animIn: { type: 'pop', duration: 0.45 } }],
    ['quiz', 'Quiz', { animIn: { type: 'pop', duration: 0.45 } }],
    ['slider', 'Emoji slider', { animIn: { type: 'slide-up', duration: 0.4 } }],
    ['add-yours', 'Add yours', { rotation: -3, animIn: { type: 'pop', duration: 0.45 } }],
    ['mention', 'Mention', { rotation: -4, animIn: { type: 'pop', duration: 0.4 } }],
    ['hashtag', 'Hashtag', { rotation: 3, animIn: { type: 'pop', duration: 0.4 } }],
    ['location', 'Location', { animIn: { type: 'drop', duration: 0.6 } }],
    ['link', 'Link', { animIn: { type: 'slide-up', duration: 0.4 } }],
    ['save', 'Save CTA', { animIn: { type: 'pop', duration: 0.4 }, loop: { type: 'pulse', speed: 1 } }],
    ['share', 'Share CTA', { animIn: { type: 'pop', duration: 0.4 } }],
    ['tap', 'Tap here', { loop: { type: 'pulse', speed: 1.4 } }],
    ['notification', 'Notification', { animIn: { type: 'slide-down', duration: 0.45 }, animOut: { type: 'slide-up', duration: 0.35 } }],
    ['music', 'Music sticker', { animIn: { type: 'pop', duration: 0.45 } }],
    ['gif', 'GIF burst', { animIn: { type: 'pop', duration: 0.35 } }],
    ['reveal', 'Reveal', { animIn: { type: 'zoom-in', duration: 0.4 } }],
  ] as [StickerType, string, Record<string, unknown>][]
).map(([sticker, name, patch]) => ({
  id: `sticker:${sticker}`,
  name,
  build: (p, t) => {
    const l = createSticker(p, t, sticker, patch)
    if (sticker === 'lower-third') l.y = p.height * 0.78
    if (sticker === 'notification') l.y = p.height * 0.14
    return [l]
  },
}))

export const FRAMES: LibraryItem[] = (
  [
    ['frame-polaroid', 'Polaroid', { rotation: -4, animIn: { type: 'drop', duration: 0.6 } }],
    ['frame-film', 'Film strip', {}],
    ['frame-phone', 'Phone mockup', { animIn: { type: 'slide-up', duration: 0.5 } }],
    ['frame-border', 'Rounded border', {}],
    ['frame-tape', 'Washi tape', { rotation: -12 }],
  ] as [StickerType, string, Record<string, unknown>][]
).map(([sticker, name, patch]) => ({
  id: `sticker:${sticker}`,
  name,
  build: (p, t) => {
    const l = createSticker(p, t, sticker, patch)
    if (sticker === 'frame-border') Object.assign(l, { x: 0, y: 0, width: p.width, height: p.height, duration: 8 })
    if (sticker === 'frame-film') Object.assign(l, { x: 0, width: p.width, height: Math.round(p.width * 0.66), y: Math.round((p.height - p.width * 0.66) / 2), duration: 8 })
    return [l]
  },
}))

/** Which native tool (see platform-tools) recreates a library item. */
export function toolIdForItem(id: string): string | null {
  const [kind, sub] = id.split(':')
  if (kind === 'comment') return 'comment-reply'
  if (kind === 'shape') return 'sticker-photo'
  if (kind === 'sticker') {
    const map: Record<string, string> = {
      poll: 'sticker-poll', quiz: 'sticker-quiz', slider: 'sticker-slider', question: 'sticker-question',
      'add-yours': 'sticker-add-yours', countdown: 'sticker-countdown', mention: 'sticker-mention',
      hashtag: 'sticker-hashtag', location: 'sticker-location', link: 'sticker-link', music: 'sticker-music',
      gif: 'sticker-gif', reveal: 'sticker-reveal', 'frame-polaroid': 'sticker-frame',
    }
    return map[sub] ?? 'sticker-photo'
  }
  return null
}

export const SHAPES: LibraryItem[] = (
  [
    ['rect', 'Rectangle'],
    ['circle', 'Circle'],
    ['triangle', 'Triangle'],
    ['star', 'Star'],
    ['heart', 'Heart'],
    ['arrow', 'Arrow'],
    ['progress', 'Progress bar'],
  ] as [ShapeType, string][]
).map(([shape, name]) => ({
  id: `shape:${shape}`,
  name,
  build: (p, t) => [
    createShape(p, t, shape, {
      ...(shape === 'heart' ? { loop: { type: 'heartbeat', speed: 1 } } : {}),
      ...(shape === 'arrow' ? { fill: '#ffd400', loop: { type: 'float', speed: 1.5 } } : {}),
      ...(shape === 'star' ? { fill: '#ffd400', loop: { type: 'spin', speed: 0.5 } } : {}),
      ...(shape === 'progress' ? { duration: 6 } : {}),
    }),
  ],
}))

/* ---------- Comment cards ---------- */

const commentItem = (id: string, name: string, variant: CommentVariant, warp: WarpType, amount = 0.14): LibraryItem => ({
  id: `comment:${id}`,
  name,
  build: (p, t) => [
    createComment(p, t, variant, {
      warp,
      warpAmount: amount,
      animIn: { type: 'pop', duration: 0.45 },
      ...(variant === 'card-dark' ? { author: 'Anaviva777', handle: '@anaviva777', text: 'So, where are the flying cars and robobutlers? I was promised a more exciting future than this. Disappointed.' } : {}),
    }),
  ],
})

export const COMMENTS: LibraryItem[] = [
  commentItem('light', 'Card light', 'card-light', 'none'),
  commentItem('dark', 'Card dark', 'card-dark', 'none'),
  commentItem('reply', 'TikTok reply', 'tiktok-reply', 'none'),
  commentItem('ig-reply', 'Instagram reply', 'ig-reply', 'none'),
  commentItem('yt', 'YouTube comment', 'yt-comment', 'none'),
  commentItem('x', 'X post', 'x-post', 'none'),
  commentItem('bubble', 'Chat bubble', 'chat-bubble', 'none'),
  commentItem('x-tilt', 'X post tilted', 'x-post', 'tilt-left'),
  commentItem('tilt-left', 'Tilted left', 'card-light', 'tilt-left'),
  commentItem('tilt-right', 'Tilted right', 'card-light', 'tilt-right'),
  commentItem('top-big', 'Top bigger', 'card-light', 'top-big'),
  commentItem('bottom-big', 'Bottom bigger', 'card-light', 'bottom-big'),
  commentItem('dark-tilt', 'Dark tilted', 'card-dark', 'tilt-right', 0.18),
]

/* ---------- Effects ---------- */

export const effectItem = (effect: EffectType, name: string): LibraryItem => ({
  id: `effect:${effect}`,
  name,
  build: (p, t) => [createEffect(p, t, effect)],
})

/* ---------- Templates: full scenes ---------- */

const asset = (id: string) => SAMPLE_ASSETS.find((a) => a.id === id)!

export interface Template extends LibraryItem {
  description: string
  cover: string
}

export const TEMPLATES: Template[] = [
  {
    id: 'tpl:comment-reply',
    name: 'Comment reply',
    description: 'Answer a viewer question with the comment card over your footage',
    cover: '/samples/street.png',
    build: (p) => [
      { ...createMedia(p, 0, asset('sample_street'), { duration: 7 }), name: 'Footage' },
      createEffect(p, 0, 'ken-burns', { duration: 7, intensity: 0.7 }),
      createComment(p, 0.2, 'card-light', { duration: 3.6, y: p.height * 0.6, animIn: { type: 'pop', duration: 0.5 }, animOut: { type: 'fade', duration: 0.3 } }),
      createText(p, 0.8, { text: 'What happens to your car if', y: p.height * 0.82, fontSize: S(p, 62), duration: 3, animIn: { type: 'word-pop', duration: 0.8 } }),
      createText(p, 3.9, { text: 'you put diesel in it?', y: p.height * 0.82, fontSize: S(p, 62), duration: 3, animIn: { type: 'word-pop', duration: 0.8 } }),
      createShape(p, 0, 'progress', { duration: 7 }),
    ],
  },
  {
    id: 'tpl:hook-captions',
    name: 'Hook + captions',
    description: 'Scroll-stopping hook, zoom punch and karaoke captions',
    cover: '/samples/creator.png',
    build: (p) => [
      { ...createMedia(p, 0, asset('sample_creator'), { duration: 8, filter: 'vivid' }), name: 'Talking head' },
      createEffect(p, 0, 'zoom-punch', { duration: 0.6 }),
      createEffect(p, 3, 'zoom-punch', { duration: 0.6 }),
      createText(p, 0, { text: 'STOP SCROLLING', font: 'anton', fontWeight: 400, fontSize: S(p, 130), color: '#ffd400', strokeColor: '#000000', strokeWidth: S(p, 8), y: p.height * 0.2, duration: 2.4, animIn: { type: 'zoom-out', duration: 0.35 }, loop: { type: 'shake', speed: 0.6 } }),
      createText(p, 2.4, { text: 'this changed how I edit videos', uppercase: true, fontSize: S(p, 68), strokeColor: '#000000', strokeWidth: S(p, 8), y: p.height * 0.72, duration: 2.8, loop: { type: 'karaoke', speed: 1 } }),
      createText(p, 5.2, { text: 'and it costs nothing', uppercase: true, fontSize: S(p, 68), strokeColor: '#000000', strokeWidth: S(p, 8), y: p.height * 0.72, duration: 2.8, loop: { type: 'karaoke', speed: 1 } }),
      createSticker(p, 6, 'follow', { y: p.height * 0.88, duration: 2, animIn: { type: 'pop', duration: 0.4 } }),
    ],
  },
  {
    id: 'tpl:product-drop',
    name: 'Product drop',
    description: 'Launch countdown with NEW badge and link sticker',
    cover: '/samples/product.png',
    build: (p) => [
      { ...createMedia(p, 0, asset('sample_product'), { duration: 8 }), name: 'Product shot' },
      createEffect(p, 0, 'zoom-pulse', { duration: 8, intensity: 0.6 }),
      createEffect(p, 0, 'flash', { duration: 0.5 }),
      createSticker(p, 0.4, 'new', { x: p.width * 0.26, y: p.height * 0.14, rotation: -8, duration: 7.6, animIn: { type: 'spin', duration: 0.5 } }),
      createText(p, 0.6, { text: 'THE DROP', font: 'anton', fontWeight: 400, fontSize: S(p, 170), y: p.height * 0.28, duration: 7.4, animIn: { type: 'slide-up', duration: 0.5 } }),
      createSticker(p, 1.2, 'countdown', { y: p.height * 0.72, duration: 6.8 }),
      createSticker(p, 2, 'label', { y: p.height * 0.88, label: 'Shop via link in bio', width: S(p, 520), duration: 6, loop: { type: 'pulse', speed: 1 } }),
    ],
  },
  {
    id: 'tpl:cinematic',
    name: 'Cinematic',
    description: 'Letterbox, grain, slow push-in and an editorial title',
    cover: '/samples/scholars.png',
    build: (p) => [
      { ...createMedia(p, 0, asset('sample_scholars'), { duration: 7, filter: 'drama' }), name: 'Scene' },
      createEffect(p, 0, 'ken-burns', { duration: 7 }),
      createEffect(p, 0, 'letterbox', { duration: 7 }),
      createEffect(p, 0, 'grain', { duration: 7, intensity: 0.8 }),
      createEffect(p, 0, 'vignette', { duration: 7 }),
      createText(p, 0.8, { text: 'The Calculation', font: 'playfair', fontWeight: 700, italic: true, fontSize: S(p, 110), duration: 5, animIn: { type: 'blur-in', duration: 1.2 }, animOut: { type: 'fade', duration: 0.8 } }),
      createEffect(p, 6, 'fade-black', { duration: 1 }),
    ],
  },
  {
    id: 'tpl:podcast',
    name: 'Podcast clip',
    description: 'Lower third, live badge, captions and a progress bar',
    cover: '/samples/creator.png',
    build: (p) => [
      { ...createMedia(p, 0, asset('sample_creator'), { duration: 8, filter: 'matte' }), name: 'Guest' },
      createSticker(p, 0, 'live', { x: p.width * 0.14, y: p.height * 0.07, duration: 8, width: S(p, 180), height: S(p, 70) }),
      createSticker(p, 0.5, 'lower-third', { y: p.height * 0.66, duration: 4, animIn: { type: 'slide-right', duration: 0.5 }, animOut: { type: 'slide-left', duration: 0.4 } }),
      createText(p, 0.5, { text: 'the hardest part is starting', fontSize: S(p, 60), color: '#111111', bgMode: 'line', bgColor: '#ffffff', shadow: false, y: p.height * 0.82, duration: 3.5, animIn: { type: 'word-pop', duration: 0.8 } }),
      createText(p, 4, { text: 'everything after is momentum', fontSize: S(p, 60), color: '#111111', bgMode: 'line', bgColor: '#ffffff', shadow: false, y: p.height * 0.82, duration: 4, animIn: { type: 'word-pop', duration: 0.8 } }),
      createShape(p, 0, 'progress', { duration: 8, fill: '#22d3ee' }),
    ],
  },
  {
    id: 'tpl:qa',
    name: 'Q&A sticker',
    description: 'Question box answer with retro VHS finish',
    cover: '/samples/street.png',
    build: (p) => [
      { ...createMedia(p, 0, asset('sample_street'), { duration: 6, filter: 'vintage' }), name: 'Background' },
      createEffect(p, 0, 'scanlines', { duration: 6, intensity: 0.7 }),
      createSticker(p, 0.3, 'question', { y: p.height * 0.38, label: 'Best street in Madrid?', sublabel: 'Gran Via, obviously', duration: 5.7 }),
      createText(p, 1.2, { text: 'answering your questions', font: 'marker', fontWeight: 400, fontSize: S(p, 76), y: p.height * 0.7, duration: 4.8, animIn: { type: 'pop', duration: 0.4 }, loop: { type: 'float', speed: 1 } }),
    ],
  },
]

/* ---------- UI forms (editable alert / search / menu mockups) ---------- */

const formItem = (form: FormType, patch: (p: Dims) => Partial<import('./types').FormLayer> = () => ({})): LibraryItem => ({
  id: `form:${form}`,
  name: FORM_NAMES[form],
  build: (p, t) => [createForm(p, t, form, { imageAssetId: form === 'airdrop' || form === 'id-badge' || form === 'safari-tabs' ? 'sample_street' : null, ...patch(p) })],
})

export const TEXT_FORMS: LibraryItem[] = (['ios-alert', 'notes', 'imessage', 'google-search'] as FormType[]).map((f) => formItem(f))
export const FORMS: LibraryItem[] = (['ios-alert', 'airdrop', 'notes', 'google-search', 'context-menu', 'imessage', 'id-badge', 'safari-tabs'] as FormType[]).map((f) => formItem(f))
