export type FormatId = '9:16' | '4:5' | '1:1' | '16:9'

export const FORMATS: Record<FormatId, { label: string; width: number; height: number; hint: string }> = {
  '9:16': { label: '9:16 Vertical', width: 1080, height: 1920, hint: 'TikTok · Reels · Shorts' },
  '4:5': { label: '4:5 Portrait', width: 1080, height: 1350, hint: 'Instagram feed' },
  '1:1': { label: '1:1 Square', width: 1080, height: 1080, hint: 'Feed post' },
  '16:9': { label: '16:9 Wide', width: 1920, height: 1080, hint: 'YouTube · X' },
}

export type FontKey = 'geist' | 'anton' | 'playfair' | 'marker' | 'mono' | 'helvetica'
export type ShapeType = 'rect' | 'circle' | 'triangle' | 'star' | 'heart' | 'arrow' | 'progress'
export type StickerType =
  | 'subscribe'
  | 'follow'
  | 'like'
  | 'live'
  | 'new'
  | 'label'
  | 'lower-third'
  | 'question'
  | 'countdown'
  | 'poll'
  | 'quiz'
  | 'slider'
  | 'add-yours'
  | 'mention'
  | 'hashtag'
  | 'location'
  | 'link'
  | 'save'
  | 'share'
  | 'tap'
  | 'notification'
  | 'music'
  | 'gif'
  | 'reveal'
  | 'frame-polaroid'
  | 'frame-film'
  | 'frame-phone'
  | 'frame-border'
  | 'frame-tape'
export type CommentVariant = 'card-light' | 'card-dark' | 'tiktok-reply' | 'ig-reply' | 'yt-comment' | 'x-post' | 'chat-bubble'

/** Where a layer came from — used by the rebuild guide to pick the matching native tool. */
export type LayerOrigin = 'auto-caption' | 'tts' | 'voiceover' | 'music'
export type EffectType =
  | 'vignette'
  | 'grain'
  | 'letterbox'
  | 'flash'
  | 'light-leak'
  | 'tint'
  | 'scanlines'
  | 'fade-black'
  | 'shake'
  | 'zoom-punch'
  | 'ken-burns'
  | 'zoom-pulse'
export type WarpType = 'none' | 'tilt-left' | 'tilt-right' | 'top-big' | 'bottom-big'

export interface AnimSpec {
  type: string
  duration: number
}

export interface LoopSpec {
  type: string
  speed: number
}

export interface Adjust {
  brightness: number
  contrast: number
  saturate: number
  blur: number
  hue: number
}

interface BaseLayer {
  id: string
  name: string
  start: number
  duration: number
  /** center x in project px */
  x: number
  /** center y in project px */
  y: number
  width: number
  height: number
  rotation: number
  opacity: number
  animIn: AnimSpec | null
  animOut: AnimSpec | null
  loop: LoopSpec | null
  filter: string
  adjust: Adjust
  warp: WarpType
  warpAmount: number
  hidden: boolean
  locked: boolean
  origin?: LayerOrigin
}

export interface MediaLayer extends BaseLayer {
  kind: 'media'
  assetId: string
  trimStart: number
  volume: number
  muted: boolean
  radius: number
  flipX: boolean
}

export interface AudioLayer extends BaseLayer {
  kind: 'audio'
  assetId: string
  trimStart: number
  volume: number
  fadeIn: number
  fadeOut: number
}

export interface TextLayer extends BaseLayer {
  kind: 'text'
  text: string
  font: FontKey
  fontSize: number
  fontWeight: number
  italic: boolean
  color: string
  align: 'left' | 'center' | 'right'
  strokeColor: string
  strokeWidth: number
  bgMode: 'none' | 'box' | 'line'
  bgColor: string
  bgPadding: number
  bgRadius: number
  shadow: boolean
  shadowColor: string
  uppercase: boolean
  lineHeight: number
  letterSpacing: number
  highlightColor: string
}

export interface ShapeLayer extends BaseLayer {
  kind: 'shape'
  shape: ShapeType
  fill: string
  stroke: string
  strokeWidth: number
  radius: number
}

export interface StickerLayer extends BaseLayer {
  kind: 'sticker'
  sticker: StickerType
  label: string
  sublabel: string
  color: string
  textColor: string
}

export interface CommentLayer extends BaseLayer {
  kind: 'comment'
  variant: CommentVariant
  author: string
  handle: string
  text: string
  avatarAssetId: string | null
  verified: boolean
}

export interface EffectLayer extends BaseLayer {
  kind: 'effect'
  effect: EffectType
  intensity: number
  color: string
}

export type FormType = 'ios-alert' | 'airdrop' | 'notes' | 'google-search' | 'context-menu' | 'id-badge' | 'imessage' | 'safari-tabs'

/** Editable UI "form" (alert, search bar, menu…). Wrap words in *asterisks* to color them with the accent. */
export interface FormLayer extends BaseLayer {
  kind: 'form'
  form: FormType
  title: string
  body: string
  items: string[]
  primary: string
  secondary: string
  accent: string
  surface: string
  textColor: string
  imageAssetId: string | null
  highlight: number
}

export type Layer = MediaLayer | AudioLayer | TextLayer | ShapeLayer | StickerLayer | CommentLayer | EffectLayer | FormLayer
export type LayerKind = Layer['kind']

export interface Asset {
  id: string
  name: string
  type: 'image' | 'video' | 'audio'
  src: string
  width: number
  height: number
  duration: number
}

export type PostType = 'reel' | 'story' | 'carousel'
export type TargetPlatform = 'instagram' | 'tiktok'

export const POST_TYPES: Record<PostType, { label: string; hint: string }> = {
  reel: { label: 'Reel / video', hint: 'One timeline' },
  story: { label: 'Story', hint: 'Slides ≤ 60 s each' },
  carousel: { label: 'Carousel', hint: 'IG ≤ 20 · TikTok photo mode ≤ 35' },
}

export const SLIDE_LIMIT: Record<PostType, Record<TargetPlatform, number>> = {
  reel: { instagram: 1, tiktok: 1 },
  story: { instagram: 100, tiktok: 100 },
  carousel: { instagram: 20, tiktok: 35 },
}

export interface Slide {
  id: string
  name: string
  layers: Layer[]
}

export interface Project {
  version: 1
  name: string
  format: FormatId
  width: number
  height: number
  background: string
  /** Layers of the active slide. */
  layers: Layer[]
  assets: Asset[]
  postType?: PostType
  target?: TargetPlatform
  /** All slides; the entry at activeSlide is stale — `layers` is the live copy. */
  slides?: Slide[]
  activeSlide?: number
  /** Elements the user extracted or saved for reuse. */
  saved?: SavedElement[]
}

export interface SavedElement {
  id: string
  name: string
  layer: Layer
}

/** Slides with the live layers merged in. */
export function getSlides(p: Project): Slide[] {
  if (!p.slides?.length) return [{ id: 'slide_1', name: 'Slide 1', layers: p.layers }]
  const active = p.activeSlide ?? 0
  return p.slides.map((s, i) => (i === active ? { ...s, layers: p.layers } : s))
}

export function uid(prefix = 'l') {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`
}

export function projectDuration(project: Project) {
  let end = 0
  for (const l of project.layers) end = Math.max(end, l.start + l.duration)
  return Math.max(1, end)
}

export function clamp(v: number, min = 0, max = 1) {
  return Math.min(max, Math.max(min, v))
}

export const CAMERA_EFFECTS = new Set<EffectType>(['shake', 'zoom-punch', 'ken-burns', 'zoom-pulse'])
