import { ANIM_IN, ANIM_OUT, EFFECTS, FILTERS, LOOPS } from './presets'
import { TIERS, TOOL_BY_ID, type NativePlatform, type Tier } from './platform-tools'
import { toolIdForItem } from './library'
import { POST_TYPES, getSlides, type Layer, type Project } from './types'

export type { NativePlatform }

export const NATIVE_PLATFORMS: Record<NativePlatform, { name: string; app: string; note: string }> = {
  instagram: {
    name: 'Instagram',
    app: 'Edits app',
    note: 'Build in Edits and finish with “Share to Instagram” so the post is tagged as made in Edits. Edits is free; Edits Plus (paid, limited test) only adds cloud storage and AI credits — no step here needs it.',
  },
  tiktok: {
    name: 'TikTok',
    app: 'TikTok editor + TikTok Studio',
    note: 'TikTok has no paid editor tier. Steps marked CapCut Pro need that paid app (ByteDance) — finish there with “Share to TikTok” so it still posts natively.',
  },
}

/**
 * - native: rebuilt with the platform's own tool
 * - fallback: the platform lacks the tool; the step describes the closest substitute
 * - plate: baked into the base video we upload
 * - overlay: exported as a transparent PNG and added as a photo sticker
 */
export type Strategy = 'native' | 'fallback' | 'plate' | 'overlay'

export interface RebuildStep {
  id: string
  slide: number
  at: number
  end: number
  layerIds: string[]
  title: string
  toolId: string | null
  tool: string
  tier: Tier
  verify: boolean
  strategy: Strategy
  settings: string[]
}

const t = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toFixed(1).padStart(4, '0')}`
const nameOf = (list: { id: string; name: string }[], id?: string | null) => list.find((x) => x.id === id)?.name ?? id

interface Resolved {
  toolId: string | null
  tool: string
  tier: Tier
  verify: boolean
  strategy: Strategy
  note?: string
}

/** Look up the native path for a tool on one platform, or its fallback. */
function resolve(toolId: string, platform: NativePlatform): Resolved {
  const tool = TOOL_BY_ID.get(toolId)
  const path = tool?.[platform]
  if (tool && path) return { toolId, tool: path.path, tier: path.tier, verify: !!path.verify, strategy: 'native' }
  const fb = tool?.fallback?.[platform]
  if (toolId === 'sticker-photo' || !fb) {
    const photo = TOOL_BY_ID.get('sticker-photo')![platform]!
    return { toolId: 'sticker-photo', tool: photo.path, tier: photo.tier, verify: !!photo.verify, strategy: 'overlay', note: tool && !path ? `${tool.name} does not exist on ${NATIVE_PLATFORMS[platform].name} — add the overlay PNG instead` : undefined }
  }
  return { toolId, tool: fb, tier: 'free', verify: false, strategy: 'fallback', note: `${tool!.name} is not on ${NATIVE_PLATFORMS[platform].name} — use this substitute` }
}

function layerToolId(l: Layer): string | null {
  switch (l.kind) {
    case 'media':
    case 'effect':
      return null
    case 'text':
      return l.origin === 'auto-caption' ? 'auto-captions' : 'text'
    case 'audio':
      return l.origin === 'tts' ? 'tts' : l.origin === 'voiceover' ? 'voiceover' : l.origin && l.origin !== 'music' ? null : 'music'
    case 'sticker':
      return toolIdForItem(`sticker:${l.sticker}`)
    case 'comment': {
      return l.variant === 'ig-reply' || l.variant === 'tiktok-reply' ? 'comment-reply' : 'sticker-photo'
    }
    case 'shape':
    case 'form':
      return 'sticker-photo'
  }
}

export function strategyOf(l: Layer, platform: NativePlatform): Strategy {
  const id = layerToolId(l)
  if (!id) return 'plate'
  if (l.kind === 'comment' && id === 'comment-reply') {
    const own = (platform === 'instagram' && l.variant === 'ig-reply') || (platform === 'tiktok' && l.variant === 'tiktok-reply')
    return own ? 'native' : 'overlay'
  }
  return resolve(id, platform).strategy
}

function animSettings(l: Layer, platform: NativePlatform) {
  const out: string[] = []
  if (!l.animIn && !l.animOut && !l.loop) return out
  const anim = resolve('text-animation', platform)
  const prefix = anim.strategy === 'native' ? `${anim.tool} → ` : ''
  if (l.animIn) out.push(`${prefix}In: ${nameOf(ANIM_IN, l.animIn.type)} (${l.animIn.duration.toFixed(1)}s)`)
  if (l.animOut) out.push(`${prefix}Out: ${nameOf(ANIM_OUT, l.animOut.type)} (${l.animOut.duration.toFixed(1)}s)`)
  if (l.loop && l.loop.type !== 'karaoke') out.push(`${prefix}Loop: ${nameOf(LOOPS, l.loop.type)}`)
  if (anim.strategy !== 'native') out.push(`No animation tool here: ${TOOL_BY_ID.get('text-animation')?.fallback?.[platform] ?? 'use timing only'}`)
  return out
}

function placement(p: Project, l: Layer) {
  const vx = l.x / p.width
  const vy = l.y / p.height
  const h = vx < 0.38 ? 'left' : vx > 0.62 ? 'right' : 'center'
  const v = vy < 0.33 ? 'top' : vy > 0.66 ? 'bottom' : 'middle'
  return `Place ${v}-${h} (x ${Math.round(vx * 100)}%, y ${Math.round(vy * 100)}%)${l.rotation ? `, rotate ${Math.round(l.rotation)}°` : ''}`
}

const timing = (l: Layer) => `Show ${t(l.start)} → ${t(l.start + l.duration)} — drag the clip edges on the timeline`

function textStyle(l: Extract<Layer, { kind: 'text' }>, platform: NativePlatform) {
  const font = { geist: 'Classic / Modern sans', anton: 'Bold condensed', bebas: 'Bold condensed', serif: 'Serif', mono: 'Typewriter', hand: 'Handwriting' } as Record<string, string>
  const style = [`Font: ${font[l.font] ?? 'Classic'}${l.uppercase ? ', ALL CAPS' : ''}`, `Color ${l.color}${l.strokeWidth ? `, outline ${l.strokeColor}` : ''}`]
  if (l.bgMode !== 'none') style.push(resolve('text-bg', platform).tool)
  return style
}

function step(slide: number, l: Layer, r: Resolved, title: string, settings: string[]): RebuildStep {
  return {
    id: `${slide}:${l.id}`,
    slide,
    at: l.start,
    end: l.start + l.duration,
    layerIds: [l.id],
    title,
    toolId: r.toolId,
    tool: r.tool,
    tier: r.tier,
    verify: r.verify,
    strategy: r.strategy,
    settings: r.note ? [r.note, ...settings] : settings,
  }
}

function slideSteps(project: Project, layers: Layer[], slide: number, platform: NativePlatform): RebuildStep[] {
  const steps: RebuildStep[] = []
  const ig = platform === 'instagram'
  const captions = layers.filter((l) => l.kind === 'text' && l.origin === 'auto-caption')
  if (captions.length) {
    const first = captions[0] as Extract<Layer, { kind: 'text' }>
    const r = resolve('auto-captions', platform)
    steps.push({
      ...step(slide, first, r, `Auto captions (${captions.length} lines)`, [
        'Regenerate natively — do not burn them in. Native captions are indexed for search.',
        ...textStyle(first, platform),
        first.loop?.type === 'karaoke' ? 'Pick the word-highlight / karaoke caption style' : 'Pick the plain caption style',
        'Review the transcript for typos before posting',
      ]),
      id: `${slide}:captions`,
      at: Math.min(...captions.map((c) => c.start)),
      end: Math.max(...captions.map((c) => c.start + c.duration)),
      layerIds: captions.map((c) => c.id),
    })
  }

  for (const l of layers) {
    if (l.kind === 'text' && l.origin === 'auto-caption') continue
    const id = layerToolId(l)
    if (!id) continue

    if (l.kind === 'text') {
      steps.push(step(slide, l, resolve('text', platform), `Text: “${l.text.slice(0, 48)}${l.text.length > 48 ? '…' : ''}”`, [`Type: ${l.text.replace(/\n/g, ' / ')}`, ...textStyle(l, platform), placement(project, l), timing(l), ...animSettings(l, platform)]))
    } else if (l.kind === 'sticker') {
      const r = resolve(id, platform)
      const isNative = r.strategy === 'native' && r.toolId !== 'sticker-photo'
      steps.push(step(slide, l, r, `Sticker: ${l.label || l.sticker}`, [
        isNative ? `Enter: ${[l.label, l.sublabel].filter(Boolean).join(' — ') || l.name}` : `Use “${l.name}.png” from the overlay pack`,
        placement(project, l),
        timing(l),
        ...animSettings(l, platform),
      ]))
    } else if (l.kind === 'comment') {
      const own = (ig && l.variant === 'ig-reply') || (!ig && l.variant === 'tiktok-reply')
      const r = own ? resolve('comment-reply', platform) : resolve('sticker-photo', platform)
      steps.push(step(slide, l, r, `Comment from ${l.author}`, [
        own ? 'Start the edit from the real comment so the native reply sticker is attached' : `Add “${l.name}.png” from the overlay pack (comment cards are photo overlays)`,
        placement(project, l),
        timing(l),
        ...animSettings(l, platform),
      ]))
    } else if (l.kind === 'audio') {
      const r = resolve(id, platform)
      const title = l.origin === 'tts' ? 'Text-to-speech voice' : l.origin === 'voiceover' ? 'Voiceover' : `Sound: ${l.name}`
      steps.push(step(slide, l, r, title, [
        l.origin === 'tts' ? `Type the script as Text, then ${r.tool}. Pick the closest voice.` : l.origin === 'voiceover' ? `Record at ${t(l.start)}` : `Search “${l.name}” or a trending sound with a similar beat`,
        `Volume ${Math.round(l.volume * 100)}%`,
        timing(l),
      ]))
    } else if (l.kind === 'shape') {
      steps.push(step(slide, l, resolve('sticker-photo', platform), `Shape: ${l.name}`, [`Add “${l.name}.png” from the overlay pack`, placement(project, l), timing(l), ...animSettings(l, platform)]))
    }
  }
  return steps.sort((a, b) => a.at - b.at)
}

function fixed(id: string, toolId: string, platform: NativePlatform, title: string, settings: string[], slide = 0, at = 0, end = 0, layerIds: string[] = [], strategy?: Strategy): RebuildStep {
  const r = resolve(toolId, platform)
  return { id, slide, at, end, layerIds, title, toolId, tool: r.tool, tier: r.tier, verify: r.verify, strategy: strategy ?? r.strategy, settings: r.note ? [r.note, ...settings] : settings }
}

export function buildRebuildPlan(project: Project, platform: NativePlatform): RebuildStep[] {
  const postType = project.postType ?? 'reel'
  const slides = getSlides(project)
  const steps: RebuildStep[] = []
  const all = slides.flatMap((s) => s.layers)
  const plate = all.filter((l) => strategyOf(l, platform) === 'plate')
  const filters = [...new Set(plate.filter((l) => l.filter && l.filter !== 'none').map((l) => nameOf(FILTERS, l.filter)))]
  const effects = [...new Set(all.filter((l) => l.kind === 'effect').map((l) => nameOf(EFFECTS, (l as Extract<Layer, { kind: 'effect' }>).effect)))]

  steps.push(
    fixed('setup', postType, platform, `Start a ${POST_TYPES[postType].label.toLowerCase()}`, [
      `Canvas ${project.width}×${project.height} (${project.format})`,
      slides.length > 1 ? `${slides.length} slides — import ${slides.map((_, i) => `plate-${i + 1}`).join(', ')} in order` : 'Import “base-plate” from the export pack',
      `Plates already contain ${plate.length} baked layers (footage, keyframes, custom effects). Do not re-add them.`,
      ...(filters.length ? [`Baked filters: ${filters.join(', ')} — leave the native Filter on “Normal”`] : []),
      ...(effects.length ? [`Baked effects: ${effects.join(', ')}`] : []),
    ], 0, 0, 0, plate.map((l) => l.id), 'plate'),
  )

  slides.forEach((s, i) => {
    if (slides.length > 1) {
      const dur = Math.max(0, ...s.layers.map((l) => l.start + l.duration))
      steps.push({ id: `slide-${i}`, slide: i, at: 0, end: dur, layerIds: [], title: `Slide ${i + 1}: ${s.name}`, toolId: null, tool: postType === 'story' ? 'Story → next slide' : 'Tap the slide thumbnail', tier: 'free', verify: false, strategy: 'native', settings: [`Length ${t(dur)}`, `${s.layers.length} layers`] })
    }
    steps.push(...slideSteps(project, s.layers, i, platform))
  })

  steps.push(
    fixed('cover', 'cover', platform, 'Pick the cover', ['Pick a frame where the hook text sits inside the safe zone'], slides.length - 1),
    fixed('publish', 'publish', platform, 'Publish natively', [
      platform === 'instagram' ? 'Keep it made-in-Edits — never save and re-upload' : 'Post from the app or “Share to TikTok” — never upload a watermarked export',
      'Put hashtags and keywords in the post caption (searchable)',
    ], slides.length - 1),
  )
  return steps
}

export interface PlanSummary {
  native: number
  fallback: number
  overlay: number
  plate: number
  paid: Tier[]
  verify: number
}

export function summarizePlan(steps: RebuildStep[]): PlanSummary {
  const s: PlanSummary = { native: 0, fallback: 0, overlay: 0, plate: 0, paid: [], verify: 0 }
  for (const x of steps) {
    s[x.strategy]++
    if (x.verify) s.verify++
    if (x.tier !== 'free' && !s.paid.includes(x.tier)) s.paid.push(x.tier)
  }
  return s
}

export function planToMarkdown(project: Project, platform: NativePlatform, steps: RebuildStep[]) {
  const p = NATIVE_PLATFORMS[platform]
  const sum = summarizePlan(steps)
  const lines = [
    `# ${project.name} — build plan for ${p.name} (${p.app})`,
    '',
    p.note,
    '',
    `Native ${sum.native} · Substitutes ${sum.fallback} · Overlay PNGs ${sum.overlay}${sum.paid.length ? ` · Needs: ${sum.paid.map((x) => TIERS[x].label).join(', ')}` : ' · All free'}`,
    '',
    'Rules: follow steps in order. Only use the tool named in each step. If a menu path is marked (verify), search the editor for the tool name instead.',
    '',
  ]
  steps.forEach((s, i) => {
    lines.push(`## ${i + 1}. ${s.title}  \`${t(s.at)}\``, `**Tool:** ${s.tool}${s.verify ? ' (verify)' : ''}  ·  **${s.strategy}**${s.tier !== 'free' ? `  ·  **${TIERS[s.tier].label}**` : ''}`, '')
    s.settings.forEach((x) => lines.push(`- [ ] ${x}`))
    lines.push('')
  })
  return lines.join('\n')
}

/** Machine-readable plan for browser automation (Playwright / agent) or a future API. */
export function planToManifest(project: Project, platform: NativePlatform, steps: RebuildStep[]) {
  const slides = getSlides(project)
  const all = slides.flatMap((s) => s.layers)
  return {
    schema: 'studio.rebuild/v2',
    platform,
    postType: project.postType ?? 'reel',
    project: { name: project.name, format: project.format, width: project.width, height: project.height, slides: slides.length },
    files: {
      plates: slides.map((_, i) => (slides.length > 1 ? `plate-${i + 1}.webm` : 'base-plate.webm')),
      overlays: all.filter((l) => strategyOf(l, platform) === 'overlay').map((l) => ({ layerId: l.id, file: `${l.name}.png` })),
    },
    summary: summarizePlan(steps),
    steps: steps.map((s) => ({ ...s, layers: s.layerIds.map((id) => all.find((l) => l.id === id)).filter(Boolean) })),
  }
}
