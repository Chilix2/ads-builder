'use client'

import { assetFromFile } from './assets'
import { createAudio, createMedia } from './factory'
import { COMMENTS, FORMS, HOOKS, SHAPES, STICKERS, TEMPLATES, TEXT_STYLES, effectItem, type LibraryItem } from './library'
import { playback } from './playback'
import { EFFECTS } from './presets'
import { editor } from './store'
import { uid, type Asset, type Layer, type SavedElement } from './types'

export const DRAG_MIME = 'application/x-studio-item'

const EFFECT_ITEMS = EFFECTS.map((e) => effectItem(e.id, e.name))
const ALL: LibraryItem[] = [...TEXT_STYLES, ...HOOKS, ...STICKERS, ...SHAPES, ...COMMENTS, ...FORMS, ...EFFECT_ITEMS]

export const getEffectItem = (id: string) => EFFECT_ITEMS.find((e) => e.id === id)

function place(layers: Layer[], pos?: { x: number; y: number }) {
  if (!pos) return layers
  return layers.map((l) => (l.kind === 'effect' || l.kind === 'audio' ? l : { ...l, x: pos.x, y: pos.y }))
}

export function insertItemById(id: string, pos?: { x: number; y: number }) {
  if (id.startsWith('asset:')) {
    const asset = editor.get().project.assets.find((a) => a.id === id.slice(6))
    if (asset) insertAsset(asset, pos)
    return
  }
  if (id.startsWith('tpl:')) {
    const tpl = TEMPLATES.find((t) => t.id === id)
    if (tpl) applyTemplate(tpl.id)
    return
  }
  if (id.startsWith('saved:')) {
    insertSaved(id.slice(6), pos)
    return
  }
  const item = ALL.find((i) => i.id === id)
  if (!item) return
  const { project } = editor.get()
  editor.addLayers(place(item.build(project, playback.get().time), pos))
}

export function applyTemplate(id: string) {
  const tpl = TEMPLATES.find((t) => t.id === id)
  if (!tpl) return
  const { project } = editor.get()
  editor.setProject({ ...project, name: tpl.name, layers: tpl.build(project, 0) })
  editor.select(null)
  playback.setTime(0)
}

export function insertAsset(asset: Asset, pos?: { x: number; y: number }) {
  const { project } = editor.get()
  const t = playback.get().time
  if (asset.type === 'audio') {
    editor.addLayers([createAudio(project, t, asset)])
    return
  }
  const layer = createMedia(project, t, asset)
  if (pos) {
    const s = 0.5
    layer.width = Math.round(layer.width * s)
    layer.height = Math.round(layer.height * s)
    layer.x = pos.x
    layer.y = pos.y
  }
  // Background footage goes under everything else.
  const isBackground = !pos
  if (isBackground) {
    editor.setProject({ ...project, layers: [layer, ...project.layers] })
    editor.select(layer.id)
  } else editor.addLayers([layer])
}

export async function importFiles(files: FileList | File[], opts: { insert?: boolean; pos?: { x: number; y: number } } = {}) {
  const assets = (await Promise.all(Array.from(files).map(assetFromFile))).filter((a): a is Asset => !!a)
  if (!assets.length) return []
  const { project } = editor.get()
  editor.setProject({ ...project, assets: [...project.assets, ...assets] })
  if (opts.insert) assets.forEach((a) => insertAsset(a, opts.pos))
  return assets
}

export function insertSaved(savedId: string, pos?: { x: number; y: number }) {
  const { project } = editor.get()
  const el = project.saved?.find((s) => s.id === savedId)
  if (!el) return
  const t = playback.get().time
  const layer = { ...structuredClone(el.layer), id: uid(), start: t, x: project.width / 2, y: project.height / 2 }
  editor.addLayers(place([layer], pos))
}

export function saveElement(layer: Layer, name = layer.name) {
  const { project } = editor.get()
  const saved: SavedElement = { id: uid('saved'), name, layer: structuredClone(layer) }
  editor.setProject({ ...project, saved: [saved, ...(project.saved ?? [])] })
}

export function removeSaved(savedId: string) {
  const { project } = editor.get()
  editor.setProject({ ...project, saved: (project.saved ?? []).filter((s) => s.id !== savedId) })
}
