'use client'

import { SAMPLE_ASSETS, createAudio, createEffect, createMedia, createText, unit } from './factory'
import { playback } from './playback'
import { editor } from './store'
import type { Asset, EffectType, Layer, Project, TextLayer } from './types'

/**
 * CapCut-style AutoCut: footage is split into shots whose lengths follow a beat
 * pattern, every cut lands on a beat, and the template decides the transition,
 * camera move, grade and title. With music in the project the beat grid comes
 * from the track itself; otherwise the template's BPM is used.
 */
export interface CutTemplate {
  id: string
  name: string
  description: string
  bpm: number
  /** Shot lengths in beats, cycled. */
  pattern: number[]
  shots: number
  filter: string
  /** Effect placed on every cut. */
  cut: EffectType | null
  /** Extra effect on every 4th cut (downbeat accent). */
  accent: EffectType | null
  shotIn: string | null
  shotLoop: EffectType | null
  overlays: EffectType[]
  title: ((p: Pick<Project, 'width' | 'height'>) => Partial<TextLayer>) | null
  outro: EffectType | null
}

const S = (p: Pick<Project, 'width' | 'height'>, n: number) => Math.round(n * unit(p))

export const CUT_TEMPLATES: CutTemplate[] = [
  {
    id: 'cut:beat-drop',
    name: 'Beat drop',
    description: 'Fast cuts with zoom punches, flash on every downbeat',
    bpm: 128,
    pattern: [2, 2, 1, 1, 2, 1, 1, 4],
    shots: 10,
    filter: 'pop',
    cut: 'zoom-punch',
    accent: 'flash',
    shotIn: null,
    shotLoop: null,
    overlays: [],
    title: (p) => ({ text: 'WAIT FOR IT', font: 'anton', fontWeight: 400, fontSize: S(p, 140), color: '#ffffff', strokeColor: '#000000', strokeWidth: S(p, 8), y: p.height * 0.2, animIn: { type: 'zoom-out', duration: 0.3 } }),
    outro: null,
  },
  {
    id: 'cut:velocity',
    name: 'Velocity',
    description: 'Hard 1-beat cuts with impact shake and a punchy grade',
    bpm: 120,
    pattern: [1, 1, 1, 1, 2],
    shots: 12,
    filter: 'drama',
    cut: 'shake',
    accent: 'zoom-punch',
    shotIn: 'zoom-out',
    shotLoop: null,
    overlays: ['vignette'],
    title: null,
    outro: 'flash',
  },
  {
    id: 'cut:cinematic',
    name: 'Cinematic flow',
    description: 'Long 4-beat shots, slow push-ins, letterbox and grain',
    bpm: 80,
    pattern: [4, 4, 4],
    shots: 5,
    filter: 'drama',
    cut: null,
    accent: null,
    shotIn: 'fade',
    shotLoop: 'ken-burns',
    overlays: ['letterbox', 'grain'],
    title: (p) => ({ text: 'a short film', font: 'playfair', fontWeight: 700, italic: true, fontSize: S(p, 96), animIn: { type: 'blur-in', duration: 1.2 }, animOut: { type: 'fade', duration: 0.8 } }),
    outro: 'fade-black',
  },
  {
    id: 'cut:photo-dump',
    name: 'Photo dump',
    description: 'One photo per beat with a flash between, warm film look',
    bpm: 100,
    pattern: [1],
    shots: 14,
    filter: 'warm',
    cut: 'flash',
    accent: null,
    shotIn: 'pop',
    shotLoop: null,
    overlays: ['grain'],
    title: (p) => ({ text: 'photo dump', font: 'marker', fontWeight: 400, fontSize: S(p, 110), y: p.height * 0.82, animIn: { type: 'pop', duration: 0.4 } }),
    outro: null,
  },
  {
    id: 'cut:glitch',
    name: 'Glitch hype',
    description: 'Cyber grade, scanlines and rapid 1-1-2 cuts',
    bpm: 140,
    pattern: [1, 1, 2],
    shots: 12,
    filter: 'cyber',
    cut: 'zoom-punch',
    accent: 'shake',
    shotIn: null,
    shotLoop: null,
    overlays: ['scanlines'],
    title: (p) => ({ text: 'NEW DROP', font: 'anton', fontWeight: 400, fontSize: S(p, 150), color: '#22d3ee', y: p.height * 0.5, loop: { type: 'glitch', speed: 1 } }),
    outro: 'flash',
  },
  {
    id: 'cut:recap',
    name: 'Story recap',
    description: 'Slide-in shots with numbered captions, relaxed tempo',
    bpm: 90,
    pattern: [2, 2, 4],
    shots: 6,
    filter: 'golden',
    cut: null,
    accent: 'light-leak',
    shotIn: 'slide-left',
    shotLoop: 'zoom-pulse',
    overlays: [],
    title: null,
    outro: 'fade-black',
  },
]

/* ---------- Beat detection ---------- */

const beatCache = new Map<string, number[]>()

/** Onset-energy beat tracker: estimates tempo by autocorrelation, then phase-aligns to the strongest onsets. */
export async function detectBeats(asset: Asset): Promise<number[]> {
  const hit = beatCache.get(asset.src)
  if (hit) return hit
  const buf = await (await fetch(asset.src)).arrayBuffer()
  const ctx = new OfflineAudioContext(1, 44100, 44100)
  const audio = await ctx.decodeAudioData(buf)
  const data = audio.getChannelData(0)
  const hop = 512
  const rate = audio.sampleRate / hop
  const n = Math.floor(data.length / hop)
  const energy = new Float32Array(n)
  for (let i = 0; i < n; i++) {
    let e = 0
    for (let j = i * hop; j < (i + 1) * hop; j++) e += data[j] * data[j]
    energy[i] = Math.sqrt(e / hop)
  }
  const flux = new Float32Array(n)
  for (let i = 1; i < n; i++) flux[i] = Math.max(0, energy[i] - energy[i - 1])

  let bestLag = Math.round((60 / 120) * rate)
  let best = -1
  for (let bpm = 70; bpm <= 180; bpm++) {
    const lag = Math.round((60 / bpm) * rate)
    let c = 0
    for (let i = lag; i < n; i++) c += flux[i] * flux[i - lag]
    if (c > best) {
      best = c
      bestLag = lag
    }
  }
  let phase = 0
  let phaseScore = -1
  for (let p = 0; p < bestLag; p++) {
    let c = 0
    for (let i = p; i < n; i += bestLag) c += flux[i]
    if (c > phaseScore) {
      phaseScore = c
      phase = p
    }
  }
  const beats: number[] = []
  for (let i = phase; i < n; i += bestLag) beats.push(i / rate)
  beatCache.set(asset.src, beats)
  return beats
}

/* ---------- Build ---------- */

function footage(project: Project): Asset[] {
  const own = project.assets.filter((a) => (a.type === 'image' || a.type === 'video') && !SAMPLE_ASSETS.some((s) => s.id === a.id))
  return own.length ? own : project.assets.filter((a) => a.type === 'image' || a.type === 'video')
}

function music(project: Project): Asset | null {
  const onTimeline = project.layers.find((l) => l.kind === 'audio')
  const id = onTimeline && onTimeline.kind === 'audio' ? onTimeline.assetId : null
  return project.assets.find((a) => a.id === id) ?? project.assets.find((a) => a.type === 'audio') ?? null
}

export function buildCut(project: Project, tpl: CutTemplate, beats?: number[]): Layer[] {
  const clips = footage(project)
  if (!clips.length) return []
  const spb = 60 / tpl.bpm
  const beatAt = (i: number) => (beats?.length ? (beats[i] ?? beats[beats.length - 1] + (i - beats.length + 1) * spb) - beats[0] : i * spb)
  const layers: Layer[] = []
  const shots: { start: number; end: number }[] = []
  let b = 0
  for (let i = 0; i < tpl.shots; i++) {
    const len = tpl.pattern[i % tpl.pattern.length]
    shots.push({ start: beatAt(b), end: beatAt(b + len) })
    b += len
  }
  const total = shots[shots.length - 1].end

  shots.forEach((shot, i) => {
    const asset = clips[i % clips.length]
    const dur = Math.max(0.2, shot.end - shot.start)
    const pass = Math.floor(i / clips.length)
    const trimStart = asset.type === 'video' ? Math.max(0, Math.min(asset.duration - dur, pass * dur * 1.5)) : 0
    layers.push({
      ...createMedia(project, shot.start, asset, { duration: dur, filter: tpl.filter, trimStart, animIn: tpl.shotIn ? { type: tpl.shotIn, duration: Math.min(0.4, dur / 2) } : null }),
      name: `Shot ${i + 1}`,
    })
    if (tpl.shotLoop) layers.push(createEffect(project, shot.start, tpl.shotLoop, { duration: dur, intensity: 0.6 }))
    if (i > 0 && tpl.cut) layers.push(createEffect(project, shot.start, tpl.cut, { duration: Math.min(0.5, dur) }))
    if (i > 0 && i % 4 === 0 && tpl.accent) layers.push(createEffect(project, shot.start, tpl.accent, { duration: Math.min(0.6, dur) }))
  })
  if (tpl.id === 'cut:recap')
    shots.forEach((shot, i) =>
      layers.push(createText(project, shot.start, { text: `Day ${i + 1}`, fontSize: S(project, 72), y: project.height * 0.8, duration: shot.end - shot.start, bgMode: 'line', bgColor: '#ffffff', color: '#111111', shadow: false, animIn: { type: 'slide-up', duration: 0.4 } })),
    )
  for (const o of tpl.overlays) layers.push(createEffect(project, 0, o, { duration: total }))
  const title = tpl.title?.(project)
  if (title) layers.push(createText(project, 0, { duration: Math.min(total, beatAt(4) || 2), ...title }))
  if (tpl.outro) layers.push(createEffect(project, Math.max(0, total - 0.6), tpl.outro, { duration: 0.6 }))
  const track = music(project)
  if (track) layers.push({ ...createAudio(project, 0, track), duration: Math.min(track.duration, total) })
  return layers
}

export async function applyCutTemplate(id: string): Promise<{ beatSynced: boolean; shots: number } | null> {
  const tpl = CUT_TEMPLATES.find((t) => t.id === id)
  if (!tpl) return null
  const { project } = editor.get()
  const track = music(project)
  let beats: number[] | undefined
  if (track) beats = await detectBeats(track).catch(() => undefined)
  const layers = buildCut(project, tpl, beats)
  if (!layers.length) return null
  editor.setProject({ ...project, name: tpl.name, layers })
  editor.select(null)
  playback.setTime(0)
  return { beatSynced: !!beats?.length, shots: tpl.shots }
}
