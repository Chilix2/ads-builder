import type { FontKey } from './types'

export const FONT_OPTIONS: { key: FontKey; label: string; cssVar: string | null; fallback: string }[] = [
  { key: 'geist', label: 'Geist', cssVar: '--font-geist-sans', fallback: 'system-ui, sans-serif' },
  { key: 'helvetica', label: 'Helvetica', cssVar: null, fallback: '"Helvetica Neue", Helvetica, Arial, sans-serif' },
  { key: 'anton', label: 'Anton', cssVar: '--font-anton', fallback: 'Impact, sans-serif' },
  { key: 'playfair', label: 'Playfair', cssVar: '--font-playfair', fallback: 'Georgia, serif' },
  { key: 'marker', label: 'Marker', cssVar: '--font-marker', fallback: 'cursive' },
  { key: 'mono', label: 'Geist Mono', cssVar: '--font-geist-mono', fallback: 'ui-monospace, monospace' },
]

const cache = new Map<FontKey, string>()

export function fontFamily(key: FontKey): string {
  const opt = FONT_OPTIONS.find((f) => f.key === key) ?? FONT_OPTIONS[0]
  if (typeof window === 'undefined') return opt.fallback
  const cached = cache.get(key)
  if (cached) return cached
  let family = opt.fallback
  if (opt.cssVar) {
    const v = getComputedStyle(document.documentElement).getPropertyValue(opt.cssVar).trim()
    if (v) family = `${v}, ${opt.fallback}`
  }
  cache.set(key, family)
  return family
}

export async function loadAllFonts() {
  if (typeof document === 'undefined') return
  await Promise.all(
    FONT_OPTIONS.flatMap((f) =>
      [400, 700, 800].map((w) => document.fonts.load(`${w} 40px ${fontFamily(f.key)}`).catch(() => [])),
    ),
  )
}
