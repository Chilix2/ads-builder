'use client'

import { useSyncExternalStore } from 'react'
import { createDemoProject } from './factory'
import { getSlides, uid, type Layer, type Project } from './types'

interface EditorState {
  project: Project
  selectedId: string | null
  past: Project[]
  future: Project[]
}

const HISTORY = 80
let state: EditorState = { project: createDemoProject(), selectedId: null, past: [], future: [] }
const listeners = new Set<() => void>()

function emit() {
  listeners.forEach((l) => l())
}

function set(next: Partial<EditorState>) {
  state = { ...state, ...next }
  emit()
}

export const editor = {
  get: () => state,
  subscribe(l: () => void) {
    listeners.add(l)
    return () => {
      listeners.delete(l)
    }
  },
  /** Push the current project onto the undo stack (call before a live gesture). */
  checkpoint() {
    set({ past: [...state.past, state.project].slice(-HISTORY), future: [] })
  },
  setProject(project: Project, record = true) {
    if (record) set({ project, past: [...state.past, state.project].slice(-HISTORY), future: [] })
    else set({ project })
  },
  replaceProject(project: Project) {
    set({ project, selectedId: null, past: [], future: [] })
  },
  selectSlide(index: number) {
    const slides = getSlides(state.project)
    if (!slides[index]) return
    editor.setProject({ ...state.project, slides, activeSlide: index, layers: slides[index].layers })
    set({ selectedId: null })
  },
  addSlide(duplicate = false) {
    const slides = getSlides(state.project)
    const active = state.project.activeSlide ?? 0
    const layers = duplicate ? slides[active].layers.map((l) => ({ ...l, id: uid() }) as Layer) : []
    const next = [...slides]
    next.splice(active + 1, 0, { id: uid(), name: `Slide ${slides.length + 1}`, layers })
    editor.setProject({ ...state.project, slides: next, activeSlide: active + 1, layers })
    set({ selectedId: null })
  },
  removeSlide(index: number) {
    const slides = getSlides(state.project)
    if (slides.length < 2) return
    const next = slides.filter((_, i) => i !== index)
    const active = Math.min(Math.max(0, (state.project.activeSlide ?? 0) - (index <= (state.project.activeSlide ?? 0) ? 1 : 0)), next.length - 1)
    editor.setProject({ ...state.project, slides: next, activeSlide: active, layers: next[active].layers })
    set({ selectedId: null })
  },
  moveSlide(from: number, to: number) {
    const slides = getSlides(state.project)
    if (to < 0 || to >= slides.length) return
    const next = [...slides]
    const [s] = next.splice(from, 1)
    next.splice(to, 0, s)
    const activeId = slides[state.project.activeSlide ?? 0].id
    editor.setProject({ ...state.project, slides: next, activeSlide: next.findIndex((x) => x.id === activeId) })
  },
  updateLayer(id: string, patch: Partial<Layer>, record = true) {
    const project = {
      ...state.project,
      layers: state.project.layers.map((l) => (l.id === id ? ({ ...l, ...patch } as Layer) : l)),
    }
    editor.setProject(project, record)
  },
  addLayers(layers: Layer[], select = true) {
    if (!layers.length) return
    editor.setProject({ ...state.project, layers: [...state.project.layers, ...layers] })
    if (select) set({ selectedId: layers[layers.length - 1].id })
  },
  removeLayer(id: string) {
    editor.setProject({ ...state.project, layers: state.project.layers.filter((l) => l.id !== id) })
    if (state.selectedId === id) set({ selectedId: null })
  },
  duplicate(id: string) {
    const l = state.project.layers.find((x) => x.id === id)
    if (!l) return
    const copy = { ...l, id: uid(), name: `${l.name} copy`, x: l.x + 40, y: l.y + 40 } as Layer
    const idx = state.project.layers.indexOf(l)
    const layers = [...state.project.layers]
    layers.splice(idx + 1, 0, copy)
    editor.setProject({ ...state.project, layers })
    set({ selectedId: copy.id })
  },
  reorder(id: string, dir: 'forward' | 'backward' | 'front' | 'back') {
    const layers = [...state.project.layers]
    const i = layers.findIndex((l) => l.id === id)
    if (i < 0) return
    const [l] = layers.splice(i, 1)
    const to =
      dir === 'front' ? layers.length : dir === 'back' ? 0 : dir === 'forward' ? Math.min(layers.length, i + 1) : Math.max(0, i - 1)
    layers.splice(to, 0, l)
    editor.setProject({ ...state.project, layers })
  },
  split(id: string, t: number) {
    const l = state.project.layers.find((x) => x.id === id)
    if (!l || t <= l.start + 0.05 || t >= l.start + l.duration - 0.05) return
    const cut = t - l.start
    const a = { ...l, duration: cut, animOut: null } as Layer
    const b = { ...l, id: uid(), name: `${l.name} (2)`, start: t, duration: l.duration - cut, animIn: null } as Layer
    if ((b.kind === 'media' || b.kind === 'audio') && (l.kind === 'media' || l.kind === 'audio')) b.trimStart = l.trimStart + cut
    const layers = state.project.layers.flatMap((x) => (x.id === id ? [a, b] : [x]))
    editor.setProject({ ...state.project, layers })
    set({ selectedId: b.id })
  },
  select(id: string | null) {
    if (id !== state.selectedId) set({ selectedId: id })
  },
  undo() {
    const prev = state.past[state.past.length - 1]
    if (!prev) return
    set({ project: prev, past: state.past.slice(0, -1), future: [state.project, ...state.future] })
  },
  redo() {
    const [next, ...rest] = state.future
    if (!next) return
    set({ project: next, past: [...state.past, state.project], future: rest })
  },
}

export function useEditor<T>(selector: (s: EditorState) => T): T {
  return useSyncExternalStore(
    editor.subscribe,
    () => selector(state),
    () => selector(state),
  )
}

export function useSelectedLayer() {
  return useEditor((s) => s.project.layers.find((l) => l.id === s.selectedId) ?? null)
}
