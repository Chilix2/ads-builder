'use client'

import { clamp, uid, type Asset, type Project } from './types'

const images = new Map<string, HTMLImageElement>()
const media = new Map<string, HTMLMediaElement>()
const listeners = new Set<() => void>()

export function onAssetsChanged(cb: () => void) {
  listeners.add(cb)
  return () => {
    listeners.delete(cb)
  }
}

function emit() {
  listeners.forEach((l) => l())
}

export function getImage(asset: Asset): HTMLImageElement | null {
  if (typeof window === 'undefined') return null
  let img = images.get(asset.id)
  if (!img || img.dataset.src !== asset.src) {
    img = new Image()
    img.crossOrigin = 'anonymous'
    img.decoding = 'async'
    img.dataset.src = asset.src
    img.onload = emit
    img.src = asset.src
    images.set(asset.id, img)
  }
  return img.complete && img.naturalWidth > 0 ? img : null
}

let audioCtx: AudioContext | null = null
let captureDest: MediaStreamAudioDestinationNode | null = null
const connected = new WeakSet<HTMLMediaElement>()

function connect(el: HTMLMediaElement) {
  if (!audioCtx || !captureDest || connected.has(el)) return
  try {
    const src = audioCtx.createMediaElementSource(el)
    src.connect(audioCtx.destination)
    src.connect(captureDest)
    connected.add(el)
  } catch {
    // element already bound to a source node
  }
}

export function startAudioCapture(): MediaStreamTrack[] {
  if (!audioCtx) {
    audioCtx = new AudioContext()
    captureDest = audioCtx.createMediaStreamDestination()
  }
  void audioCtx.resume()
  media.forEach(connect)
  return captureDest!.stream.getAudioTracks()
}

function getLayerMedia(layerId: string, asset: Asset): HTMLMediaElement {
  const existing = media.get(layerId)
  if (existing && existing.dataset.src === asset.src) return existing
  if (existing) {
    existing.pause()
    existing.removeAttribute('src')
  }
  const el: HTMLMediaElement = asset.type === 'audio' ? new Audio() : document.createElement('video')
  el.crossOrigin = 'anonymous'
  el.preload = 'auto'
  el.dataset.src = asset.src
  if (el instanceof HTMLVideoElement) el.playsInline = true
  el.addEventListener('loadeddata', emit)
  el.src = asset.src
  media.set(layerId, el)
  connect(el)
  return el
}

export function getVideoFrame(layerId: string): HTMLVideoElement | null {
  const el = media.get(layerId)
  return el instanceof HTMLVideoElement && el.readyState >= 2 ? el : null
}

export function syncMedia(project: Project, t: number, playing: boolean) {
  const live = new Set<string>()
  for (const layer of project.layers) {
    if (layer.kind !== 'media' && layer.kind !== 'audio') continue
    const asset = project.assets.find((a) => a.id === layer.assetId)
    if (!asset || asset.type === 'image') continue
    live.add(layer.id)
    const el = getLayerMedia(layer.id, asset)
    const local = t - layer.start
    const active = !layer.hidden && local >= 0 && local < layer.duration
    if (!active) {
      if (!el.paused) el.pause()
      continue
    }
    const target = local + layer.trimStart
    let vol = layer.volume
    if (layer.kind === 'audio') {
      if (layer.fadeIn > 0) vol *= clamp(local / layer.fadeIn)
      if (layer.fadeOut > 0) vol *= clamp((layer.duration - local) / layer.fadeOut)
    }
    el.volume = clamp(vol)
    el.muted = layer.kind === 'media' ? layer.muted : false
    if (playing) {
      if (el.paused) {
        el.currentTime = target
        void el.play().catch(() => {})
      } else if (Math.abs(el.currentTime - target) > 0.3) {
        el.currentTime = target
      }
    } else {
      if (!el.paused) el.pause()
      if (Math.abs(el.currentTime - target) > 0.04 && !el.seeking) el.currentTime = target
    }
  }
  for (const [id, el] of media) {
    if (!live.has(id)) {
      el.pause()
      media.delete(id)
    }
  }
}

export function pauseAllMedia() {
  media.forEach((el) => el.pause())
}

function probe(src: string, type: Asset['type']): Promise<{ width: number; height: number; duration: number }> {
  return new Promise((resolve) => {
    if (type === 'image') {
      const img = new Image()
      img.onload = () => resolve({ width: img.naturalWidth, height: img.naturalHeight, duration: 5 })
      img.onerror = () => resolve({ width: 1080, height: 1920, duration: 5 })
      img.src = src
      return
    }
    const el = type === 'audio' ? new Audio() : document.createElement('video')
    el.preload = 'metadata'
    el.onloadedmetadata = () => {
      const v = el instanceof HTMLVideoElement ? el : null
      resolve({
        width: v?.videoWidth ?? 0,
        height: v?.videoHeight ?? 0,
        duration: Number.isFinite(el.duration) ? el.duration : 10,
      })
    }
    el.onerror = () => resolve({ width: 1080, height: 1920, duration: 10 })
    el.src = src
  })
}

export async function assetFromFile(file: File): Promise<Asset | null> {
  const type: Asset['type'] | null = file.type.startsWith('video')
    ? 'video'
    : file.type.startsWith('audio')
      ? 'audio'
      : file.type.startsWith('image')
        ? 'image'
        : null
  if (!type) return null
  const src = URL.createObjectURL(file)
  const meta = await probe(src, type)
  return { id: uid('asset'), name: file.name, type, src, ...meta }
}

export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(String(r.result))
    r.onerror = reject
    r.readAsDataURL(file)
  })
}
