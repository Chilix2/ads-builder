'use client'

import { getImage } from './assets'
import { fontFamily } from './fonts'
import type { FormLayer, Project } from './types'

type Ctx = CanvasRenderingContext2D
type Token = { text: string; accent: boolean }

/** Forms are drawn in a 1000px-wide reference space and scaled to the layer width. */
const R = 1000
const HELV = '"Helvetica Neue", Helvetica, Arial, sans-serif'

let mc: HTMLCanvasElement | null = null
const measure = () => (mc ??= document.createElement('canvas')).getContext('2d')!

function tokens(text: string): Token[] {
  const out: Token[] = []
  text.split('*').forEach((part, i) => {
    for (const w of part.split(/(\s+)/)) if (w) out.push({ text: w, accent: i % 2 === 1 })
  })
  return out
}

function richLines(ctx: Ctx, text: string, maxW: number, font: (accent: boolean) => string): Token[][] {
  const lines: Token[][] = []
  for (const para of text.split('\n')) {
    let line: Token[] = []
    let width = 0
    for (const t of tokens(para)) {
      ctx.font = font(t.accent)
      const tw = ctx.measureText(t.text).width
      if (width + tw > maxW && line.length && t.text.trim()) {
        lines.push(line)
        line = []
        width = 0
      }
      if (!line.length && !t.text.trim()) continue
      line.push(t)
      width += tw
    }
    lines.push(line)
  }
  return lines.map((l) => (l.length && !l[l.length - 1].text.trim() ? l.slice(0, -1) : l))
}

function drawRich(ctx: Ctx, lines: Token[][], x: number, y: number, lh: number, align: CanvasTextAlign, font: (accent: boolean) => string, color: string, accent: string) {
  ctx.textBaseline = 'middle'
  ctx.textAlign = 'left'
  lines.forEach((line, i) => {
    const widths = line.map((t) => {
      ctx.font = font(t.accent)
      return ctx.measureText(t.text).width
    })
    const total = widths.reduce((a, b) => a + b, 0)
    let cx = align === 'center' ? x - total / 2 : align === 'right' ? x - total : x
    line.forEach((t, j) => {
      ctx.font = font(t.accent)
      ctx.fillStyle = t.accent ? accent : color
      ctx.fillText(t.text, cx, y + i * lh + lh / 2)
      cx += widths[j]
    })
  })
}

const sansFont = (size: number, weight: number, accentWeight = weight) => (a: boolean) => `${a ? accentWeight : weight} ${size}px ${HELV}`
const serifFont = (size: number, italicAccent = true) => (a: boolean) => `${a && italicAccent ? 'italic 800' : '400'} ${size}px ${fontFamily('playfair')}`

function panel(ctx: Ctx, w: number, h: number, r: number, fill: string, shadow = true) {
  ctx.save()
  if (shadow) {
    ctx.shadowColor = 'rgba(0,0,0,0.22)'
    ctx.shadowBlur = 40
    ctx.shadowOffsetY = 12
  }
  ctx.fillStyle = fill
  ctx.beginPath()
  ctx.roundRect(0, 0, w, h, r)
  ctx.fill()
  ctx.restore()
}

function hline(ctx: Ctx, x1: number, x2: number, y: number, color = 'rgba(0,0,0,0.14)', width = 2) {
  ctx.strokeStyle = color
  ctx.lineWidth = width
  ctx.beginPath()
  ctx.moveTo(x1, y)
  ctx.lineTo(x2, y)
  ctx.stroke()
}

function drawCover(ctx: Ctx, project: Project, l: FormLayer, x: number, y: number, w: number, h: number, radius = 0, full?: { x: number; y: number; w: number; h: number }) {
  ctx.save()
  ctx.beginPath()
  ctx.roundRect(x, y, w, h, radius)
  ctx.clip()
  const asset = project.assets.find((a) => a.id === l.imageAssetId && a.type === 'image')
  const img = asset ? getImage(asset) : null
  if (img) {
    const f = full ?? { x, y, w, h }
    const k = Math.max(f.w / img.naturalWidth, f.h / img.naturalHeight)
    const dw = img.naturalWidth * k
    const dh = img.naturalHeight * k
    ctx.drawImage(img, f.x + (f.w - dw) / 2, f.y + (f.h - dh) / 2, dw, dh)
  } else {
    ctx.fillStyle = '#d4d4d8'
    ctx.fillRect(x, y, w, h)
    ctx.fillStyle = '#71717a'
    ctx.font = `500 ${Math.min(44, w / 14)}px ${HELV}`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillText('Pick a photo in the Inspector', x + w / 2, y + h / 2)
  }
  ctx.restore()
}

function magnifier(ctx: Ctx, x: number, y: number, s: number, color: string) {
  ctx.strokeStyle = color
  ctx.lineWidth = s * 0.14
  ctx.lineCap = 'round'
  ctx.beginPath()
  ctx.arc(x - s * 0.1, y - s * 0.1, s * 0.3, 0, Math.PI * 2)
  ctx.moveTo(x + s * 0.12, y + s * 0.12)
  ctx.lineTo(x + s * 0.4, y + s * 0.4)
  ctx.stroke()
}

/* ---------- layout ---------- */

function layout(l: FormLayer) {
  const ctx = measure()
  switch (l.form) {
    case 'ios-alert': {
      const title = richLines(ctx, l.title, 840, sansFont(96, 600, 800))
      const top = 130 + title.length * 112
      return { h: top + (l.primary || l.secondary ? 180 : 0), title, top }
    }
    case 'airdrop': {
      const body = richLines(ctx, l.body, 860, sansFont(50, 400, 700))
      const header = 200 + body.length * 64
      return { h: header + 760 + 170, body, header }
    }
    case 'notes': {
      const title = richLines(ctx, l.title, 800, serifFont(150))
      const body = richLines(ctx, l.body, 800, serifFont(100))
      return { h: 220 + title.length * 165 + body.length * 115 + 80, title, body }
    }
    case 'google-search': {
      const n = l.items.length
      return { h: 150 + (n ? 40 + n * 150 + 30 : 0) + 20 }
    }
    case 'context-menu': {
      const h = l.items.reduce((a, it) => a + (it.trim() === '---' ? 40 : 150), 0)
      return { h: h + 80 }
    }
    case 'id-badge': {
      const title = richLines(ctx, l.title.toUpperCase(), 860, sansFont(76, 400, 700))
      const cardTop = 150
      const textTop = cardTop + 60 + 820 + 70
      const fields = textTop + title.length * 88 + 60
      return { h: fields + 220, title, cardTop, textTop, fields }
    }
    case 'imessage':
      return { h: 780 }
    case 'safari-tabs': {
      const n = Math.max(1, l.items.length)
      return { h: (n - 1) * 330 + 420 + 160, n }
    }
  }
}

export function formHeight(l: FormLayer) {
  return Math.round((layout(l).h * l.width) / R)
}

/* ---------- drawing ---------- */

export function drawForm(ctx: Ctx, project: Project, l: FormLayer) {
  const s = l.width / R
  const L = layout(l) as ReturnType<typeof layout> & Record<string, unknown>
  const H = L.h
  ctx.translate(-l.width / 2, (-H * s) / 2)
  ctx.scale(s, s)
  ctx.textBaseline = 'middle'
  const accent = l.accent
  const tc = l.textColor

  switch (l.form) {
    case 'ios-alert': {
      const { title, top } = L as { title: Token[][]; top: number }
      panel(ctx, R, H, 70, l.surface)
      drawRich(ctx, title, R / 2, 65, 112, 'center', sansFont(96, 600, 800), tc, accent)
      if (l.primary || l.secondary) {
        hline(ctx, 0, R, top, 'rgba(0,0,0,0.18)', 3)
        ctx.font = `500 76px ${HELV}`
        ctx.fillStyle = accent
        ctx.textAlign = 'center'
        if (l.secondary) {
          ctx.fillText(l.secondary, R / 4, top + 90)
          ctx.font = `700 76px ${HELV}`
          ctx.fillText(l.primary, (R * 3) / 4, top + 90)
          ctx.fillStyle = 'rgba(0,0,0,0.18)'
          ctx.fillRect(R / 2 - 1.5, top, 3, 180)
        } else ctx.fillText(l.primary, R / 2, top + 90)
      }
      break
    }
    case 'airdrop': {
      const { body, header } = L as { body: Token[][]; header: number }
      panel(ctx, R, H, 60, l.surface)
      ctx.fillStyle = tc
      ctx.textAlign = 'center'
      ctx.font = `700 72px ${HELV}`
      ctx.fillText(l.title, R / 2, 100)
      drawRich(ctx, body, R / 2, 150, 64, 'center', sansFont(50, 400, 700), tc, tc)
      ctx.save()
      ctx.beginPath()
      ctx.rect(0, header, R, 760)
      ctx.clip()
      drawCover(ctx, project, l, 0, header, R, 760)
      ctx.restore()
      const by = header + 760
      ctx.fillStyle = 'rgba(0,0,0,0.12)'
      ctx.fillRect(R / 2 - 1, by, 2, 170)
      ctx.textAlign = 'center'
      ctx.fillStyle = accent
      ctx.font = `400 64px ${HELV}`
      ctx.fillText(l.secondary, R / 4, by + 85)
      ctx.font = `700 64px ${HELV}`
      ctx.fillText(l.primary, (R * 3) / 4, by + 85)
      break
    }
    case 'notes': {
      const { title, body } = L as { title: Token[][]; body: Token[][] }
      panel(ctx, R, H, 90, l.surface)
      ctx.fillStyle = '#f1f1f3'
      ctx.beginPath()
      ctx.arc(110, 110, 66, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = '#111'
      ctx.lineWidth = 9
      ctx.lineCap = 'round'
      ctx.beginPath()
      ctx.moveTo(122, 80)
      ctx.lineTo(92, 110)
      ctx.lineTo(122, 140)
      ctx.stroke()
      ctx.fillStyle = accent
      ctx.font = `600 64px ${HELV}`
      ctx.textAlign = 'left'
      ctx.fillText(l.primary, 200, 112)
      ctx.fillStyle = '#f1f1f3'
      ctx.beginPath()
      ctx.roundRect(560, 50, 260, 120, 60)
      ctx.fill()
      ctx.fillStyle = '#777'
      for (let i = 0; i < 3; i++) {
        ctx.beginPath()
        ctx.arc(720 + i * 26, 110, 8, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.strokeStyle = '#888'
      ctx.lineWidth = 6
      ctx.strokeRect(610, 95, 46, 44)
      ctx.fillStyle = accent
      ctx.beginPath()
      ctx.arc(905, 110, 66, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = l.surface
      ctx.lineWidth = 8
      ctx.beginPath()
      ctx.moveTo(875, 110)
      ctx.lineTo(898, 135)
      ctx.lineTo(940, 84)
      ctx.stroke()
      ctx.fillStyle = accent
      ctx.fillRect(70, 240, 8, 160)
      drawRich(ctx, title, R / 2 + 30, 220, 165, 'center', serifFont(150), tc, accent)
      drawRich(ctx, body, R / 2 + 30, 220 + title.length * 165, 115, 'center', serifFont(100), tc, accent)
      break
    }
    case 'google-search': {
      panel(ctx, R, 150, 75, l.surface)
      const gColors = ['#4285f4', '#ea4335', '#fbbc05', '#34a853']
      ctx.lineWidth = 14
      for (let i = 0; i < 4; i++) {
        ctx.strokeStyle = gColors[i]
        ctx.beginPath()
        ctx.arc(85, 75, 30, (i * Math.PI) / 2 - Math.PI / 4, ((i + 1) * Math.PI) / 2 - Math.PI / 4)
        ctx.stroke()
      }
      ctx.fillStyle = gColors[0]
      ctx.fillRect(85, 69, 32, 12)
      ctx.fillStyle = '#e5e5e5'
      ctx.fillRect(150, 45, 3, 60)
      const ql = richLines(measure(), l.title, 680, sansFont(44, 400, 500))
      drawRich(ctx, ql.slice(0, 1), 180, 45, 60, 'left', sansFont(44, 400, 500), tc, accent)
      ctx.fillStyle = gColors[0]
      ctx.beginPath()
      ctx.roundRect(918, 40, 26, 50, 13)
      ctx.fill()
      ctx.strokeStyle = gColors[1]
      ctx.lineWidth = 6
      ctx.beginPath()
      ctx.arc(931, 80, 22, 0, Math.PI)
      ctx.stroke()
      ctx.fillStyle = gColors[3]
      ctx.fillRect(928, 102, 6, 14)
      if (l.items.length) {
        const top = 190
        const ch = l.items.length * 150 + 30
        ctx.save()
        ctx.translate(40, top)
        panel(ctx, R - 80, ch, 70, l.surface)
        l.items.forEach((it, i) => {
          const y = 15 + i * 150
          magnifier(ctx, 75, y + 75, 50, '#555')
          const lines = richLines(measure(), it, 760, sansFont(44, 400, 600))
          drawRich(ctx, lines.slice(0, 1), 140, y + 45, 60, 'left', sansFont(44, 400, 600), tc, accent)
          if (i < l.items.length - 1) hline(ctx, 40, R - 120, y + 150, 'rgba(0,0,0,0.08)', 3)
        })
        ctx.restore()
      }
      break
    }
    case 'context-menu': {
      panel(ctx, R, H, 110, l.surface)
      let y = 40
      l.items.forEach((raw, i) => {
        const it = raw.trim()
        if (it === '---') {
          hline(ctx, 0, R, y + 20, 'rgba(0,0,0,0.18)', 8)
          y += 40
          return
        }
        const sub = it.endsWith('>')
        const label = sub ? it.slice(0, -1).trim() : it
        const hl = i === l.highlight
        if (hl) {
          ctx.fillStyle = accent
          ctx.fillRect(0, y + 10, R, 130)
        }
        ctx.strokeStyle = tc
        ctx.lineWidth = 4
        ctx.beginPath()
        ctx.roundRect(55, y + 45, 60, 60, 14)
        ctx.stroke()
        ctx.fillStyle = tc
        ctx.textAlign = 'left'
        ctx.font = `${hl ? 800 : 400} 64px ${HELV}`
        ctx.fillText(label, 160, y + 77)
        if (sub) {
          ctx.font = `400 60px ${HELV}`
          ctx.fillText('>', R - 90, y + 77)
        }
        y += 150
      })
      break
    }
    case 'id-badge': {
      const { title, cardTop, textTop, fields } = L as { title: Token[][]; cardTop: number; textTop: number; fields: number }
      ctx.save()
      ctx.translate(0, cardTop)
      panel(ctx, R, H - cardTop, 40, l.surface)
      ctx.restore()
      drawCover(ctx, project, l, 50, cardTop + 60, R - 100, 820)
      ctx.fillStyle = l.surface
      ctx.beginPath()
      ctx.roundRect(R / 2 - 45, cardTop + 25, 90, 50, 25)
      ctx.fill()
      ctx.strokeStyle = accent
      ctx.lineWidth = 22
      ctx.beginPath()
      ctx.ellipse(R / 2, cardTop - 20, 42, 80, 0, 0, Math.PI * 2)
      ctx.stroke()
      ctx.fillStyle = '#8a8f94'
      ctx.fillRect(R / 2 - 22, 0, 44, cardTop - 90)
      drawRich(ctx, title, 50, textTop, 88, 'left', sansFont(76, 400, 700), tc, tc)
      const field = (label: string, value: string, y: number) => {
        ctx.textAlign = 'left'
        ctx.fillStyle = tc
        ctx.font = `400 40px ${HELV}`
        ctx.fillText(label, 50, y)
        const lw = ctx.measureText(label).width
        ctx.font = `400 46px ${fontFamily('marker')}`
        ctx.fillText(value, 60 + lw, y - 4)
        ctx.setLineDash([8, 6])
        hline(ctx, 50, 50 + lw + Math.max(220, ctx.measureText(value).width + 30), y + 32, 'rgba(0,0,0,0.5)', 2)
        ctx.setLineDash([])
      }
      field('Name:', l.primary, fields + 40)
      field('Role:', l.secondary, fields + 130)
      break
    }
    case 'imessage': {
      panel(ctx, R, H, 100, l.surface)
      ctx.fillStyle = tc
      ctx.textAlign = 'center'
      ctx.font = `500 44px ${HELV}`
      ctx.fillText(l.primary, R / 2, 90)
      ctx.font = `400 50px ${HELV}`
      const bw = Math.min(860, ctx.measureText(l.body).width + 80)
      ctx.fillStyle = '#e5e5ea'
      ctx.beginPath()
      ctx.roundRect(40, 150, bw, 120, 60)
      ctx.fill()
      ctx.beginPath()
      ctx.moveTo(45, 250)
      ctx.quadraticCurveTo(30, 285, 15, 290)
      ctx.quadraticCurveTo(60, 290, 85, 260)
      ctx.fill()
      ctx.fillStyle = tc
      ctx.textAlign = 'left'
      ctx.fillText(l.body, 80, 212, 780)
      ctx.fillStyle = '#ffffff'
      ctx.beginPath()
      ctx.arc(105, 400, 65, 0, Math.PI * 2)
      ctx.fill()
      ctx.beginPath()
      ctx.roundRect(200, 335, 760, 130, 65)
      ctx.fill()
      ctx.strokeStyle = tc
      ctx.lineWidth = 6
      ctx.beginPath()
      ctx.moveTo(80, 400)
      ctx.lineTo(130, 400)
      ctx.moveTo(105, 375)
      ctx.lineTo(105, 425)
      ctx.stroke()
      ctx.fillStyle = '#3a3a3c'
      ctx.font = `400 50px ${HELV}`
      ctx.fillText(l.title, 250, 402, 560)
      const cw = Math.min(560, ctx.measureText(l.title).width)
      ctx.fillStyle = accent
      ctx.fillRect(258 + cw, 370, 5, 64)
      ctx.beginPath()
      ctx.arc(890, 400, 50, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = '#fff'
      ctx.lineWidth = 9
      ctx.beginPath()
      ctx.moveTo(890, 428)
      ctx.lineTo(890, 372)
      ctx.moveTo(866, 394)
      ctx.lineTo(890, 370)
      ctx.lineTo(914, 394)
      ctx.stroke()
      ctx.fillStyle = 'rgba(0,0,0,0.06)'
      ctx.beginPath()
      ctx.roundRect(30, 520, R - 60, 110, 55)
      ctx.fill()
      magnifier(ctx, 95, 575, 50, '#8e8e93')
      ctx.fillStyle = '#8e8e93'
      ctx.font = `400 46px ${HELV}`
      ctx.fillText('Search Emoji', 150, 578)
      break
    }
    case 'safari-tabs': {
      const { n } = L as { n: number }
      const full = { x: 30, y: 70, w: R - 60, h: (n - 1) * 330 + 350 }
      ctx.fillStyle = '#2a2a2c'
      ctx.beginPath()
      ctx.roundRect(0, 0, R, H, 40)
      ctx.fill()
      for (let i = 0; i < n; i++) {
        const y = i * 330
        ctx.save()
        ctx.translate(30, y)
        panel(ctx, R - 60, 420, 16, l.surface)
        ctx.restore()
        drawCover(ctx, project, l, 30, y + 70, R - 60, 350, 0, full)
        ctx.fillStyle = l.surface
        ctx.fillRect(30, y, R - 60, 70)
        ctx.fillStyle = tc
        ctx.font = `400 42px ${HELV}`
        ctx.textAlign = 'center'
        ctx.fillText(l.items[i]?.trim() || l.title, R / 2, y + 38, R - 220)
        ctx.lineWidth = 5
        ctx.strokeStyle = tc
        ctx.beginPath()
        ctx.moveTo(62, y + 22)
        ctx.lineTo(92, y + 52)
        ctx.moveTo(92, y + 22)
        ctx.lineTo(62, y + 52)
        ctx.stroke()
      }
      const by = H - 80
      ctx.fillStyle = l.accent
      ctx.font = `400 50px ${HELV}`
      ctx.textAlign = 'left'
      ctx.fillText(l.secondary, 40, by)
      ctx.textAlign = 'right'
      ctx.fillText(l.primary, R - 40, by)
      ctx.strokeStyle = l.accent
      ctx.lineWidth = 4
      ctx.beginPath()
      ctx.moveTo(R / 2 - 30, by)
      ctx.lineTo(R / 2 + 30, by)
      ctx.moveTo(R / 2, by - 30)
      ctx.lineTo(R / 2, by + 30)
      ctx.stroke()
      break
    }
  }
}
