import { experimental_generateSpeech as generateSpeech } from 'ai'

export const maxDuration = 60

const VOICES = new Set(['alloy', 'ash', 'coral', 'echo', 'fable', 'nova', 'onyx', 'sage', 'shimmer'])

export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as { text?: unknown; voice?: unknown; speed?: unknown } | null
  const text = typeof body?.text === 'string' ? body.text.trim() : ''
  const voice = typeof body?.voice === 'string' && VOICES.has(body.voice) ? body.voice : 'nova'
  const speed = typeof body?.speed === 'number' ? Math.min(2, Math.max(0.5, body.speed)) : 1
  if (!text) return Response.json({ error: 'Enter a script to speak.' }, { status: 400 })
  if (text.length > 4000) return Response.json({ error: 'Keep the script under 4,000 characters.' }, { status: 400 })

  try {
    const { audio } = await generateSpeech({ model: 'openai/tts-1-hd', text, voice, speed })
    return new Response(audio.uint8Array as BodyInit, {
      headers: { 'Content-Type': audio.mediaType || 'audio/mpeg', 'Cache-Control': 'no-store' },
    })
  } catch (err) {
    console.error('[speech]', err)
    return Response.json({ error: 'Voice generation failed.' }, { status: 500 })
  }
}
