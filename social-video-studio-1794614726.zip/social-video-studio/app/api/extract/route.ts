import { generateText, jsonSchema, Output } from 'ai'

export const maxDuration = 60

const FORMS = ['ios-alert', 'airdrop', 'notes', 'google-search', 'context-menu', 'id-badge', 'imessage', 'safari-tabs'] as const

export interface ExtractedElement {
  kind: 'form' | 'sticker'
  name: string
  form: (typeof FORMS)[number] | null
  title: string
  body: string
  items: string[]
  primary: string
  secondary: string
  accent: string
  surface: string
  textColor: string
  bbox: { x: number; y: number; w: number; h: number }
}

const schema = jsonSchema<{ elements: ExtractedElement[] }>({
  type: 'object',
  additionalProperties: false,
  required: ['elements'],
  properties: {
    elements: {
      type: 'array',
      items: {
        type: 'object',
        additionalProperties: false,
        required: ['kind', 'name', 'form', 'title', 'body', 'items', 'primary', 'secondary', 'accent', 'surface', 'textColor', 'bbox'],
        properties: {
          kind: { type: 'string', enum: ['form', 'sticker'] },
          name: { type: 'string' },
          form: { type: ['string', 'null'], enum: [...FORMS, null] },
          title: { type: 'string' },
          body: { type: 'string' },
          items: { type: 'array', items: { type: 'string' } },
          primary: { type: 'string' },
          secondary: { type: 'string' },
          accent: { type: 'string' },
          surface: { type: 'string' },
          textColor: { type: 'string' },
          bbox: {
            type: 'object',
            additionalProperties: false,
            required: ['x', 'y', 'w', 'h'],
            properties: { x: { type: 'number' }, y: { type: 'number' }, w: { type: 'number' }, h: { type: 'number' } },
          },
        },
      },
    },
  },
})

const PROMPT = `You analyse social-media graphics and extract reusable design elements.

Return every distinct element:
1. kind "form": a UI mockup overlay (alert dialog, AirDrop card, Notes header, Google search bar with suggestions, right-click/context menu, ID badge on lanyard, iMessage/keyboard panel, stacked Safari tabs). Pick the closest "form" from: ${FORMS.join(', ')}.
   Fill the fields with the exact visible text:
   - title: main text / headline / search query / typed message. Wrap words shown in the accent color or bold-colored in *asterisks*.
   - body: secondary text (subtitle, incoming message, second headline line).
   - items: list rows (search suggestions, menu entries, tab titles). Use "---" for a menu divider and add " >" for rows with a submenu arrow.
   - primary / secondary: button labels (e.g. Accept / Decline, Save), Notes back-label, badge Name / Role, iMessage date label.
   - accent, surface, textColor: hex colors from the image.
2. kind "sticker": a physical object or person worth cutting out (product, food, cup, packaging). form null, other text fields empty, colors "#000000".

bbox is the element's bounding box as fractions 0-1 of the image (x,y = top-left). Keep it tight. Return at most 8 elements, forms first.`

export async function POST(req: Request) {
  const form = await req.formData()
  const file = form.get('image')
  if (!(file instanceof File) || !file.type.startsWith('image/')) return Response.json({ error: 'Send an image file.' }, { status: 400 })
  if (file.size > 8 * 1024 * 1024) return Response.json({ error: 'Image must be under 8 MB.' }, { status: 413 })

  try {
    const { output } = await generateText({
      model: 'google/gemini-3-flash',
      output: Output.object({ schema }),
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: PROMPT },
            { type: 'image', image: new Uint8Array(await file.arrayBuffer()), mediaType: file.type },
          ],
        },
      ],
    })
    return Response.json({ elements: output.elements.slice(0, 8) })
  } catch (err) {
    console.error('[extract]', err)
    return Response.json({ error: 'Could not analyse this image.' }, { status: 500 })
  }
}
