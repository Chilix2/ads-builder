import { experimental_transcribe as transcribe } from 'ai'

export const maxDuration = 120

const MAX_BYTES = 25 * 1024 * 1024

type Timed = { text?: string; word?: string; startSecond?: number; endSecond?: number; start?: number; end?: number }

const norm = (items: unknown): { text: string; start: number; end: number }[] =>
  Array.isArray(items)
    ? (items as Timed[])
        .map((w) => ({
          text: String(w.text ?? w.word ?? '').trim(),
          start: Number(w.startSecond ?? w.start ?? 0),
          end: Number(w.endSecond ?? w.end ?? 0),
        }))
        .filter((w) => w.text)
    : []

export async function POST(req: Request) {
  const form = await req.formData().catch(() => null)
  const file = form?.get('file')
  if (!(file instanceof Blob) || file.size === 0) return Response.json({ error: 'No audio file provided.' }, { status: 400 })
  if (file.size > MAX_BYTES) return Response.json({ error: 'File is over 25 MB. Trim the clip or upload the audio track only.' }, { status: 413 })

  try {
    const result = await transcribe({
      model: 'openai/whisper-1',
      audio: new Uint8Array(await file.arrayBuffer()),
      providerOptions: { openai: { timestampGranularities: ['word', 'segment'] } },
    })
    const r = result as unknown as { words?: unknown }
    return Response.json({
      text: result.text,
      language: result.language ?? null,
      duration: result.durationInSeconds ?? null,
      words: norm(r.words),
      segments: norm(result.segments),
    })
  } catch (err) {
    console.error('[transcribe]', err)
    return Response.json({ error: 'Transcription failed. Try a shorter clip.' }, { status: 500 })
  }
}
