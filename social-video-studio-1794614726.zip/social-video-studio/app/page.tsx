import { EditorClient } from '@/components/editor/editor-client'

export default function Page() {
  return <EditorClient />
}
